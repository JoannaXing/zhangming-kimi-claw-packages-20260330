#!/bin/zsh

set -u

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR" || exit 1

CURRENT_LOG="${CURRENT_LOG:-$ROOT_DIR/logs/backfill-doc-all-watchdog-resume-20260330-175222.log}"
NEW_DOC_TOKEN="${NEW_DOC_TOKEN:-}"
SESSION_NAME="${SESSION_NAME:-douyin_doc_backfill}"
NEW_SESSION_NAME="${NEW_SESSION_NAME:-douyin_doc_backfill}"
POLL_SECONDS="${POLL_SECONDS:-2}"
STALL_SECONDS="${STALL_SECONDS:-180}"
MAX_DOC_WRITE_SECONDS="${MAX_DOC_WRITE_SECONDS:-5400}"
WAIT_VIDEO_ID="${WAIT_VIDEO_ID:-}"
NEW_LOG="${NEW_LOG:-$ROOT_DIR/logs/backfill-doc-all-switch-$(date +%Y%m%d-%H%M%S).log}"
RECONCILE_FIRST="${RECONCILE_FIRST:-1}"

if [[ -z "$NEW_DOC_TOKEN" ]]; then
  echo "缺少 NEW_DOC_TOKEN" >&2
  exit 1
fi

if [[ ! -f "$CURRENT_LOG" ]]; then
  echo "当前日志不存在: $CURRENT_LOG" >&2
  exit 1
fi

switch_log() {
  printf '[switch][%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*"
}

last_started_id() {
  node -e "const fs=require('fs'); const p=process.argv[1]; if(!fs.existsSync(p)){process.exit(0);} const lines=fs.readFileSync(p,'utf8').split(/\n/); let last=''; const re=/\[\d+\/\d+\]\s+开始补写文档:\s*(\d+)/; for(const line of lines){const m=line.match(re); if(m) last=m[1];} if(last) process.stdout.write(last);" "$CURRENT_LOG"
}

last_completed_id() {
  node -e "const fs=require('fs'); const p=process.argv[1]; if(!fs.existsSync(p)){process.exit(0);} const lines=fs.readFileSync(p,'utf8').split(/\n/); let last=''; const re=/\[\d+\/\d+\]\[(\d+)\]\s+文档回填完成/; for(const line of lines){const m=line.match(re); if(m) last=m[1];} if(last) process.stdout.write(last);" "$CURRENT_LOG"
}

video_completed() {
  local video_id="$1"
  rg -q "\\[\\d+/\\d+\\]\\[$video_id\\]\\s+文档回填完成" "$CURRENT_LOG"
}

mark_completed_rewrites() {
  local checkpoint_path="$ROOT_DIR/.state/checkpoints/douyin-transcribe-to-feishu.json"
  node - "$ROOT_DIR/logs" "$CURRENT_LOG" "$checkpoint_path" <<'NODE'
const fs = require('fs');
const path = require('path');

const logsDir = String(process.argv[2] || '').trim();
const currentLogPath = String(process.argv[3] || '').trim();
const checkpointPath = String(process.argv[4] || '').trim();
if (!checkpointPath || !fs.existsSync(checkpointPath)) {
  process.exit(1);
}

const candidateLogs = new Set();
if (logsDir && fs.existsSync(logsDir)) {
  for (const name of fs.readdirSync(logsDir)) {
    if (!/^backfill-doc-all.*\.log$/.test(name)) continue;
    candidateLogs.add(path.join(logsDir, name));
  }
}
if (currentLogPath && fs.existsSync(currentLogPath)) {
  candidateLogs.add(currentLogPath);
}

const checkpoint = JSON.parse(fs.readFileSync(checkpointPath, 'utf8'));
checkpoint.items = checkpoint.items || {};
const now = new Date().toISOString();
const re = /\[\d+\/\d+\]\[(\d+)\]\s+文档回填完成/;
let marked = 0;
let last = '';

for (const logPath of [...candidateLogs].sort()) {
  if (!fs.existsSync(logPath)) continue;
  const lines = fs.readFileSync(logPath, 'utf8').split(/\n/);
  for (const line of lines) {
    const match = line.match(re);
    if (!match) continue;
    const videoId = String(match[1] || '').trim();
    if (!videoId) continue;
    last = videoId;
    const existing = checkpoint.items[videoId] || {};
    if (!String(existing.docRewriteCompletedAt || '').trim()) {
      checkpoint.items[videoId] = {
        ...existing,
        input: existing.input || videoId,
        docRewriteCompletedAt: now,
      };
      marked += 1;
    }
  }
}

fs.writeFileSync(checkpointPath, JSON.stringify(checkpoint, null, 2));
process.stdout.write(`${marked}\t${last}`);
NODE
}

if [[ -z "$WAIT_VIDEO_ID" ]]; then
  WAIT_VIDEO_ID="$(last_started_id)"
fi

if [[ -z "$WAIT_VIDEO_ID" ]]; then
  echo "无法从当前日志识别正在处理的视频 ID" >&2
  exit 1
fi

switch_log "waiting for video $WAIT_VIDEO_ID to finish"

until video_completed "$WAIT_VIDEO_ID"; do
  sleep "$POLL_SECONDS"
done

RESUME_AFTER="$(last_completed_id)"
if [[ -z "$RESUME_AFTER" ]]; then
  echo "无法识别最后完成的视频 ID" >&2
  exit 1
fi

switch_log "video $WAIT_VIDEO_ID completed, resume_after=$RESUME_AFTER"
switch_log "stopping session $SESSION_NAME"
screen -S "$SESSION_NAME" -X quit >/dev/null 2>&1 || true
sleep 2

mark_result="$(mark_completed_rewrites || true)"
marked_count="${mark_result%%$'\t'*}"
marked_last="${mark_result#*$'\t'}"
switch_log "checkpoint marked_from_log count=${marked_count:-0} last=${marked_last:-<none>}"

if [[ "$RECONCILE_FIRST" != "0" ]]; then
  switch_log "reconciling new target $NEW_DOC_TOKEN"
  if ! node douyin-transcribe-to-feishu.js --reconcile-target --doc-token "$NEW_DOC_TOKEN" >> "$NEW_LOG" 2>&1; then
    echo "reconcile 失败，详见日志: $NEW_LOG" >&2
    exit 1
  fi
fi

switch_log "starting session $NEW_SESSION_NAME on doc $NEW_DOC_TOKEN"
screen -S "$NEW_SESSION_NAME" -X quit >/dev/null 2>&1 || true
screen -dmS "$NEW_SESSION_NAME" zsh -lc "cd \"$ROOT_DIR\" && LOG=\"$NEW_LOG\" DOC_TOKEN=\"$NEW_DOC_TOKEN\" POLL_SECONDS=\"$POLL_SECONDS\" STALL_SECONDS=\"$STALL_SECONDS\" MAX_DOC_WRITE_SECONDS=\"$MAX_DOC_WRITE_SECONDS\" ./run_backfill_doc_all_watchdog.sh"

sleep 2
if ! screen -ls | grep -q "[.]$NEW_SESSION_NAME"; then
  echo "新会话未成功启动: $NEW_SESSION_NAME" >&2
  exit 1
fi

switch_log "new log: $NEW_LOG"
printf '%s\n' "$NEW_LOG"

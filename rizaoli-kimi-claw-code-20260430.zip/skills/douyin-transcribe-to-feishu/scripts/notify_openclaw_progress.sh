#!/usr/bin/env bash
# 将抖音定时同步结果推送到 OpenClaw 已连接的聊天通道（默认飞书 DM）。
# 依赖：PATH 中有 openclaw；Gateway 已运行；通道已登录。
# 环境变量（可选，覆盖 runtime / daily-sync.env 已 eval 的 scheduler_*）：
#   OPENCLAW_NOTIFY_TARGET   如 user:ou_xxxx
#   OPENCLAW_NOTIFY_CHANNEL  默认 feishu

set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./scheduler_runtime_env.sh
source "$SCRIPT_DIR/scheduler_runtime_env.sh"
setup_scheduler_runtime_env

LOG_FILE=${1:-}
SYNC1_EXIT=${2:-0}
SYNC2_EXIT=${3:-0}
ENG_RAN=${4:-0}
REPORT_FILE=${5:-}

if [[ -z "${LOG_FILE}" || ! -f "${LOG_FILE}" ]]; then
  echo "[douyin-notify] 跳过：无效日志文件" >&2
  exit 0
fi

ENABLED="${scheduler_openclaw_notify_enabled:-false}"
TARGET="${OPENCLAW_NOTIFY_TARGET:-${scheduler_openclaw_notify_target:-}}"
CHANNEL="${OPENCLAW_NOTIFY_CHANNEL:-${scheduler_openclaw_notify_channel:-feishu}}"

if [[ "$ENABLED" != "true" ]]; then
  exit 0
fi

if [[ -z "$TARGET" ]]; then
  echo "[douyin-notify] 已开启 OpenClaw 简报，但未配置接收目标。请在 .state/daily-sync.env 写入：" >&2
  echo "  OPENCLAW_NOTIFY_TARGET=user:你的飞书OpenID前缀（与 openclaw cron 里 delivery.to 格式一致）" >&2
  exit 0
fi

OPENCLAW_BIN_HINT="${DOUYIN_OPENCLAW_BIN:-${OPENCLAW_BIN:-}}"
OPENCLAW_BIN="$(
  resolve_command_bin \
    openclaw \
    "$OPENCLAW_BIN_HINT" \
    "/opt/homebrew/bin/openclaw" \
    "/usr/local/bin/openclaw" \
    "/usr/bin/openclaw" \
    "${HOME}/.npm-global/bin/openclaw" \
    "${HOME}/.local/bin/openclaw"
)" || true

if [[ -z "$OPENCLAW_BIN" ]]; then
  echo "[douyin-notify] 未找到 openclaw 命令，无法推送。请安装 CLI 或把 openclaw 加入 PATH。日志：${LOG_FILE}" >&2
  echo "[douyin-notify] 可选：在 .state/daily-sync.env 写入 OPENCLAW_BIN=/绝对路径/openclaw" >&2
  exit 0
fi
append_path_entries "$(dirname "$OPENCLAW_BIN")"

if ! "$OPENCLAW_BIN" health >/dev/null 2>&1; then
  echo "[douyin-notify] OpenClaw Gateway 未响应，简报未发送。请先启动本机 gateway；详细日志：${LOG_FILE}" >&2
  exit 0
fi

if [[ -n "$REPORT_FILE" && -f "$REPORT_FILE" ]]; then
  body="$(cat "$REPORT_FILE")"
else
  SH_TIME="$(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M')"

  overall="✅ 本轮同步脚本已结束。"
  if [[ "$SYNC1_EXIT" -ne 0 ]] || { [[ "$ENG_RAN" == "1" ]] && [[ "$SYNC2_EXIT" -ne 0 ]]; }; then
    overall="⚠️ 本轮有步骤异常退出，请打开下方日志文件排查。"
  fi

  stage1="• 新视频增量："
  if grep -q "本次没有待处理视频" "$LOG_FILE" 2>/dev/null; then
    stage1+="暂无新稿，未执行转写。"
  else
    line="$(grep "处理汇总:" "$LOG_FILE" 2>/dev/null | tail -n 1 || true)"
    if [[ -n "$line" ]]; then
      clean="${line##*] }"
      stage1+="${clean}"
    else
      stage1+="未在日志中解析到汇总行（增量阶段退出码 ${SYNC1_EXIT}）。"
    fi
  fi

  stage2=""
  if [[ "$ENG_RAN" == "1" ]]; then
    stage2="• 近 7 天互动核对："
    if grep -q "近窗互动核对完成:" "$LOG_FILE" 2>/dev/null; then
      line="$(grep "近窗互动核对完成:" "$LOG_FILE" | tail -n 1)"
      stage2+="${line##*] }"
    elif grep -q "没有可核对的视频" "$LOG_FILE" 2>/dev/null; then
      line="$(grep "没有可核对的视频" "$LOG_FILE" | tail -n 1)"
      stage2+="${line##*] }"
    else
      stage2+="未解析到核对摘要（退出码 ${SYNC2_EXIT}）。"
    fi
  else
    stage2="• 近 7 天互动核对：已在配置中关闭，本轮未执行。"
  fi

  body="$(cat <<EOF
🎬 抖音转写 · 定时同步简报

📅 上海时间 ${SH_TIME}
${overall}

${stage1}
${stage2}

📎 完整日志
${LOG_FILE}

——
💡 没收到消息？先确认本机 OpenClaw Gateway 在跑、飞书插件已连线；目标用户 ID 见 OPENCLAW_NOTIFY_TARGET。
EOF
)"
fi

if "$OPENCLAW_BIN" message send --channel "$CHANNEL" --target "$TARGET" -m "$body" >>"$LOG_FILE" 2>&1; then
  echo "[douyin-notify] 已推送到 OpenClaw（${CHANNEL} → ${TARGET}）" >>"$LOG_FILE"
else
  echo "[douyin-notify] openclaw message send 失败，请检查上方同日志中的 CLI 输出；可先运行: openclaw health" >>"$LOG_FILE"
  echo "[douyin-notify] 推送失败，详情已追加到日志: ${LOG_FILE}" >&2
  exit 0
fi

#!/usr/bin/env python3
"""
Grounded article generation based on retrieved video knowledge records.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

PROVIDER_CHOICES = ("auto", "ark", "openclaw")
OPENCLAW_RETRY_ATTEMPTS = 2


def resolve_openclaw_bin() -> str:
    return str(os.getenv("OPENCLAW_BIN") or os.getenv("OPENCLAW_CLI_BIN") or "openclaw").strip() or "openclaw"


def strip_code_fence(text: str) -> str:
    value = str(text or "").strip()
    fenced = re.match(r"^```(?:json)?\s*([\s\S]*?)\s*```$", value, flags=re.IGNORECASE)
    return fenced.group(1).strip() if fenced else value


def parse_json_from_text(text: str) -> dict[str, Any]:
    raw = strip_code_fence(text)
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end < start:
        raise ValueError("模型输出中未找到 JSON 对象")
    return json.loads(raw[start : end + 1])


def extract_ark_chat_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") if isinstance(data, dict) else None
    if not isinstance(choices, list) or not choices:
        return ""
    primary = (((choices[0] or {}).get("message") or {}).get("content"))
    if isinstance(primary, str):
        return primary.strip()
    if isinstance(primary, list):
        parts: list[str] = []
        for item in primary:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "\n".join(part.strip() for part in parts if part and part.strip()).strip()
    return ""


def extract_openclaw_text(result: dict[str, Any]) -> str:
    payloads = (((result or {}).get("result") or {}).get("payloads")) or ((result or {}).get("payloads")) or []
    parts: list[str] = []
    for payload in payloads:
        if isinstance(payload, dict) and isinstance(payload.get("text"), str):
            text = payload["text"].strip()
            if text:
                parts.append(text)
    return "\n".join(parts).strip()


def normalize_multiline_text(text: str) -> str:
    value = str(text or "").replace("\r\n", "\n").strip()
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value


def normalize_provider(value: Any, *, field_name: str) -> str:
    provider = str(value or "").strip().lower()
    if not provider:
        return "auto"
    if provider not in PROVIDER_CHOICES:
        supported = ", ".join(PROVIDER_CHOICES)
        raise ValueError(f"{field_name} 只支持 {supported}，当前为: {value}")
    return provider


def default_used_source_ranks(results: list[dict[str, Any]], limit: int = 3) -> list[int]:
    ranks: list[int] = []
    for item in results[: min(limit, len(results))]:
        rank = item.get("rank")
        if isinstance(rank, int):
            ranks.append(rank)
    return ranks


@dataclass
class GenerationOptions:
    target_words: int
    retrieval_query: str
    original_request: str
    voice: str | None = None
    audience: str | None = None
    provider: str | None = None
    include_source_refs: bool = True


class ArticleGenerator:
    """Generate grounded long-form text from retrieved evidence."""

    def __init__(self, config: dict[str, Any] | None = None):
        config = config or {}
        generation_cfg = config.get("generation", {})
        self.provider = normalize_provider(
            os.getenv("KNOWLEDGE_WRITER_PROVIDER") or generation_cfg.get("provider") or "auto",
            field_name="KNOWLEDGE_WRITER_PROVIDER / generation.provider",
        )
        self.timeout_seconds = int(generation_cfg.get("timeout_seconds") or 120)
        self.temperature = float(generation_cfg.get("temperature") or 0.2)
        self.ark_base_url = (
            str(os.getenv("ARK_BASE_URL") or generation_cfg.get("ark_base_url") or "").strip()
            or "https://ark.cn-beijing.volces.com/api/v3"
        )
        self.ark_model = (
            str(os.getenv("ARK_MODEL") or generation_cfg.get("ark_model") or "").strip()
            or "doubao-seed-2-0-lite-260215"
        )
        self.ark_max_tokens = int(generation_cfg.get("ark_max_tokens") or 2200)
        self.openclaw_thinking = str(generation_cfg.get("openclaw_thinking") or "minimal").strip() or "minimal"
        self.ark_api_key = str(os.getenv("ARK_API_KEY") or generation_cfg.get("ark_api_key") or "").strip()

    def generate(self, payload: dict[str, Any], options: GenerationOptions) -> dict[str, Any]:
        results = list(payload.get("results") or [])
        if not results:
            raise ValueError("检索结果为空，无法生成 grounded 文章")

        prompt = self._build_prompt(payload, options)
        provider = (
            normalize_provider(options.provider, field_name="--provider")
            if options.provider is not None
            else self.provider
        )
        attempt_providers = self._resolve_generation_attempts(provider)

        try:
            generated: dict[str, Any] | None = None
            used_provider = "fallback"
            last_error: Exception | None = None
            for candidate in attempt_providers:
                try:
                    if candidate == "ark":
                        raw_text = self._generate_with_ark(prompt)
                    else:
                        raw_text = ""
                        for attempt in range(OPENCLAW_RETRY_ATTEMPTS):
                            try:
                                raw_text = self._generate_with_openclaw(prompt)
                                break
                            except Exception as exc:
                                last_error = exc
                                if attempt + 1 < OPENCLAW_RETRY_ATTEMPTS:
                                    time.sleep(0.8)
                        if not raw_text:
                            raise last_error or RuntimeError("OpenClaw 生成失败")
                    generated = self._parse_generation_payload_with_recovery(raw_text, payload, options)
                    used_provider = candidate
                    break
                except Exception as exc:
                    last_error = exc

            if generated is None:
                if provider == "ark" and not self._has_ark_provider():
                    raise RuntimeError("ARK_API_KEY 未配置，无法使用 Ark 生成文章") from last_error
                raise last_error or RuntimeError("文章生成失败")
        except Exception:
            generated = self._fallback_from_sources(payload, options)
            used_provider = "fallback"


        selected_results = self._select_results_by_rank(results, generated.get("usedSourceRanks") or [])
        if not selected_results:
            selected_results = results[: min(3, len(results))]

        rendered = self._render_markdown(
            generated=generated,
            selected_results=selected_results,
            source_ref_text=payload.get("sourceRefText") if options.include_source_refs else "",
        )
        return {
            "provider": used_provider,
            "title": generated.get("title", ""),
            "quote": generated.get("quote", ""),
            "article": generated.get("article", ""),
            "usedSourceRanks": generated.get("usedSourceRanks") or [],
            "groundingNotes": generated.get("groundingNotes") or [],
            "markdown": rendered,
        }

    def _build_prompt(self, payload: dict[str, Any], options: GenerationOptions) -> str:
        voice_line = (
            f"显式口吻要求：{options.voice.strip()}"
            if options.voice and options.voice.strip()
            else (
                "默认口吻要求：沿用知识库里稳定的表达方式。优先保持口语化、判断先行、"
                "再给例子、最后收束，不要切成 AI 腔、营销腔、学术论文腔。"
            )
        )
        audience_line = f"受众：{options.audience.strip()}" if options.audience and options.audience.strip() else "受众：泛中文读者"

        evidence_blocks: list[str] = []
        for item in payload.get("results") or []:
            evidence_blocks.append(
                "\n".join(
                    [
                        f"[S{item.get('rank')}]",
                        f"发布日期：{item.get('publishDate') or '未知'}",
                        f"主题：{item.get('topic') or '未命名主题'}",
                        f"视频ID：{item.get('videoId') or ''}",
                        f"命中分数：{item.get('score') or 0}",
                        f"命中原因：{'；'.join(item.get('whyMatched') or []) or '无'}",
                        "核心要点：",
                        *(f"- {point}" for point in (item.get("keyPoints") or [])[:4]),
                        "命中片段：",
                        str(item.get("snippet") or "").strip() or "无",
                        "全文摘录：",
                        str(item.get("transcriptExcerpt") or "").strip() or "无",
                        f"链接：{item.get('url') or ''}",
                    ]
                )
            )

        return "\n".join(
            [
                "你在做一篇 grounded 中文文章写作。你必须严格基于给定证据写作，不得编造证据之外的人物细节、原话、时间、数据、案例或结论。",
                "如果某个结论证据不够，就不要写重，不要拔高。",
                "金句可以是你基于证据提炼的新表达，但不能违背证据。",
                "正文必须至少包含：1 个明确观点、1 个来自证据的具体案例、1 句收束性的金句。",
                "正文只写中文。",
                "输出要求：仅输出 JSON，不要输出 markdown、解释、代码块或前后缀文字。",
                'JSON 结构固定为 {"title":"标题","article":"正文段落，段落间用\\n\\n分隔","quote":"收束金句","usedSourceRanks":[1,2],"groundingNotes":["说明1","说明2"]}。',
                "最终输出的第一个字符必须是 {，最后一个字符必须是 }。",
                "title 控制在 6 到 18 个汉字。",
                f"正文目标长度：约 {max(120, options.target_words)} 个中文字符。",
                f"原始写作要求：{options.original_request}",
                f"检索查询：{options.retrieval_query}",
                voice_line,
                audience_line,
                "",
                "证据如下：",
                *evidence_blocks,
            ]
        )

    def _generate_with_ark(self, prompt: str) -> str:
        payload = {
            "model": self.ark_model,
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个 grounded 中文写作助手。你只输出 JSON，不输出解释、markdown 或代码块。",
                },
                {"role": "user", "content": prompt},
            ],
            "temperature": self.temperature,
            "max_tokens": self.ark_max_tokens,
            "thinking": {"type": "disabled"},
        }
        request = urllib.request.Request(
            f"{self.ark_base_url.rstrip('/')}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.ark_api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout_seconds) as response:
                raw = response.read().decode("utf-8")
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="ignore")
            raise RuntimeError(f"Ark 生成失败: HTTP {exc.code} {body}") from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(f"Ark 生成失败: {exc.reason}") from exc

        data = json.loads(raw)
        text = extract_ark_chat_text(data)
        if not text:
            raise RuntimeError("Ark 返回为空")
        return text

    def _generate_with_openclaw(self, prompt: str) -> str:
        completed = subprocess.run(
            [
                resolve_openclaw_bin(),
                "--log-level",
                "silent",
                "agent",
                "--agent",
                "main",
                "--local",
                "--json",
                "--timeout",
                str(self.timeout_seconds),
                "--thinking",
                self.openclaw_thinking,
                "--message",
                prompt,
            ],
            capture_output=True,
            text=True,
            check=False,
        )
        raw = completed.stdout.strip() or completed.stderr.strip()
        if completed.returncode != 0:
            raise RuntimeError(f"OpenClaw 生成失败: {raw or f'exit={completed.returncode}'}")
        result = parse_json_from_text(raw)
        status = result.get("status")
        if status not in {None, "ok"}:
            raise RuntimeError(f"OpenClaw 生成失败: {result.get('summary') or 'unknown_error'}")
        text = extract_openclaw_text(result)
        if not text:
            raise RuntimeError("OpenClaw 返回为空")
        return text

    def _has_ark_provider(self) -> bool:
        return bool(self.ark_api_key)

    def _resolve_generation_attempts(self, provider: str) -> list[str]:
        if provider == "ark":
            return ["ark"]
        if provider == "openclaw":
            return ["openclaw", "ark"] if self._has_ark_provider() else ["openclaw"]
        if provider == "auto":
            return ["ark", "openclaw"] if self._has_ark_provider() else ["openclaw"]
        return ["openclaw", "ark"] if self._has_ark_provider() else ["openclaw"]

    def _recover_generation_from_text(
        self,
        raw_text: str,
        payload: dict[str, Any],
        options: GenerationOptions,
    ) -> dict[str, Any] | None:
        text = normalize_multiline_text(strip_code_fence(raw_text))
        if not text:
            return None

        title = ""
        quote = ""
        article = text

        title_match = re.search(r"(?:^|\n)标题\s*[:：]\s*(.+)", text)
        if title_match:
            title = title_match.group(1).strip()
            article = article.replace(title_match.group(0), "", 1)

        quote_match = re.search(r"(?:^|\n)(?:金句|quote)\s*[:：]\s*(.+)", text, flags=re.IGNORECASE)
        if quote_match:
            quote = quote_match.group(1).strip()
            article = article.replace(quote_match.group(0), "", 1)

        article = normalize_multiline_text(article)
        if not article:
            return None

        lines = [line.strip() for line in article.splitlines() if line.strip()]
        if not title and lines and len(lines[0]) <= 18:
            title = lines[0]
            article = normalize_multiline_text(article[len(lines[0]) :])

        compact = re.sub(r"\s+", "", article)
        if len(compact) < 60:
            return None

        if not title:
            title = f"{options.retrieval_query}这件事"[:18]

        return {
            "title": title[:40],
            "article": article,
            "quote": quote[:80],
            "usedSourceRanks": default_used_source_ranks(list(payload.get("results") or [])),
            "groundingNotes": ["模型未按 JSON 返回，已自动提取正文。"],
        }

    def _parse_generation_payload_with_recovery(
        self,
        raw_text: str,
        payload: dict[str, Any],
        options: GenerationOptions,
    ) -> dict[str, Any]:
        try:
            return self._parse_generation_payload(raw_text)
        except Exception:
            recovered = self._recover_generation_from_text(raw_text, payload, options)
            if recovered:
                return recovered
            raise

    def _parse_generation_payload(self, raw_text: str) -> dict[str, Any]:
        parsed = parse_json_from_text(raw_text)
        title = str(parsed.get("title") or "").strip()
        article = normalize_multiline_text(parsed.get("article") or "")
        quote = str(parsed.get("quote") or "").strip()
        used_source_ranks: list[int] = []
        for item in parsed.get("usedSourceRanks") or []:
            if isinstance(item, int):
                used_source_ranks.append(item)
                continue
            if isinstance(item, str):
                match = re.search(r"(\d+)", item)
                if match:
                    used_source_ranks.append(int(match.group(1)))

        raw_grounding_notes = parsed.get("groundingNotes") or []
        if isinstance(raw_grounding_notes, str):
            raw_grounding_notes = [raw_grounding_notes]
        grounding_notes = [str(item).strip() for item in raw_grounding_notes if str(item).strip()]
        if not title:
            raise ValueError("生成结果缺少标题")
        if not article:
            raise ValueError("生成结果缺少正文")
        return {
            "title": title[:40],
            "article": article,
            "quote": quote[:80],
            "usedSourceRanks": used_source_ranks,
            "groundingNotes": grounding_notes[:6],
        }

    def _fallback_from_sources(self, payload: dict[str, Any], options: GenerationOptions) -> dict[str, Any]:
        results = list(payload.get("results") or [])
        primary = results[0]
        secondary = results[1] if len(results) > 1 else None
        main_point = ((primary.get("matchedKeyPoints") or primary.get("keyPoints") or [""])[0]).strip()
        case_sentence = str(primary.get("transcriptExcerpt") or primary.get("snippet") or "").strip()
        follow_point = ""
        if secondary:
            follow_point = ((secondary.get("matchedKeyPoints") or secondary.get("keyPoints") or [""])[0]).strip()

        paragraphs = [
            f"关于{options.retrieval_query}，我更在意的不是表面的动作，而是背后的节奏和判断。{main_point or '真正拉开差距的，往往不是表面动作，而是内在判断。'}",
            f"从知识库里的具体案例看，{case_sentence or '很多看似偶然的结果，背后其实都有稳定的思维和行为模式。'}",
        ]
        if follow_point:
            paragraphs.append(f"再往深一层看，{follow_point}。所以问题不只是会不会做，而是能不能把注意力放在真正关键的地方。")
        quote = (
            f"{options.retrieval_query}真正考验的，不是你有多用力，而是你能不能一直做对。"
            if options.retrieval_query
            else "真正拉开差距的，不是你多努力，而是你能不能长期做对。"
        )
        return {
            "title": f"{options.retrieval_query}这件事"[:18],
            "article": "\n\n".join(paragraphs),
            "quote": quote,
            "usedSourceRanks": [item.get("rank") for item in results[: min(3, len(results))] if item.get("rank")],
            "groundingNotes": ["模型输出解析失败，已降级为基于检索结果的抽取式写法。"],
        }

    def _select_results_by_rank(
        self,
        results: list[dict[str, Any]],
        used_source_ranks: list[int],
    ) -> list[dict[str, Any]]:
        if not used_source_ranks:
            return []
        rank_set = set(used_source_ranks)
        return [item for item in results if item.get("rank") in rank_set]

    def _render_markdown(
        self,
        generated: dict[str, Any],
        selected_results: list[dict[str, Any]],
        source_ref_text: str | None,
    ) -> str:
        lines = [f"# {generated['title']}", "", generated["article"].strip()]
        quote = str(generated.get("quote") or "").strip()
        if quote:
            lines.extend(["", f"金句：{quote}"])

        grounding_notes = generated.get("groundingNotes") or []
        if grounding_notes:
            lines.extend(["", "写作说明"])
            for item in grounding_notes:
                lines.append(f"- {item}")

        if selected_results:
            lines.extend(["", "主要参考"])
            for item in selected_results:
                lines.append(
                    f"- S{item.get('rank')}: {item.get('publishDate')} | {item.get('topic') or '未命名主题'} | 视频ID {item.get('videoId')}"
                )

        filtered_source_ref_text = ""
        if selected_results:
            ref_lines = ["原文定位"]
            for index, item in enumerate(selected_results, start=1):
                source_ref = item.get("sourceRef") or {}
                summary_line = str(source_ref.get("summaryLine") or "").strip()
                link_line = str(source_ref.get("linkLine") or "").strip()
                if summary_line and link_line:
                    ref_lines.append(f"{index}. {summary_line}")
                    ref_lines.append(f"   {link_line}")
            if len(ref_lines) > 1:
                filtered_source_ref_text = "\n".join(ref_lines)

        if filtered_source_ref_text:
            lines.extend(["", "---", "", filtered_source_ref_text])
        elif source_ref_text:
            lines.extend(["", "---", "", str(source_ref_text).strip()])

        return "\n".join(lines).strip() + "\n"

---
name: douyin-transcribe-to-feishu
description: 抖音视频语音转写、同步最新一期、更新本地索引，并输出飞书知识库日更简报
metadata:
  openclaw:
    emoji: 📝
    requires:
      bins: [ffmpeg, node, python3]
      env: []
---

# douyin-transcribe-to-feishu

处理链路：解析分享内容/短链 → 下载视频 → 提取元数据 → ASR 转写 → 标准化输出 → 写入飞书文档与多维表格 → checkpoint。

## 新能力

- `--limit` 控制抓取数量
- `--batch` 批量处理
- `douyin.com` 主站登录态深分页发现
- 标准化同步模式入口
- checkpoint 记录与真正 resume
- checkpoint 按写入目标感知
- 标准化文档格式
- 标准化 Bitable 字段映射
- 文档/Bitable 真正写回
- ASR 成功后本地持久化备份
- `--skip-doc-write` 表格优先模式
- `--backfill-doc-pending` 文档后补模式
- 成功写入后的本地索引日志
- macOS / Linux 双环境运行兼容
- 统一 runner 与调度安装脚本

## 固定目标

- 文档 Token：`AKKHw9M1DiY83LkK1ohcNtMDn7b`
- Bitable App Token：`QdSlbWIV4aLHaqswxh5cg0RLnKf`
- Table ID：`tbl8j1Qj6V9K0HPz`

## 用法

```bash
node douyin-transcribe-to-feishu.js "抖音链接或分享文本"
node douyin-transcribe-to-feishu.js --batch videos.txt --limit 5
node douyin-transcribe-to-feishu.js --batch videos.txt --limit 3 --dry-run
node douyin-transcribe-to-feishu.js --checkpoint /tmp/custom-checkpoint.json
node douyin-transcribe-to-feishu.js --sync-latest
node douyin-transcribe-to-feishu.js --sync-incremental
node douyin-transcribe-to-feishu.js --sync-recent 3
node douyin-transcribe-to-feishu.js --sync-date 2026-03-27
node douyin-transcribe-to-feishu.js --sync-month 2026-03
node douyin-transcribe-to-feishu.js --sync-oldest 20 --skip-doc-write
node douyin-transcribe-to-feishu.js --backfill-doc-pending --limit 10
node douyin-transcribe-to-feishu.js --rewrite 7621183793445803435
node douyin-transcribe-to-feishu.js --reconcile-target
node douyin-transcribe-to-feishu.js --backfill-missing-backups
node douyin-transcribe-to-feishu.js --backfill-comments-engagement
node douyin-transcribe-to-feishu.js --refresh-engagement-recent-days 7
node douyin-transcribe-to-feishu.js --refresh-engagement-recent-days 7 --limit 50
node douyin-transcribe-to-feishu.js --sync-latest --force-rewrite
node douyin-transcribe-to-feishu.js --sync-latest --doc-token xxx --bitable-app-token yyy --bitable-table-id zzz
node douyin-transcribe-to-feishu.js --sync-latest --index-log /tmp/customer-a-write-index.jsonl
node douyin-transcribe-to-feishu.js --sync-latest --backup-dir /tmp/customer-a-douyin-backups
node douyin-transcribe-to-feishu.js --sync-date 2026-03-03 --douyin-storage-state .state/douyin-storage-state.json
./scripts/run_douyin_daily_sync.sh
```

## 自然语言触发

以下说法默认都应该命中这个 skill，并优先走统一 runner：

- “同步抖音最新一期并给我简报”
- “拉新最近抖音视频”
- “更新视频知识库日更”
- “跑一下抖音日更任务”
- “同步最新数据，把多维表格和本地索引一起更新”

## 说明

- 默认直接复用 OpenClaw 的 Feishu channel 凭证写入文档和 Bitable。
- 飞书目标支持 `命令行 > 环境变量 > runtime.toml` 覆盖。
- 本地备份目录支持 `--backup-dir`、`DOUYIN_BACKUP_DIR` 或 `DOUYIN_TRANSCRIBE_BACKUP_DIR` 覆盖。
- checkpoint、索引日志和调度锁文件默认都落在 skill 内的 `.state/`，避免 macOS / Linux 调度时依赖 `/tmp`。
- 备份目录会按“文档/表格目标 + 视频ID”分层，切换客户目标时不会互相覆盖。
- 每个写入目标根目录会持续维护 `catalog.json`，作为该目标当前已接管视频的目录索引，默认按发布时间逆序排列。
- 同一目标根目录还会维护 `timeline-checklist.json`，按发布时间正序记录该视频在当前目标下的完成状态。
- 同一目标根目录还会维护 `dedupe-index.json`，识别“不同视频ID但内容重复”的条目。
- 推荐大批量补录时先跑 `--skip-doc-write`，先把多维表格和本地备份补全，再用 `--backfill-doc-pending` 慢慢补文档。
- `--sync-oldest N --skip-doc-write` 会优先消费“最早且尚未入表”的视频，不会被“表格已写、仅待补文档”的条目反复挡住。
- `--reconcile-target` 会扫描当前飞书文档与多维表格，把已存在内容接管到本地 `checkpoint / write-index / catalog`。
- `--backfill-missing-backups` 会针对当前目标里缺本地备份的条目重新抓取，并把文档区块与多维表格刷新到当前最新模板。
- 若设置了 `VOLC_APP_ID` / `VOLC_ACCESS_TOKEN`，会尝试火山云 ASR。
- 当前生产策略下，云端 ASR 若命中服务端异常会先短重试；重试后仍失败则直接报错退出，不会再自动回退到本地 Whisper。
- 账号级发现当前固定指向 `runtime.toml` 里的 `account.sec_uid`。
- 主站深分页默认读取 `runtime.toml` 里的 `browser.douyin_storage_state_path`，也可通过 `--douyin-storage-state` 或 `DOUYIN_STORAGE_STATE_PATH` 覆盖。
- `增量同步 / 同步最新一期 / 同步最近 N 期` 会优先使用主站首屏时间线；若无登录态则退回公开首屏。
- `同步指定日期 / 同步指定月份 / 从最早开始补 N 期` 依赖主站登录态深分页，并按抖音发布时间（UTC+8）严格筛选。
- `--sync-oldest N` 会优先使用本地 `timeline-checklist.json` 中尚未完成的最早视频；只有 checklist 还没覆盖完整账号时间线时，才会回到 douyin.com 做完整发现。
- `--force-rewrite` 可叠加到任意同步模式，跳过 checkpoint 已写入判断，直接重写该批视频。
- 成功写入后会追加 `jsonl` 索引日志，记录 `发布日期 / 视频ID / 标题 / 主题 / docToken / bitableAppToken / tableId / bitableRecordId`。
- 只要 ASR 成功，就会把 `record.json / transcript.txt / doc.md / bitable-fields.json / doc-sections.json / meta.json` 落到本地备份目录；每次运行还会额外写入 `runs/<时间戳>_<模型>/` 快照，低质量 fallback 不再覆盖已有 canonical。
- `meta.json` 会记录 `asrAttempts / asrFallbackUsed / asrPrimaryError`，便于定位云端 ASR 失败后为何回退到本地 Whisper。
- `meta.json` 还会记录 `dedupeStatus / canonicalVideoId / duplicateOfVideoId / contentFingerprint`，避免文档和表格重复入库。
- `config/text-corrections.json` 可维护账号级专名纠错词典，当前已内置 `张老师 -> 章老师`、`张敏 -> 章明`、`张明 -> 章明`、`张行长 -> 章行长`。
- checkpoint 仅会对“同一个视频 + 同一个文档/表格目标”生效，切换客户目标不会误跳过。
- 默认不会重写已存在内容；如果当前目标里已同时存在文档区块和表格记录，脚本会提示“已存在，保持原样”，只有显式 `--force-rewrite` 或 `--rewrite` 才会替换。
- 飞书文档写入默认最多尝试 2 次；若命中 `99991400 request trigger frequency limit`，会明确反馈“飞书写入限频，请稍后再试”，不会长时间死磕。
- 历史回填模式会改成“转写一条、表格一条、文档批量写入”；文档 flush 默认 10 条一批，批次间最小间隔 8 秒。
- 如果显式传入 `--skip-doc-write`，主链路会跳过飞书文档写入，只保留表格写入、本地备份和 checkpoint/checklist 更新。
- `--backfill-doc-pending` 会直接复用本地 `record.json + doc-sections.json` 补写飞书文档，不会重复做抖音抓取和 ASR。
- 当前已增加内容级去重：命中重复正文时，会保留本地备份，但会标记 `duplicate_skipped`，不再写表格、不再补文档。
- 文档插入位置会优先使用本地 `write-index.jsonl` 与 checkpoint 边界，减少整篇文档扫描。
- 飞书文档与多维表格统一按“抖音发布时间（UTC+8）逆序”处理；多维表格的 `发布日期` 会按秒级时间戳写入。
- 飞书多维表格界面的默认排序，仍需在视图中手动设置一次 `发布日期` 降序；公开 API 当前没有稳定的视图排序配置能力。
- 多维表格字段写入已支持别名解析；当前语义已拆成 `标签` 和 `主题` 两列，其中旧表头 `标签/主题` 仍可兼容承接 `标签`。
- `主题（AI提取）` / `主题(AI提取)` 会自动映射到 `主题`。
- `核心要点（AI提取）` / `核心要点(AI提取)` 会自动映射到 `核心要点`。
- 互动数据当前统一维护 `点赞 / 收藏 / 评论 / 转发` 四项；多维表格默认字段名为 `点赞数-抖音 / 收藏数-抖音 / 评论数-抖音 / 转发数-抖音`，其中 `转发数` 也兼容 `分享数` 类表头。

## 跨平台与调度

- 核心 Node 脚本保持一套，macOS 与 Linux 共用，不拆 skill。
- 统一调度入口是 `./scripts/run_douyin_daily_sync.sh`，调度器最终都调用它。
- 当前仓库默认由 **OpenClaw `cron/jobs.json`** 统一调度，不再推荐给这个 skill 单独安装 launchd / systemd / crontab，避免重复跑。
- 调度参数默认读取 `config/runtime.toml` 里的 `[scheduler]` 配置；其中 `hour` / `minute` 仅作为默认计划时间参考，真正生效的触发时间以 OpenClaw cron job 为准。
- OpenClaw cron 的 prompt 固定放在 `/Users/synqora/.openclaw/workspace/prompts/douyin-daily-sync.md`，job 只负责触发，不再把大段执行说明硬编码到 `jobs.json`。
- 每日调度为两阶段：① `sync_mode`（默认 `incremental`）只处理 checkpoint 未写入的**新视频**；② 若 `engagement_refresh_enabled = true`，再跑 `--refresh-engagement-recent-days`（默认天数见 `engagement_refresh_days`），仅针对**发布时间在最近 N 天**且具备本地备份的条目，拉取抖音当前点赞/收藏/评论数/转发与最多 10 条评论正文，与 `record.json` 比对（评论按规范化排序后指纹比对），**仅在有差异时**写回本地备份与多维表格；可用 `engagement_refresh_max_videos` 限制单次核对条数（`0` 为不限制）。
- 如果调度器运行时拿不到 `ARK_API_KEY`、飞书凭证、登录态等环境变量，可把变量写到 `.state/daily-sync.env`，runner 会自动加载。
- `.state/daily-sync.env` 默认不进 git，适合放客户各自的 `ARK_API_KEY` / `NODE_BIN` / `OPENCLAW_BIN` 这类本地敏感或环境相关配置。
- runner 会自动补一层常见 `PATH` 并尝试解析 `node` / `openclaw` 的绝对路径，优先顺序为：`.state/daily-sync.env` 中显式指定 -> 当前 PATH -> 常见安装目录；如果客户环境比较特殊，可在 `.state/daily-sync.env` 里显式写：
  - `NODE_BIN=/绝对路径/node`
  - `OPENCLAW_BIN=/绝对路径/openclaw`
- OpenClaw cron 的推荐做法：job 用 **isolated + agentTurn + delivery** 触发 prompt，再由 prompt 调用 runner，并把最终 `run-report.md` 直接回复在 OpenClaw 聊天界面；运行命令时加 `OPENCLAW_SKIP_NOTIFY=1`，避免 runner 末尾再额外调用 `openclaw message send`。
- `runtime.toml` 中 `openclaw_notify_enabled` 已默认关闭，保留这个开关只是兼容旧的独立调度方案；如果你已经切到 OpenClaw cron，就不要再启用 skill 自带通知。
- `./scripts/install_scheduler_macos.sh` 与 `./scripts/install_scheduler_linux.sh` 仍保留作兼容入口，但当前仓库不再推荐使用；只有在完全不接 OpenClaw cron 时才考虑它们，而且必须与 OpenClaw cron 二选一。
- 如果升级了 skill 且之前已经装过 launchd / systemd / crontab，记得重新运行对应安装脚本，让新的 PATH 配置生效。
- 当前默认日更模式是 `incremental`；如需保守一些，可把 `[scheduler] sync_mode` 改成 `recent`，再配合 `recent_count`。
- runner 每次执行都会在 `.state/runs/<run_id>/` 下落 `sync-summary.json / engagement-summary.json / run-summary.json / run-report.md`，并刷新 `.state/runs/latest.json` 与 `.state/runs/latest-report.md`。

## 历史表格字段回填

- 如果当前飞书多维表格新增了 `主题` 列，或只是修改了相关表头，可直接执行：
  - `node douyin-transcribe-to-feishu.js --backfill-bitable-fields`
- 该命令只刷新当前目标下的本地格式化产物与多维表格字段，不会重抓抖音、不会重做 ASR、不会写飞书文档。

## 当前账号级限制

- 严格日期/月份/最早补录依赖 `douyin.com` 主站登录态深分页。
- 如果没有可用的登录态文件，脚本只能退回账号首屏发现，无法对更旧日期做严格保证。
- 当前实现会在达到目标边界后主动停止，不会再用不严谨方式反推更旧数据。

## 当前文档规则

- 当前只保留 H3 标题，不追加编号。
- 文档 H3 统一使用 `日期 + #主题`。
- 如果没有可用主题，则 H3 只保留日期。
- 原始标签不再参与 H3 生成，也不再过滤固定前缀标签。
- 多维表格里的 `标签` 只保存抖音原始显式标签；没有就留空。
- 多维表格里的 `主题` 单独保存 LLM 提炼主题；如果摘要失败则留空，等待后续重跑。
- 文档中的摘要小标题统一使用 `核心要点`。

## 当前摘要链路

- 默认摘要提供方为 `auto`。
- `auto` 的顺序是：优先 Ark；若运行环境没有 `ARK_API_KEY`，或 Ark 连续失败两次，则自动回退 OpenClaw 摘要。
- 默认模型为 `doubao-seed-2-0-lite-260215`。
- Ark 摘要走 `chat/completions`，并显式关闭 thinking，确保返回内容可直接按 JSON 解析。
- 推荐运行环境提供 `ARK_API_KEY`，这样速度更快；不提供也仍可用，只是会走 OpenClaw 回退链路。
- 如需排查兼容问题，可临时设置 `SUMMARY_PROVIDER=openclaw` 切回旧链路。

## 当前转写分段规则

- 先保留 ASR 原文本中的空行分段。
- 不再按字数阈值切段。
- 不再按句号、问号、感叹号等标点主动切段。
- 仅在检测到以下结构词时开启新段：
  - `首先` `其次` `再次` `最后`
  - `第一` `第二` `第三` `第四` `第五`
  - `第一点` `第二点` `第三点` `第四点` `第五点`
  - `总结一下` `所以` `举个例子` `换个角度`
- 如果全文没有这些结构词，则保持单段，不做猜测性拆分。

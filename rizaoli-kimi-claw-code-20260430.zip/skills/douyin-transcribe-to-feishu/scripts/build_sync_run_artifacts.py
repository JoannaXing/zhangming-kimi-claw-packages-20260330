#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path


def load_json(path: str) -> dict:
    if not path:
        return {}
    file_path = Path(path)
    if not file_path.exists():
        return {}
    try:
        return json.loads(file_path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def write_json(path: str, payload: dict) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def write_text(path: str, content: str) -> None:
    file_path = Path(path)
    file_path.parent.mkdir(parents=True, exist_ok=True)
    file_path.write_text(content.rstrip() + "\n", encoding="utf-8")


def format_display_status(status: str) -> str:
    mapping = {
        "success": "成功",
        "success_with_warnings": "成功（有告警）",
        "partial_failure": "部分失败",
        "failed": "失败",
        "skipped": "跳过",
        "noop": "成功",
        "not_run": "成功",
    }
    return mapping.get(str(status or "").strip(), "失败")


def load_log_lines(path: str) -> list[str]:
    if not path:
        return []
    file_path = Path(path)
    if not file_path.exists():
        return []
    try:
        return file_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []


def stage_log_lines(log_lines: list[str], operation: str) -> list[str]:
    if not log_lines:
        return []
    engagement_marker = "engagement-recent-diff start"
    if operation == "sync":
        for index, line in enumerate(log_lines):
            if engagement_marker in line:
                return log_lines[:index]
        return log_lines
    if operation == "refresh_engagement_recent_diff":
        for index, line in enumerate(log_lines):
            if engagement_marker in line:
                return log_lines[index:]
        return log_lines
    return log_lines


def extract_stage_failure_message(log_lines: list[str], operation: str) -> str:
    lines = stage_log_lines(log_lines, operation)
    if not lines:
        return ""
    for raw_line in reversed(lines):
        line = raw_line.strip()
        if not line:
            continue
        if line.startswith(("Error:", "TypeError:", "ReferenceError:", "SyntaxError:")):
            return line
        if "失败:" in line:
            return line.split("失败:", 1)[1].strip() or line
    return ""


def normalize_stage(
    payload: dict,
    operation: str,
    exit_code: int,
    *,
    ran: bool = True,
    log_lines: list[str] | None = None,
) -> dict:
    if payload:
        payload = dict(payload)
        payload.setdefault("operation", operation)
        payload.setdefault("status", "success" if exit_code == 0 else "failed")
        return payload
    if not ran:
        return {
            "schemaVersion": 1,
            "generatedAt": datetime.now().isoformat(),
            "operation": operation,
            "status": "not_run",
            "message": "",
            "counts": {},
        }
    return {
        "schemaVersion": 1,
        "generatedAt": datetime.now().isoformat(),
        "operation": operation,
        "status": "failed" if exit_code != 0 else "partial_failure",
        "message": extract_stage_failure_message(log_lines or [], operation) or "阶段未产出结构化 summary",
        "counts": {},
    }


def overall_status(sync_stage: dict, engagement_stage: dict) -> str:
    statuses = [sync_stage.get("status", ""), engagement_stage.get("status", "")]
    if any(status == "failed" for status in statuses):
        if any(status in {"success", "noop", "partial_failure"} for status in statuses if status != "failed"):
            return "partial_failure"
        return "failed"
    if any(status == "partial_failure" for status in statuses):
        return "partial_failure"
    if any(status == "success_with_warnings" for status in statuses):
        return "success_with_warnings"
    if int((engagement_stage.get("counts") or {}).get("docUpdateFailed", 0)) > 0:
        return "success_with_warnings"
    for item in sync_stage.get("results") or []:
        item_status = str(item.get("status") or "").strip()
        summary_status = str(item.get("summaryStatus") or "").strip()
        if item_status == "success_with_warnings":
            return "success_with_warnings"
        if item.get("warnings"):
            return "success_with_warnings"
        if summary_status in {"failed", "partial", "deferred"}:
            return "success_with_warnings"
    return "success"


def is_success_like_status(status: str) -> bool:
    return str(status or "").strip() in {"success", "success_with_warnings"}


def is_reportable_new_video(item: dict) -> bool:
    if not is_success_like_status(item.get("status", "")):
        return False
    validation = item.get("validation") or {}
    if validation.get("passed") is not True:
        return False
    checklist_status = str(validation.get("checklistStatus") or "").strip()
    item_status = str(item.get("status") or "").strip()
    dedupe_status = str(item.get("dedupeStatus") or "").strip()
    if checklist_status in {"duplicate_skipped", "silence_skipped"}:
        return False
    if item_status in {"duplicate_skipped", "silence_skipped"}:
        return False
    if dedupe_status == "duplicate":
        return False
    return True


def canonical_written_items(sync_stage: dict) -> list[dict]:
    items = [item for item in (sync_stage.get("results") or []) if is_reportable_new_video(item)]
    return sorted(
        items,
        key=lambda item: (
            str(item.get("publishTime") or ""),
            str(item.get("videoId") or ""),
        ),
        reverse=True,
    )


def duplicate_skipped_count(sync_stage: dict) -> int:
    total = 0
    for item in sync_stage.get("results") or []:
        validation = item.get("validation") or {}
        checklist_status = str(validation.get("checklistStatus") or "").strip()
        item_status = str(item.get("status") or "").strip()
        dedupe_status = str(item.get("dedupeStatus") or "").strip()
        if checklist_status == "duplicate_skipped" or item_status == "duplicate_skipped" or dedupe_status == "duplicate":
            total += 1
    return total


def sync_counts(sync_stage: dict) -> tuple[int, int, int]:
    counts = sync_stage.get("counts") or {}
    success_like_total = len(canonical_written_items(sync_stage))
    validated_written = success_like_total
    validation_failed = int(counts.get("validationFailed", 0))
    return success_like_total, validated_written, validation_failed


def build_index_line(sync_stage: dict) -> str:
    success_like_total, validated_written, validation_failed = sync_counts(sync_stage)
    if sync_stage.get("status") == "noop":
        return "索引闭环：本轮无新增视频，无需写入闭环校验"
    if success_like_total <= 0:
        return "索引闭环：本轮未形成成功写入"
    if validation_failed <= 0:
        return (
            f"索引闭环：已验证 {validated_written}/{success_like_total} 条新增视频完成 "
            "checkpoint、write-index、catalog、checklist、本地备份"
        )
    return (
        f"索引闭环：已验证 {validated_written}/{success_like_total} 条新增视频完成闭环，"
        f"异常 {validation_failed} 条"
    )


def build_engagement_line(stage: dict) -> str:
    status = str(stage.get("status") or "").strip()
    counts = stage.get("counts") or {}
    updated = int(counts.get("updated", 0))
    if status == "not_run":
        return "近7天互动核对：本轮未执行"
    if status == "noop":
        return "近7天互动核对：本轮无可核对视频"
    if updated > 0:
        return "近7天互动核对："
    return "近7天互动核对：无更新"


def build_engagement_doc_line(stage: dict) -> str:
    counts = stage.get("counts") or {}
    updated = int(counts.get("docUpdated", 0))
    failed = int(counts.get("docUpdateFailed", 0))
    if updated <= 0 and failed <= 0:
        return ""
    if failed > 0:
        return f"文档互动回写：已更新{updated}条；失败{failed}条"
    return f"文档互动回写：已更新{updated}条"


def build_engagement_detail_lines(stage: dict) -> list[str]:
    items = list(stage.get("updatedItems") or [])
    if not items:
        return []

    lines = []
    for item in items:
        publish_date = str(item.get("publishDate") or "").strip() or "日期未知"
        topic = str(item.get("topic") or item.get("title") or "").strip() or "无主题"
        video_id = str(item.get("videoId") or "").strip() or "未知视频"
        changes = [str(entry).strip() for entry in (item.get("changes") or []) if str(entry).strip()]
        change_text = "，".join(changes[:3]) if changes else "评论与互动已刷新"
        lines.append(f"- {publish_date} | {topic} | 视频ID {video_id} | {change_text}")
    return lines


def build_video_lines(sync_stage: dict) -> tuple[list[str], str]:
    reportable_items = canonical_written_items(sync_stage)
    if not reportable_items:
        return ["新增视频：0 条"], ""
    lines = [f"新增视频：{len(reportable_items)} 条"]
    for item in reportable_items[:3]:
        publish_date = str(item.get("publishDate") or "") or "待从日志补充"
        topic = str(item.get("topic") or item.get("title") or "").strip() or "无"
        video_id = str(item.get("videoId") or "").strip() or "待从日志补充"
        lines.append(f"- {publish_date} | {topic} | 视频ID {video_id}")
    first_link = str(reportable_items[0].get("link") or "").strip()
    if not first_link:
        first_video_id = str(reportable_items[0].get("videoId") or "").strip()
        if first_video_id:
            first_link = f"https://www.douyin.com/video/{first_video_id}"
    return lines, first_link or "无"


def build_duplicate_line(sync_stage: dict) -> str:
    duplicate_count = duplicate_skipped_count(sync_stage)
    if duplicate_count <= 0:
        return ""
    return f"重复内容跳过：{duplicate_count} 条"


def first_sync_problem(sync_stage: dict) -> str:
    stage_status = str(sync_stage.get("status") or "").strip()
    if stage_status in {"success", "noop", "not_run"}:
        has_failed_result = any(item.get("status") == "failed" for item in sync_stage.get("results") or [])
        has_validation_issue = any(
            item.get("status") in {"success", "success_with_warnings"}
            and (item.get("validation") or {}).get("passed") is not True
            for item in sync_stage.get("results") or []
        )
        if not has_failed_result and not has_validation_issue:
            return ""
    for item in sync_stage.get("results") or []:
        if item.get("status") == "failed":
            stage = str(item.get("failedStage") or "未知阶段").strip()
            video_id = str(item.get("videoId") or "").strip()
            if video_id:
                return f"{stage} | 视频ID {video_id}"
            return stage
    for item in sync_stage.get("results") or []:
        validation = item.get("validation") or {}
        status = str(item.get("status") or "").strip()
        if status in {"success", "success_with_warnings"} and validation.get("passed") is not True:
            video_id = str(item.get("videoId") or "").strip()
            return f"索引闭环未完成 | 视频ID {video_id or '未知'}"
    message = str(sync_stage.get("message") or "").strip()
    return message


def first_engagement_problem(engagement_stage: dict) -> str:
    status = str(engagement_stage.get("status") or "").strip()
    if status in {"failed", "partial_failure"}:
        message = str(engagement_stage.get("message") or "").strip()
        return message or "近7天互动核对失败"
    return ""


def build_exception_line(sync_stage: dict, engagement_stage: dict) -> str:
    problems = []
    sync_problem = first_sync_problem(sync_stage)
    if sync_problem:
        problems.append(sync_problem)
    engagement_problem = first_engagement_problem(engagement_stage)
    if engagement_problem:
        problems.append(engagement_problem)
    if not problems:
        return ""
    return f"异常摘要：{'；'.join(problems)}"


def build_sync_warning_fragment(sync_stage: dict) -> str:
    for item in sync_stage.get("results") or []:
        warnings = [str(entry).strip() for entry in (item.get("warnings") or []) if str(entry).strip()]
        if not warnings:
            continue
        video_id = str(item.get("videoId") or "").strip() or "未知"
        return f"视频ID {video_id} | {'；'.join(warnings[:2])}"
    return ""


def build_engagement_warning_fragment(stage: dict) -> str:
    counts = stage.get("counts") or {}
    failed = int(counts.get("docUpdateFailed", 0))
    if failed <= 0:
        return ""
    item = next(iter(stage.get("docUpdateFailedItems") or []), {}) or {}
    video_id = str(item.get("videoId") or "").strip() or "未知"
    topic = str(item.get("topic") or item.get("title") or "").strip()
    error = str(item.get("error") or "").strip()
    detail = topic or error or "文档互动回写失败"
    return f"文档互动回写失败 {failed} 条 | 视频ID {video_id} | {detail}"


def build_warning_line(sync_stage: dict, engagement_stage: dict) -> str:
    fragments = []
    sync_fragment = build_sync_warning_fragment(sync_stage)
    if sync_fragment:
        fragments.append(sync_fragment)
    engagement_fragment = build_engagement_warning_fragment(engagement_stage)
    if engagement_fragment:
        fragments.append(engagement_fragment)
    if not fragments:
        return ""
    return f"告警摘要：{'；'.join(fragments[:2])}"


def build_report(sync_stage: dict, engagement_stage: dict, log_path: str) -> str:
    run_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    report_lines = [
        "🎬 视频知识库日更简报",
        f"执行时间：{run_time}",
        f"执行状态：{format_display_status(overall_status(sync_stage, engagement_stage))}",
    ]
    new_video_lines, first_link = build_video_lines(sync_stage)
    report_lines.extend(new_video_lines)
    duplicate_line = build_duplicate_line(sync_stage)
    if duplicate_line:
        report_lines.append(duplicate_line)
    if first_link:
        report_lines.append(f"抖音链接：{first_link}")
    report_lines.append(build_engagement_line(engagement_stage))
    engagement_details = build_engagement_detail_lines(engagement_stage)
    if engagement_details:
        updated = int((engagement_stage.get("counts") or {}).get("updated", 0))
        report_lines.append(f"更新{updated}条视频数据：")
        report_lines.extend(engagement_details)
    warning_line = build_warning_line(sync_stage, engagement_stage)
    if warning_line:
        report_lines.append(warning_line)
    exception_line = build_exception_line(sync_stage, engagement_stage)
    if exception_line:
        report_lines.append(exception_line)
    return "\n".join(report_lines)


def main() -> int:
    parser = argparse.ArgumentParser(description="Build combined Douyin sync artifacts.")
    parser.add_argument("--sync-summary", required=True)
    parser.add_argument("--engagement-summary", required=True)
    parser.add_argument("--sync-exit", type=int, default=0)
    parser.add_argument("--engagement-exit", type=int, default=0)
    parser.add_argument("--engagement-ran", type=int, default=0)
    parser.add_argument("--log-file", required=True)
    parser.add_argument("--out-summary", required=True)
    parser.add_argument("--out-report", required=True)
    parser.add_argument("--run-id", default="")
    args = parser.parse_args()

    log_lines = load_log_lines(args.log_file)
    sync_stage = normalize_stage(
        load_json(args.sync_summary),
        "sync",
        args.sync_exit,
        ran=True,
        log_lines=log_lines,
    )
    engagement_stage = normalize_stage(
        load_json(args.engagement_summary),
        "refresh_engagement_recent_diff",
        args.engagement_exit,
        ran=bool(args.engagement_ran),
        log_lines=log_lines,
    )
    combined_status = overall_status(sync_stage, engagement_stage)
    report = build_report(sync_stage, engagement_stage, args.log_file)

    combined_summary = {
        "schemaVersion": 1,
        "generatedAt": datetime.now().isoformat(),
        "runId": args.run_id,
        "status": combined_status,
        "logFile": args.log_file,
        "stages": {
            "sync": sync_stage,
            "engagement": engagement_stage,
        },
        "report": report,
    }

    write_json(args.out_summary, combined_summary)
    write_text(args.out_report, report)
    print(report)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

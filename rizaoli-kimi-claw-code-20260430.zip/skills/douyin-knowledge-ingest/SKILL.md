---
name: douyin-knowledge-ingest
description: 按知识库 profile 运行抖音转写入库，复用现有 douyin-transcribe-to-feishu 能力，并把产物同步到统一知识库目录；支持日常定时同步和 legacy 备份导入
metadata:
  openclaw:
    emoji: 📼
    requires:
      bins: [node, python3]
---

# douyin-knowledge-ingest

用于按 profile 包装现有 [douyin-transcribe-to-feishu](../douyin-transcribe-to-feishu/SKILL.md)，并把转写结果同步到 `knowledge-bases/<profile>/storage/records`。

## 用法

```bash
python3 douyin_knowledge_ingest.py --profile rizaoli-douyin --scheduled
python3 douyin_knowledge_ingest.py --profile rizaoli-douyin --sync-incremental
python3 douyin_knowledge_ingest.py --profile rizaoli-douyin 7564405121091505462
python3 douyin_knowledge_ingest.py --profile rizaoli-douyin --import-legacy --sync-only
```

## 说明

- `--scheduled` 会读取 `knowledge-bases/<profile>/scheduler.toml`
- 运行完成后会自动把 source 备份同步到 profile 自己的统一知识库目录
- `--import-legacy` 只在同步阶段额外导入旧 skill 的历史备份

## 交付与回帖策略

这条链路既面向定时同步，也会被聊天里的知识库任务直接调用。执行时先分两类：

### 轻任务

- 单条抖音视频入库
- 单条轻量重写
- 预计 `30s` 内能收口的任务

这类任务优先前台执行，拿到终态再回复。

### 长任务

- 批量同步
- engagement refresh
- backfill / reconcile
- 大文档重写
- 任何明显会超过 `30s` 的链路

这类任务默认不要卡住当前聊天，优先走 OpenClaw 现成的 `subagent / isolated` 完工回报链路，让完成或失败自动回到原飞书聊天。

额外要求：

- 没有可靠完工回帖链路时，不要裸后台化
- 不要只回复“已开始处理”，把终态交付留给用户自己追问
- 如果知识库、飞书文档、多维表已经写成，但聊天里没自动给结果说明，这次体验仍算未闭环

#!/usr/bin/env node
/**
 * douyin-transcribe-to-feishu
 * 抖音视频转写 -> 标准化 -> 写入飞书文档/多维表格 -> checkpoint
 */

const { execFileSync, spawn } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');
const axiosModule = require('axios');

const douyin = require('./lib/douyin.js');
const feishu = require('./lib/feishu_client.js');
const axios = axiosModule.default || axiosModule;

const SKILL_DIR = __dirname;
const LIB_DIR = path.join(SKILL_DIR, 'lib');
const CONFIG_PATH = path.join(SKILL_DIR, 'config', 'runtime.toml');
const TEXT_CORRECTIONS_PATH = (() => {
  const configured = String(
    process.env.DOUYIN_TEXT_CORRECTIONS_PATH ||
      process.env.KNOWLEDGE_BASE_TEXT_CORRECTIONS_PATH ||
      path.join(SKILL_DIR, 'config', 'text-corrections.json'),
  ).trim();
  return path.isAbsolute(configured) ? configured : path.join(SKILL_DIR, configured);
})();
const DEFAULT_DOUYIN_STORAGE_STATE_PATH = path.join(
  SKILL_DIR,
  '.state',
  'douyin-storage-state.json',
);
const PYTHON_BIN = fs.existsSync(path.join(SKILL_DIR, '.venv', 'bin', 'python'))
  ? path.join(SKILL_DIR, '.venv', 'bin', 'python')
  : 'python3';

function run(cmd, args, options = {}) {
  return execFileSync(cmd, args, { encoding: 'utf-8', ...options });
}

function runPython(args, options = {}) {
  return run(PYTHON_BIN, args, options);
}

function parseTomlSimple(content) {
  const out = {};
  let cur = out;
  for (const raw of content.split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const sec = line.match(/^\[(.+)]$/);
    if (sec) {
      cur = out;
      for (const part of sec[1].split('.')) {
        cur[part] = cur[part] || {};
        cur = cur[part];
      }
      continue;
    }
    const kv = line.match(/^([A-Za-z0-9_]+)\s*=\s*"?(.*?)"?$/);
    if (kv) cur[kv[1]] = kv[2];
  }
  return out;
}

const CONFIG = parseTomlSimple(fs.readFileSync(CONFIG_PATH, 'utf-8'));
const SUMMARY_ENABLED = String(CONFIG.summary?.enabled || 'true') !== 'false';
const SUMMARY_MODE = String(CONFIG.summary?.mode || 'pre_write').trim() || 'pre_write';
const SUMMARY_TIMEOUT_SECONDS = Number(CONFIG.summary?.timeout_seconds || 120);
const SUMMARY_THINKING = CONFIG.summary?.thinking || 'minimal';
const SUMMARY_PROVIDER = String(
  process.env.SUMMARY_PROVIDER ||
    CONFIG.summary?.provider ||
    (process.env.ARK_API_KEY ? 'ark' : 'openclaw'),
)
  .trim()
  .toLowerCase();
const SUMMARY_TEMPERATURE = Number(CONFIG.summary?.temperature || 0);
const ARK_API_KEY = String(process.env.ARK_API_KEY || CONFIG.summary?.ark_api_key || '').trim();
const ARK_BASE_URL = String(
  process.env.ARK_BASE_URL || CONFIG.summary?.ark_base_url || 'https://ark.cn-beijing.volces.com/api/v3',
)
  .trim()
  .replace(/\/+$/g, '');
const ARK_SUMMARY_MODEL = String(
  process.env.ARK_SUMMARY_MODEL ||
    process.env.ARK_MODEL ||
    CONFIG.summary?.ark_model ||
    'doubao-seed-2-0-lite-260215',
)
  .trim();
const ARK_SUMMARY_MAX_TOKENS = Math.max(128, Number(CONFIG.summary?.ark_max_tokens || 320));
const DEFAULT_PROGRESS_FIRST_HEARTBEAT_SECONDS = Math.max(
  10,
  Number(CONFIG.progress?.first_heartbeat_seconds || CONFIG.progress?.heartbeat_seconds || 15),
);
const DEFAULT_PROGRESS_REPEAT_HEARTBEAT_SECONDS = Math.max(
  DEFAULT_PROGRESS_FIRST_HEARTBEAT_SECONDS,
  Number(CONFIG.progress?.repeat_heartbeat_seconds || CONFIG.progress?.heartbeat_seconds || 30),
);
const RETRY_METADATA_ATTEMPTS = Math.max(1, Number(CONFIG.retry?.metadata_attempts || 3));
const RETRY_METADATA_DELAY_MS = Math.max(0, Number(CONFIG.retry?.metadata_delay_seconds || 2) * 1000);
const RETRY_SUMMARY_ATTEMPTS = Math.max(1, Number(CONFIG.retry?.summary_attempts || 2));
const RETRY_SUMMARY_DELAY_MS = Math.max(0, Number(CONFIG.retry?.summary_delay_seconds || 3) * 1000);
const RETRY_FEISHU_DOC_ATTEMPTS = Math.max(1, Number(CONFIG.retry?.feishu_doc_attempts || 3));
const RETRY_FEISHU_DOC_DELAY_MS = Math.max(0, Number(CONFIG.retry?.feishu_doc_delay_seconds || 5) * 1000);
const RETRY_FEISHU_BITABLE_ATTEMPTS = Math.max(
  1,
  Number(CONFIG.retry?.feishu_bitable_attempts || 3),
);
const RETRY_FEISHU_BITABLE_DELAY_MS = Math.max(
  0,
  Number(CONFIG.retry?.feishu_bitable_delay_seconds || 3) * 1000,
);
const FEISHU_DOC_MIN_INTERVAL_MS = Math.max(
  0,
  Number(CONFIG.doc_write?.min_interval_seconds || 2) * 1000,
);
const FEISHU_DOC_BATCH_MIN_INTERVAL_MS = Math.max(
  FEISHU_DOC_MIN_INTERVAL_MS,
  Number(CONFIG.doc_write?.batch_min_interval_seconds || 8) * 1000,
);
const FEISHU_DOC_BATCH_SIZE = Math.max(1, Number(CONFIG.doc_write?.batch_size || 10));
const STOP_ON_FEISHU_DOC_RATE_LIMIT = String(CONFIG.doc_write?.stop_on_rate_limit || 'true') !== 'false';
const BACKFILL_DOC_PENDING_DEFAULT_LIMIT = Math.max(
  1,
  Number(CONFIG.doc_write?.backfill_pending_limit || 5),
);
const FEISHU_DOC_WRITE_TIMEOUT_MS = Math.max(
  15000,
  Number(CONFIG.doc_write?.write_timeout_seconds || 90) * 1000,
);
const ACCOUNT_SEC_UID = String(CONFIG.account?.sec_uid || '').trim();
const ACCOUNT_PROFILE_URL = String(CONFIG.account?.profile_url || '').trim();
const ACCOUNT_VISIBLE_DISCOVERY_LIMIT = Math.max(1, Number(CONFIG.account?.visible_limit || 15));
const ACCOUNT_DEEP_DISCOVERY_MAX_PAGES = Math.max(
  1,
  Number(CONFIG.account?.deep_discovery_max_pages || 200),
);
const BACKUP_ENABLED_BY_DEFAULT = String(CONFIG.backup?.enabled || 'true') !== 'false';
const DEFAULT_STATE_DIR = resolveSkillPath('.state');
const DEFAULT_CHECKPOINT_DIR = resolveSkillPath(
  CONFIG.run?.checkpoint_dir || path.join(DEFAULT_STATE_DIR, 'checkpoints'),
);
const DEFAULT_CHECKPOINT_FILE = String(
  CONFIG.run?.checkpoint_file || 'douyin-transcribe-to-feishu.json',
)
  .trim() || 'douyin-transcribe-to-feishu.json';
const DEFAULT_CHECKPOINT_PATH = path.join(DEFAULT_CHECKPOINT_DIR, DEFAULT_CHECKPOINT_FILE);
const DEFAULT_BACKUP_DIR = BACKUP_ENABLED_BY_DEFAULT
  ? resolveSkillPath(CONFIG.backup?.output_dir || '.local-backups')
  : '';
const DEFAULT_INDEX_LOG_PATH = resolveSkillPath(
  CONFIG.logging?.index_log_path || path.join(DEFAULT_CHECKPOINT_DIR, 'write-index.jsonl'),
);
const DEDUPE_ENABLED = String(CONFIG.dedupe?.enabled || 'true') !== 'false';
const DEDUPE_MIN_TRANSCRIPT_CHARS = Math.max(
  50,
  Number(CONFIG.dedupe?.min_transcript_chars || 120),
);
const DEDUPE_MIN_SIMILARITY = Math.min(
  1,
  Math.max(0.9, Number(CONFIG.dedupe?.min_similarity || 0.995)),
);
const DEDUPE_MAX_LENGTH_RATIO_DELTA = Math.min(
  0.2,
  Math.max(0, Number(CONFIG.dedupe?.max_length_ratio_delta || 0.03)),
);
let activeFirstHeartbeatSeconds = DEFAULT_PROGRESS_FIRST_HEARTBEAT_SECONDS;
let activeRepeatHeartbeatSeconds = DEFAULT_PROGRESS_REPEAT_HEARTBEAT_SECONDS;
let feishuDocCooldownUntilMs = 0;
let feishuDocNextWritableAtMs = 0;
const TEXT_CORRECTIONS = loadTextCorrections(TEXT_CORRECTIONS_PATH);

function loadTextCorrections(filePath) {
  if (!fs.existsSync(filePath)) {
    return [];
  }
  const raw = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  const replacements = raw?.replacements && typeof raw.replacements === 'object' ? raw.replacements : {};
  return Object.entries(replacements)
    .map(([from, to]) => [String(from || ''), String(to || '')])
    .filter(([from, to]) => from && to && from !== to)
    .sort((left, right) => right[0].length - left[0].length)
    .map(([from, to]) => ({ from, to }));
}

function applyTextCorrections(text) {
  let output = String(text || '');
  for (const item of TEXT_CORRECTIONS) {
    output = output.split(item.from).join(item.to);
  }
  return output;
}

function applyTextCorrectionsToRecord(record) {
  if (!record || typeof record !== 'object') {
    return record;
  }
  record.title = applyTextCorrections(record.title || '');
  record.topic = applyTextCorrections(record.topic || '');
  record.transcript = applyTextCorrections(record.transcript || '');
  record.comments = (Array.isArray(record.comments) ? record.comments : []).map((item) =>
    applyTextCorrections(item),
  );
  record.keyPoints = (Array.isArray(record.keyPoints) ? record.keyPoints : []).map((item) =>
    applyTextCorrections(item),
  );
  return record;
}

function stripCodeFence(text) {
  const value = String(text || '').trim();
  const fenced = value.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  return fenced ? fenced[1].trim() : value;
}

function parseJsonFromOutput(raw) {
  const text = String(raw || '').trim();
  const start = text.indexOf('{');
  if (start < 0) {
    throw new Error('OpenClaw 摘要输出中未找到 JSON');
  }
  return JSON.parse(text.slice(start));
}

function formatElapsedMs(ms) {
  const totalSeconds = Math.max(0, Math.round(ms / 1000));
  if (totalSeconds < 60) {
    return `${totalSeconds} 秒`;
  }
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  return secs ? `${mins} 分 ${secs} 秒` : `${mins} 分`;
}

function withTimeout(promise, timeoutMs, label) {
  const effectiveTimeoutMs = Math.max(1, Number(timeoutMs) || 0);
  if (!effectiveTimeoutMs) {
    return promise;
  }
  let timer = null;
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => {
      reject(new Error(`${label || '操作'}超时（>${formatElapsedMs(effectiveTimeoutMs)}）`));
    }, effectiveTimeoutMs);
  });
  return Promise.race([promise, timeoutPromise]).finally(() => {
    if (timer) {
      clearTimeout(timer);
    }
  });
}

function nowClock() {
  // 业务日志统一用 Asia/Shanghai 墙钟，避免 toISOString() 误显示为 UTC
  return new Date().toLocaleString('sv-SE', { timeZone: 'Asia/Shanghai' }).slice(11, 19);
}

function logProgress(prefix, message) {
  console.log(`[${nowClock()}]${prefix} ${message}`);
}

function buildStepPrefix(positionLabel, videoId = '') {
  return `${positionLabel ? `[${positionLabel}]` : ''}${videoId ? `[${videoId}]` : ''}`;
}

function getApiErrorPayload(err) {
  return err?.response?.data || err?.data || null;
}

function normalizeResponseHeaders(headers) {
  const out = {};
  for (const [key, value] of Object.entries(headers || {})) {
    const normalizedKey = String(key || '').toLowerCase().trim();
    if (!normalizedKey) continue;
    out[normalizedKey] = Array.isArray(value) ? value[0] : value;
  }
  return out;
}

function parseRateLimitResetDelayMs(value) {
  if (value === undefined || value === null || value === '') return null;
  const raw = Number(value);
  if (!Number.isFinite(raw)) return null;
  if (raw > 1e12) {
    return Math.max(0, raw - Date.now());
  }
  if (raw > 1e9) {
    return Math.max(0, raw * 1000 - Date.now());
  }
  return Math.max(0, Math.ceil(raw) * 1000);
}

function getFeishuRateLimitInfo(err) {
  const payload = getApiErrorPayload(err);
  const headers = normalizeResponseHeaders(err?.response?.headers || err?.headers || {});
  const resetDelayMs =
    err?.rateLimitInfo?.resetDelayMs ?? parseRateLimitResetDelayMs(headers['x-ogw-ratelimit-reset']);
  const limit = String(
    err?.rateLimitInfo?.limit || headers['x-ogw-ratelimit-limit'] || '',
  ).trim();
  const logId = String(
    err?.rateLimitInfo?.logId || payload?.log_id || headers['x-tt-logid'] || '',
  ).trim();
  return {
    limit,
    logId,
    resetDelayMs,
    resetSeconds: resetDelayMs === null ? null : Math.ceil(resetDelayMs / 1000),
  };
}

function isFeishuRateLimitError(err) {
  const payload = getApiErrorPayload(err);
  if (
    Number(payload?.code) === 99991400 ||
    String(payload?.msg || '').includes('request trigger frequency limit')
  ) {
    return true;
  }
  const headers = normalizeResponseHeaders(err?.response?.headers || err?.headers || {});
  const text = `${JSON.stringify(payload || '')}\n${JSON.stringify(headers || {})}`;
  return text.includes('99991400') || text.includes('request trigger frequency limit');
}

function getAdaptiveRetryDelayMs(err, attempt, baseDelayMs) {
  if (!isFeishuRateLimitError(err)) {
    return baseDelayMs;
  }
  const info = getFeishuRateLimitInfo(err);
  if (info.resetDelayMs !== null) {
    return Math.max(baseDelayMs, info.resetDelayMs);
  }
  return Math.max(baseDelayMs, Math.min(120000, 15000 * attempt));
}

function noteFeishuDocRateLimit(err) {
  if (!isFeishuRateLimitError(err)) {
    return;
  }
  const delayMs = Math.max(
    30000,
    getAdaptiveRetryDelayMs(err, 1, Math.max(RETRY_FEISHU_DOC_DELAY_MS, 15000)),
  );
  const nextAt = Date.now() + delayMs;
  feishuDocCooldownUntilMs = Math.max(feishuDocCooldownUntilMs, nextAt);
  feishuDocNextWritableAtMs = Math.max(feishuDocNextWritableAtMs, nextAt);
}

async function waitForFeishuDocCooldown(prefix, label) {
  const waitUntilMs = Math.max(feishuDocCooldownUntilMs, feishuDocNextWritableAtMs);
  const delayMs = waitUntilMs - Date.now();
  if (delayMs <= 0) {
    feishuDocNextWritableAtMs = Date.now();
    return;
  }
  logProgress(prefix, `${label}前等待飞书写入窗口，约 ${formatElapsedMs(delayMs)}`);
  await sleep(delayMs);
}

async function waitForFeishuDocWriteWindow(prefix, label, minIntervalMs = FEISHU_DOC_MIN_INTERVAL_MS) {
  await waitForFeishuDocCooldown(prefix, label);
  feishuDocNextWritableAtMs = Math.max(feishuDocNextWritableAtMs, Date.now()) + Math.max(0, minIntervalMs);
}

function formatError(err) {
  const payload = getApiErrorPayload(err);
  if (
    Number(payload?.code) === 99991400 ||
    String(payload?.msg || '').includes('request trigger frequency limit')
  ) {
    const info = getFeishuRateLimitInfo(err);
    const resetText =
      info.resetSeconds !== null ? `，建议等待约 ${info.resetSeconds} 秒` : '';
    const logIdText = info.logId ? `，log_id=${info.logId}` : '';
    return `飞书写入限频（99991400 request trigger frequency limit），请稍后再试${resetText}${logIdText}`;
  }

  const parts = [];
  if (err instanceof Error && err.message) {
    parts.push(err.message);
  } else if (err !== undefined && err !== null) {
    parts.push(String(err));
  }

  if (payload?.code) {
    parts.push(`code ${payload.code}`);
  }
  if (payload?.msg) {
    parts.push(String(payload.msg));
  }

  return [...new Set(parts.filter(Boolean))].join(' | ');
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function parsePublishTimestamp(value) {
  const normalized = String(value || '').trim();
  if (!normalized) return null;
  const full = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(normalized)
    ? `${normalized}:00`
    : normalized;
  const iso = /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(full)
    ? full.replace(' ', 'T') + '+08:00'
    : /^\d{4}-\d{2}-\d{2}$/.test(full)
      ? `${full}T00:00:00+08:00`
      : '';
  if (!iso) return null;
  const timestamp = Date.parse(iso);
  return Number.isNaN(timestamp) ? null : timestamp;
}

function getPublishDate(value) {
  const normalized = String(value || '').trim();
  return /^\d{4}-\d{2}-\d{2}/.test(normalized) ? normalized.slice(0, 10) : '';
}

function getPublishMonth(value) {
  const date = getPublishDate(value);
  return date ? date.slice(0, 7) : '';
}

function buildWriteTarget(args) {
  return {
    docToken: String(args.docToken || '').trim(),
    bitableAppToken: String(args.bitableAppToken || '').trim(),
    bitableTableId: String(args.bitableTableId || '').trim(),
  };
}

function buildWriteTargetSignature(target) {
  return [target.docToken, target.bitableAppToken, target.bitableTableId].join('::');
}

function resolveSkillPath(value, fallback = '') {
  const candidate = String(value || fallback || '').trim();
  if (!candidate) return '';
  return path.isAbsolute(candidate) ? candidate : path.resolve(SKILL_DIR, candidate);
}

function resolveGenericPath(value, fallback = '') {
  const candidate = String(value || fallback || '').trim();
  if (!candidate) return '';
  return path.isAbsolute(candidate) ? candidate : path.resolve(candidate);
}

function buildWriteTargetKey(target) {
  return `${target.docToken}|${target.bitableAppToken}|${target.bitableTableId}`;
}

function buildCheckpointTargetPatch(target) {
  return {
    target: {
      docToken: target.docToken,
      bitableAppToken: target.bitableAppToken,
      bitableTableId: target.bitableTableId,
    },
    targetSignature: buildWriteTargetSignature(target),
  };
}

function matchesCheckpointTarget(item, targetSignature) {
  return String(item?.targetSignature || '').trim() === String(targetSignature || '').trim();
}

function normalizeDocSequence(value) {
  const number = Number(value);
  return Number.isInteger(number) && number > 0 ? number : null;
}

function parseDocSequenceFromHeading(headingText) {
  const match = String(headingText || '')
    .trim()
    .match(/（第\s*(\d+)\s*条）\s*$/u);
  return match ? normalizeDocSequence(match[1]) : null;
}

function getCheckpointDocSequence(item, targetSignature) {
  if (!matchesCheckpointTarget(item, targetSignature)) {
    return null;
  }
  return normalizeDocSequence(item?.docSequence);
}

function getMaxDocSequence(sections) {
  return (Array.isArray(sections) ? sections : []).reduce((max, section) => {
    const sequence = parseDocSequenceFromHeading(section?.headingText);
    return sequence ? Math.max(max, sequence) : max;
  }, 0);
}

function allocateDocSequenceForExistingSection(sections, existingRange) {
  const ranges = Array.isArray(sections) ? sections : [];
  const targetStartIndex = Number.isInteger(existingRange?.startIndex) ? existingRange.startIndex : null;
  const targetHeading = String(existingRange?.headingText || '').trim();
  const currentIndex = ranges.findIndex(
    (section) =>
      (targetStartIndex !== null && section?.startIndex === targetStartIndex) ||
      (targetHeading && String(section?.headingText || '').trim() === targetHeading),
  );
  if (currentIndex < 0) {
    return null;
  }

  const usedSequences = new Set(
    ranges.map((section) => parseDocSequenceFromHeading(section?.headingText)).filter(Boolean),
  );
  const preferred = Math.max(1, ranges.length - currentIndex);
  if (!usedSequences.has(preferred)) {
    return preferred;
  }

  for (let candidate = preferred - 1; candidate >= 1; candidate -= 1) {
    if (!usedSequences.has(candidate)) {
      return candidate;
    }
  }

  let candidate = preferred + 1;
  while (usedSequences.has(candidate)) {
    candidate += 1;
  }
  return candidate;
}

async function resolveDocSequence(client, args, checkpoint, videoId, existingRange = null) {
  if (!args.docToken) {
    return null;
  }

  const existingSequence = parseDocSequenceFromHeading(existingRange?.headingText);
  if (existingSequence) {
    return existingSequence;
  }

  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  const checkpointSequence = getCheckpointDocSequence(checkpoint.items?.[videoId], targetSignature);
  if (checkpointSequence) {
    return checkpointSequence;
  }

  const sections = await feishu.listSectionRanges(client, args.docToken);
  const maxSequence = getMaxDocSequence(sections);

  if (existingRange) {
    const existingAssigned = allocateDocSequenceForExistingSection(sections, existingRange);
    if (existingAssigned) {
      return existingAssigned;
    }
  }

  return maxSequence > 0 ? maxSequence + 1 : sections.length + 1;
}

function safeRelativePath(filePath) {
  if (!filePath) return '';
  const relative = path.relative(SKILL_DIR, filePath);
  return relative && !relative.startsWith('..') ? relative : filePath;
}

function writeJsonFile(filePath, payload) {
  fs.writeFileSync(filePath, JSON.stringify(payload, null, 2), 'utf-8');
}

function ensureParentDir(filePath) {
  if (!filePath) return;
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
}

function readJsonFileSafe(filePath) {
  if (!filePath || !fs.existsSync(filePath)) {
    return null;
  }
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf-8'));
  } catch {
    return null;
  }
}

function sanitizePathSegment(value) {
  return String(value || '')
    .trim()
    .replace(/[<>:"/\\|?*\x00-\x1F]+/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 180) || 'default';
}

function toPortableRelativePath(filePath) {
  return String(filePath || '').split(path.sep).join('/');
}

function normalizeTranscriptForDedupe(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/\s+/g, '')
    .replace(/[，。、“”‘’！？：；,.!?;:()（）\-]/g, '')
    .trim();
}

function hashContentFingerprint(text) {
  const normalized = normalizeTranscriptForDedupe(text);
  if (!normalized) {
    return '';
  }
  return crypto.createHash('sha1').update(normalized).digest('hex');
}

function computeDiceSimilarity(left, right) {
  const leftText = String(left || '');
  const rightText = String(right || '');
  if (!leftText && !rightText) {
    return 1;
  }
  if (!leftText || !rightText) {
    return 0;
  }
  const buildBigrams = (value) => {
    const grams = new Map();
    if (value.length < 2) {
      grams.set(value, 1);
      return grams;
    }
    for (let index = 0; index < value.length - 1; index += 1) {
      const gram = value.slice(index, index + 2);
      grams.set(gram, (grams.get(gram) || 0) + 1);
    }
    return grams;
  };

  const leftBigrams = buildBigrams(leftText);
  const rightBigrams = buildBigrams(rightText);
  let leftCount = 0;
  let rightCount = 0;
  let intersection = 0;
  for (const value of leftBigrams.values()) {
    leftCount += value;
  }
  for (const value of rightBigrams.values()) {
    rightCount += value;
  }
  for (const [gram, count] of leftBigrams.entries()) {
    if (!rightBigrams.has(gram)) continue;
    intersection += Math.min(count, rightBigrams.get(gram));
  }
  return leftCount + rightCount ? (2 * intersection) / (leftCount + rightCount) : 0;
}

function compareByPublishTimeThenVideoIdAsc(left, right) {
  const leftTs = parsePublishTimestamp(left?.publishTime || '') ?? 0;
  const rightTs = parsePublishTimestamp(right?.publishTime || '') ?? 0;
  if (leftTs !== rightTs) {
    return leftTs - rightTs;
  }
  return String(left?.videoId || '').localeCompare(String(right?.videoId || ''));
}

function buildDedupeCandidateFromRecord(record, backupPath = '') {
  const videoId = String(record?.videoId || '').trim();
  if (!videoId) {
    return null;
  }
  const normalizedTranscript = normalizeTranscriptForDedupe(record?.transcript || '');
  const contentFingerprint = normalizedTranscript
    ? crypto.createHash('sha1').update(normalizedTranscript).digest('hex')
    : '';
  return {
    videoId,
    publishTime: String(record?.publishTime || '').trim(),
    publishDate: getPublishDate(record?.publishTime || ''),
    title: String(record?.title || '').trim(),
    topic: String(record?.topic || '').trim(),
    duration: String(record?.duration || '').trim(),
    backupPath: String(backupPath || '').trim(),
    normalizedTranscript,
    normalizedTranscriptLength: normalizedTranscript.length,
    contentFingerprint,
  };
}

function findDuplicateCanonicalCandidate(candidate, canonicalCandidates) {
  if (!DEDUPE_ENABLED || !candidate?.normalizedTranscript) {
    return null;
  }

  const currentLength = Number(candidate.normalizedTranscriptLength || 0);
  if (currentLength < DEDUPE_MIN_TRANSCRIPT_CHARS) {
    return null;
  }

  let bestMatch = null;
  for (const canonical of Array.isArray(canonicalCandidates) ? canonicalCandidates : []) {
    if (!canonical?.videoId || canonical.videoId === candidate.videoId) {
      continue;
    }
    if (!canonical.normalizedTranscript) {
      continue;
    }
    const canonicalLength = Number(canonical.normalizedTranscriptLength || 0);
    if (canonicalLength < DEDUPE_MIN_TRANSCRIPT_CHARS) {
      continue;
    }
    if (
      candidate.duration &&
      canonical.duration &&
      String(candidate.duration).trim() !== String(canonical.duration).trim()
    ) {
      continue;
    }
    if (candidate.contentFingerprint && candidate.contentFingerprint === canonical.contentFingerprint) {
      return {
        canonical,
        similarity: 1,
        reason: 'content_fingerprint_match',
      };
    }
    const maxLength = Math.max(currentLength, canonicalLength);
    if (
      maxLength > 0 &&
      Math.abs(currentLength - canonicalLength) / maxLength > DEDUPE_MAX_LENGTH_RATIO_DELTA
    ) {
      continue;
    }
    const similarity = computeDiceSimilarity(
      candidate.normalizedTranscript,
      canonical.normalizedTranscript,
    );
    if (similarity < DEDUPE_MIN_SIMILARITY) {
      continue;
    }
    if (!bestMatch || similarity > bestMatch.similarity) {
      bestMatch = {
        canonical,
        similarity,
        reason: 'high_transcript_similarity',
      };
    }
  }
  return bestMatch;
}

function summarizeAsrAttempts(attempts) {
  return (Array.isArray(attempts) ? attempts : []).map((attempt, index) => {
    const elapsedRaw = Number(attempt?.elapsed_sec ?? attempt?.elapsedSec);
    return {
      index: index + 1,
      success: attempt?.success === true,
      model: String(attempt?.model || '').trim(),
      elapsedSec: Number.isFinite(elapsedRaw) ? elapsedRaw : null,
      error: attempt?.success ? '' : String(attempt?.error || '').trim(),
    };
  });
}

function normalizeStatusValue(status) {
  return String(status || '').trim();
}

function isTerminalSkipStatus(status) {
  const normalized = normalizeStatusValue(status);
  return normalized === 'duplicate_skipped' || normalized === 'silence_skipped';
}

function isCompletedCheckpointStatus(status) {
  const normalized = normalizeStatusValue(status);
  return normalized === 'written' || isTerminalSkipStatus(normalized);
}

function getPrimaryAsrFailure(attempts) {
  return summarizeAsrAttempts(attempts).find((attempt) => !attempt.success)?.error || '';
}

function didAsrFallbackSucceed(attempts) {
  const list = summarizeAsrAttempts(attempts);
  if (list.length <= 1) {
    return false;
  }
  const lastAttempt = list[list.length - 1];
  const lastModel = String(lastAttempt.model || '').trim();
  return (
    lastAttempt.success &&
    list
      .slice(0, -1)
      .some((attempt) => !attempt.success && String(attempt.model || '').trim() !== lastModel)
  );
}

function isSilenceAsrFailure(input) {
  const texts = [];
  if (typeof input === 'string' || input instanceof Error) {
    texts.push(String(input?.message || input || ''));
    if (input?.stdout) texts.push(String(input.stdout));
    if (input?.stderr) texts.push(String(input.stderr));
  } else if (input && typeof input === 'object') {
    texts.push(String(input.error || ''));
    for (const attempt of Array.isArray(input.attempts) ? input.attempts : []) {
      texts.push(String(attempt?.error || ''));
    }
  }
  const haystack = texts.join(' ').toLowerCase();
  return (
    haystack.includes('20000003') ||
    haystack.includes('normal silence audio') ||
    haystack.includes('no valid speech in audio')
  );
}

function getAsrModelRank(model) {
  const value = String(model || '').trim().toLowerCase();
  if (!value) return 0;
  if (value === 'turbo_2_0' || value === 'streaming_1_0') return 300;
  if (value.startsWith('mlx_whisper')) return 100;
  return 200;
}

function getSummaryStatusRank(status) {
  switch (String(status || '').trim()) {
    case 'written':
      return 70;
    case 'ready':
      return 60;
    case 'partial':
      return 50;
    case 'deferred':
      return 40;
    case 'skipped':
      return 30;
    case 'empty':
      return 20;
    case 'pending':
      return 10;
    case 'failed':
      return 0;
    default:
      return 5;
  }
}

function shouldPromoteCanonicalBackup(existingMeta, nextMeta) {
  if (!existingMeta) {
    return true;
  }

  const existingAsrRank = getAsrModelRank(existingMeta.asrModel);
  const nextAsrRank = getAsrModelRank(nextMeta.asrModel);
  if (existingAsrRank !== nextAsrRank) {
    return nextAsrRank > existingAsrRank;
  }

  const existingSummaryRank = getSummaryStatusRank(existingMeta.summaryStatus);
  const nextSummaryRank = getSummaryStatusRank(nextMeta.summaryStatus);
  if (existingSummaryRank !== nextSummaryRank) {
    return nextSummaryRank >= existingSummaryRank;
  }

  return true;
}

function formatCommentsForDisplay(comments) {
  return (Array.isArray(comments) ? comments : [])
    .map((item) => String(item || '').trim())
    .filter(Boolean)
    .map((item, index) => `${index + 1}. ${item}`)
    .join('\n');
}

function writeBackupArtifacts(backupDir, recordPayload, artifacts, metaPayload) {
  fs.mkdirSync(backupDir, { recursive: true });
  writeJsonFile(path.join(backupDir, 'record.json'), recordPayload);
  fs.writeFileSync(path.join(backupDir, 'transcript.txt'), String(recordPayload?.transcript || ''), 'utf-8');
  fs.writeFileSync(
    path.join(backupDir, 'comments.txt'),
    formatCommentsForDisplay(recordPayload?.comments),
    'utf-8',
  );
  fs.writeFileSync(path.join(backupDir, 'doc.md'), String(artifacts?.docContent || ''), 'utf-8');
  writeJsonFile(path.join(backupDir, 'bitable-fields.json'), artifacts?.fields || {});
  writeJsonFile(path.join(backupDir, 'doc-sections.json'), artifacts?.sections || {});
  writeJsonFile(path.join(backupDir, 'meta.json'), metaPayload);
}

function refreshBackupArtifactsInPlace(args, backupDir, recordPayload, artifacts, metadataPatch = {}) {
  fs.mkdirSync(backupDir, { recursive: true });
  const metaPath = path.join(backupDir, 'meta.json');
  const existingMeta = readJsonFileSafe(metaPath) || {};
  const refreshedAt = new Date().toISOString();
  writeJsonFile(path.join(backupDir, 'record.json'), recordPayload);
  fs.writeFileSync(path.join(backupDir, 'transcript.txt'), String(recordPayload?.transcript || ''), 'utf-8');
  fs.writeFileSync(
    path.join(backupDir, 'comments.txt'),
    formatCommentsForDisplay(recordPayload?.comments),
    'utf-8',
  );
  fs.writeFileSync(path.join(backupDir, 'doc.md'), String(artifacts?.docContent || ''), 'utf-8');
  writeJsonFile(path.join(backupDir, 'bitable-fields.json'), artifacts?.fields || {});
  writeJsonFile(path.join(backupDir, 'doc-sections.json'), artifacts?.sections || {});
  writeJsonFile(metaPath, {
    ...existingMeta,
    ...metadataPatch,
    videoId: String(recordPayload?.videoId || existingMeta.videoId || '').trim(),
    publishTime: String(recordPayload?.publishTime || existingMeta.publishTime || '').trim(),
    writeTarget: args.writeTarget || existingMeta.writeTarget || buildWriteTarget(args),
    artifactsRefreshedAt: refreshedAt,
    artifactsSchemaVersion: 'tag-topic-split-v1',
    textCorrectionsAppliedAt: refreshedAt,
    files: {
      ...(existingMeta.files || {}),
      record: 'record.json',
      transcript: 'transcript.txt',
      comments: 'comments.txt',
      doc: 'doc.md',
      bitableFields: 'bitable-fields.json',
      docSections: 'doc-sections.json',
      meta: 'meta.json',
    },
  });
}

function persistLocalBackup(args, record, artifacts, metadata = {}) {
  const backupRoot = String(args.backupDir || '').trim();
  const videoId = String(record?.videoId || '').trim();
  if (!backupRoot || !videoId) {
    return '';
  }

  const targetKey = sanitizePathSegment(buildWriteTargetKey(args.writeTarget || buildWriteTarget(args)));
  const backupDir = path.join(backupRoot, targetKey, videoId);
  const backedUpAt = new Date().toISOString();
  const asrAttempts = summarizeAsrAttempts(metadata.asrAttempts);
  const recordPayload = { ...record };
  const existingCanonicalMeta = readJsonFileSafe(path.join(backupDir, 'meta.json'));
  const baseMetaPayload = {
    backedUpAt,
    videoId,
    publishTime: record?.publishTime || '',
    input: metadata.input || '',
    asrModel: metadata.asrModel || '',
    asrFallbackUsed: metadata.asrFallbackUsed === true,
    asrPrimaryError: metadata.asrPrimaryError || '',
    asrAttempts,
    summaryStatus: metadata.summaryStatus || '',
    contentFingerprint:
      metadata.contentFingerprint || existingCanonicalMeta?.contentFingerprint || '',
    contentNormalizedLength: Number(
      metadata.contentNormalizedLength || existingCanonicalMeta?.contentNormalizedLength || 0,
    ),
    dedupeStatus: metadata.dedupeStatus || existingCanonicalMeta?.dedupeStatus || '',
    canonicalVideoId:
      metadata.canonicalVideoId || existingCanonicalMeta?.canonicalVideoId || '',
    duplicateOfVideoId:
      metadata.duplicateOfVideoId || existingCanonicalMeta?.duplicateOfVideoId || '',
    duplicateSimilarity: Number.isFinite(Number(metadata.duplicateSimilarity))
      ? Number(metadata.duplicateSimilarity)
      : Number.isFinite(Number(existingCanonicalMeta?.duplicateSimilarity))
        ? Number(existingCanonicalMeta.duplicateSimilarity)
        : null,
    dedupeReason: metadata.dedupeReason || existingCanonicalMeta?.dedupeReason || '',
    writeTarget: args.writeTarget || buildWriteTarget(args),
    files: {
      record: 'record.json',
      transcript: 'transcript.txt',
      comments: 'comments.txt',
      doc: 'doc.md',
      bitableFields: 'bitable-fields.json',
      docSections: 'doc-sections.json',
      meta: 'meta.json',
    },
  };

  const runsDir = path.join(backupDir, 'runs');
  const runName = `${backedUpAt.replace(/[:.]/g, '-')}_${sanitizePathSegment(
    metadata.asrModel || 'unknown',
  )}`;
  const runDir = path.join(runsDir, runName);
  const runRelativePath = toPortableRelativePath(path.relative(backupDir, runDir));
  const promoteCanonical = shouldPromoteCanonicalBackup(existingCanonicalMeta, baseMetaPayload);
  const canonicalReason = promoteCanonical
    ? existingCanonicalMeta
      ? 'replaced_with_equal_or_higher_quality_result'
      : 'initialized'
    : 'kept_existing_higher_quality_result';

  writeBackupArtifacts(runDir, recordPayload, artifacts, {
    ...baseMetaPayload,
    role: 'snapshot',
    snapshotRelativePath: runRelativePath,
    canonicalUpdated: promoteCanonical,
    canonicalReason,
  });

  writeJsonFile(path.join(backupDir, 'latest-run.json'), {
    backedUpAt,
    latestRunRelativePath: runRelativePath,
    asrModel: baseMetaPayload.asrModel,
    summaryStatus: baseMetaPayload.summaryStatus,
    asrFallbackUsed: baseMetaPayload.asrFallbackUsed,
    asrPrimaryError: baseMetaPayload.asrPrimaryError,
  });

  if (promoteCanonical) {
    writeBackupArtifacts(backupDir, recordPayload, artifacts, {
      ...baseMetaPayload,
      role: 'canonical',
      canonicalSourceRunRelativePath: runRelativePath,
      canonicalUpdated: true,
      canonicalReason,
    });
    writeJsonFile(path.join(backupDir, 'canonical-run.json'), {
      backedUpAt,
      canonicalRunRelativePath: runRelativePath,
      asrModel: baseMetaPayload.asrModel,
      summaryStatus: baseMetaPayload.summaryStatus,
    });
  }

  return backupDir;
}

function getCheckpointWrittenVideoIds(checkpoint, targetSignature) {
  const ids = new Set();
  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (isCompletedCheckpointStatus(item?.status) && matchesCheckpointTarget(item, targetSignature)) {
      ids.add(videoId);
    }
  }
  return ids;
}

function requireAccountConfig() {
  if (!ACCOUNT_SEC_UID) {
    throw new Error('runtime.toml 缺少 account.sec_uid，无法执行账号级同步');
  }
}

function buildTimelineBoundaryStopWhen(startTimestamp) {
  return ({ pageItems }) => {
    const timestamps = (Array.isArray(pageItems) ? pageItems : [])
      .map((item) => parsePublishTimestamp(item.publishTime))
      .filter((value) => value !== null);
    if (!timestamps.length) return false;
    return Math.min(...timestamps) < startTimestamp;
  };
}

function assertTimelineStopReason(modeLabel, timeline, allowedStopReasons) {
  const stopReason = String(timeline?.stopReason || '').trim();
  if (allowedStopReasons.includes(stopReason)) {
    return;
  }
  throw new Error(
    `${modeLabel}未完成严格时间线扫描，停止原因 ${stopReason || 'unknown'}；请检查抖音登录态或提高扫描上限`,
  );
}

function logTimelineDiscoveryResult(timeline) {
  logProgress(
    '',
    [
      `账号发现完成: ${Array.isArray(timeline?.items) ? timeline.items.length : 0} 条`,
      `页数 ${timeline?.pageCount || 1}`,
      `has_more=${timeline?.hasMore ? 'true' : 'false'}`,
      timeline?.stopReason ? `停止原因 ${timeline.stopReason}` : '',
      timeline?.source ? `来源 ${timeline.source}` : '',
      ACCOUNT_PROFILE_URL || ACCOUNT_SEC_UID,
    ]
      .filter(Boolean)
      .join(' | '),
  );
}

function assertTimelineWindowSatisfiesRequest(modeLabel, timeline) {
  if (timeline?.hasMore) {
    throw new Error(
      `${modeLabel}需要完整账号时间线；当前公开发现链路只能稳定拿到账号首屏 ${ACCOUNT_VISIBLE_DISCOVERY_LIMIT} 条，已停止执行以避免错误数据`,
    );
  }
}

async function hydrateTimelineItems(prefix, items) {
  const enriched = [];
  for (const [index, item] of items.entries()) {
    const videoId = item.videoId;
    if (!videoId) continue;
    // eslint-disable-next-line no-await-in-loop
    const detail = await retryOperation({
      prefix,
      label: `补拉第 ${index + 1}/${items.length} 条视频详情`,
      attempts: RETRY_METADATA_ATTEMPTS,
      delayMs: RETRY_METADATA_DELAY_MS,
      fn: () => douyin.getVideoInfo(videoId),
    });
    enriched.push({
      ...item,
      ...detail,
    });
  }
  return enriched;
}

function sortTimelineItemsByPublishTime(items, direction = 'desc') {
  const ordered = items.slice();
  ordered.sort((left, right) => {
    const leftTs = parsePublishTimestamp(left.publishTime) ?? 0;
    const rightTs = parsePublishTimestamp(right.publishTime) ?? 0;
    return direction === 'asc' ? leftTs - rightTs : rightTs - leftTs;
  });
  return ordered;
}

function dedupeTimelineItems(items) {
  const seen = new Set();
  const result = [];
  for (const item of items) {
    if (!item?.videoId || seen.has(item.videoId)) continue;
    seen.add(item.videoId);
    result.push(item);
  }
  return result;
}

function collectExplicitVideoIds(args) {
  const deduped = [];
  const seen = new Set();
  for (const raw of Array.isArray(args.inputs) ? args.inputs : []) {
    const videoId = String(raw || '').trim();
    if (!videoId || seen.has(videoId)) continue;
    seen.add(videoId);
    deduped.push(videoId);
  }
  return deduped;
}

async function resolveSyncInputs(args, checkpoint) {
  if (!args.syncMode) {
    if (args.rewriteTarget) {
      return [args.rewriteTarget];
    }
    return args.inputs.slice(0, args.limit);
  }

  if (args.syncMode === 'rewrite') {
    return [args.rewriteTarget];
  }

  requireAccountConfig();
  const checkpointWrittenIds = getCheckpointWrittenVideoIds(
    checkpoint,
    buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args)),
  );
  const checklist = loadTargetTimelineChecklist(args);
  const checklistCompletedIds = new Set(
    (Array.isArray(checklist.items) ? checklist.items : [])
      .filter(
        (item) =>
          item?.completed === true ||
          isTerminalSkipStatus(item?.status) ||
          (item?.docPresent === true && item?.bitablePresent === true),
      )
      .map((item) => String(item?.videoId || '').trim())
      .filter(Boolean),
  );
  const takeVideoIds = (items, direction = 'preserve') => {
    const source = Array.isArray(items) ? items.slice() : [];
    const ordered =
      direction === 'asc' || direction === 'desc'
        ? sortTimelineItemsByPublishTime(source, direction)
        : source;
    return ordered.map((item) => item.videoId).filter(Boolean);
  };
  const hasMainSiteLogin = douyin.hasSavedDouyinLoginState(args.douyinStorageStatePath);

  const discoverVisibleTimeline = async () => {
    const discoverOne = async (mode) => {
      const useMainSite = mode === 'main_site';
      const timeline = await withProgress(
        '',
        useMainSite ? '发现抖音主站账号首屏视频列表' : '发现账号公开首屏视频列表',
        () =>
          useMainSite
            ? douyin.discoverAccountTimelineMainSite(ACCOUNT_SEC_UID, {
                storageStatePath: args.douyinStorageStatePath,
                maxPages: 1,
              })
            : douyin.discoverAccountTimelineFirstPage(ACCOUNT_SEC_UID),
      );
      const items = dedupeTimelineItems(timeline.items || []);
      if (!items.length) {
        throw new Error(useMainSite ? '未发现抖音主站账号时间线首屏' : '未发现账号公开首屏视频列表');
      }
      logTimelineDiscoveryResult(timeline);
      noteTimelineDiscoveryToChecklist(args, checkpoint, timeline, items);
      return { timeline, items };
    };

    if (!hasMainSiteLogin) {
      return discoverOne('public_first_page');
    }

    try {
      return await discoverOne('main_site');
    } catch (err) {
      const reason = formatError(err);
      logProgress('', `抖音主站首屏发现失败，自动降级到公开首屏: ${reason}`);
      return discoverOne('public_first_page');
    }
  };

  const discoverMainSiteTimeline = async (message, options = {}) => {
    if (!hasMainSiteLogin) {
      throw new Error(
        `当前同步模式需要 douyin.com 主站登录态；请先传入 --douyin-storage-state 或准备好 ${args.douyinStorageStatePath}`,
      );
    }
    const timeline = await withProgress('', message, () =>
      douyin.discoverAccountTimelineMainSite(ACCOUNT_SEC_UID, {
        storageStatePath: args.douyinStorageStatePath,
        maxPages: Number(options.maxPages || ACCOUNT_DEEP_DISCOVERY_MAX_PAGES),
        stopWhen: options.stopWhen,
      }),
    );
    const items = dedupeTimelineItems(timeline.items || []);
    logTimelineDiscoveryResult(timeline);
    noteTimelineDiscoveryToChecklist(args, checkpoint, timeline, items);
    return { timeline, items };
  };

  if (args.syncMode === 'latest') {
    const { items } = await discoverVisibleTimeline();
    return takeVideoIds(items.slice(0, 1));
  }

  if (args.syncMode === 'incremental') {
    const { items } = await discoverVisibleTimeline();
    const pending = [];
    for (const item of items) {
      const videoId = String(item?.videoId || '').trim();
      if (!videoId) continue;
      if (checkpointWrittenIds.has(videoId) || checklistCompletedIds.has(videoId)) {
        break;
      }
      pending.push(item);
    }
    // Process older items first so content-level dedupe can stabilize
    // before newer duplicates are considered for Feishu writes.
    return takeVideoIds(pending, 'asc');
  }

  if (args.syncMode === 'recent') {
    if (hasMainSiteLogin) {
      const { items } = await discoverMainSiteTimeline(
        `按最近 ${args.recentCount} 期发现账号时间线`,
        {
          stopWhen: ({ items: accumulated }) => accumulated.length >= args.recentCount,
        },
      );
      return takeVideoIds(items.slice(0, args.recentCount), 'asc');
    }

    const { timeline, items } = await discoverVisibleTimeline();
    if (args.recentCount > items.length && timeline.hasMore) {
      throw new Error(
        `请求最近 ${args.recentCount} 期，但当前仅发现首屏 ${items.length} 条；如需继续向后翻页，请先提供 douyin.com 主站登录态`,
      );
    }
    return takeVideoIds(items.slice(0, args.recentCount), 'asc');
  }

  if (args.syncMode === 'date') {
    const targetStartTimestamp = parsePublishTimestamp(`${args.targetDate} 00:00:00`);
    const { timeline, items } = await discoverMainSiteTimeline(
      `按指定日期 ${args.targetDate} 发现账号时间线`,
      {
        stopWhen: buildTimelineBoundaryStopWhen(targetStartTimestamp),
      },
    );
    assertTimelineStopReason(`指定日期 ${args.targetDate}`, timeline, [
      'stop_condition',
      'end_of_timeline',
    ]);
    const matched = sortTimelineItemsByPublishTime(
      items.filter((item) => getPublishDate(item.publishTime) === args.targetDate),
      'asc',
    );
    return takeVideoIds(matched);
  }

  if (args.syncMode === 'month') {
    const targetMonthStartTimestamp = parsePublishTimestamp(`${args.targetMonth}-01 00:00:00`);
    const { timeline, items } = await discoverMainSiteTimeline(
      `按指定月份 ${args.targetMonth} 发现账号时间线`,
      {
        stopWhen: buildTimelineBoundaryStopWhen(targetMonthStartTimestamp),
      },
    );
    assertTimelineStopReason(`指定月份 ${args.targetMonth}`, timeline, [
      'stop_condition',
      'end_of_timeline',
    ]);
    const matched = sortTimelineItemsByPublishTime(
      items.filter((item) => getPublishMonth(item.publishTime) === args.targetMonth),
      'asc',
    );
    return takeVideoIds(matched);
  }

  if (args.syncMode === 'oldest') {
    const cached = getPendingOldestVideoIdsFromChecklist(args, checkpoint, args.oldestCount);
    if (cached.videoIds.length) {
      logProgress(
        '',
        `本地 checklist 已命中 ${cached.videoIds.length} 条最早未完成视频，直接继续补录，无需重新扫描账号全时间线`,
      );
      return cached.videoIds;
    }
    if (cached.checklist?.coverage?.completeTimeline === true) {
      logProgress('', '本地 checklist 已覆盖完整时间线，当前没有更早的未完成视频');
      return [];
    }
    const { timeline, items } = await discoverMainSiteTimeline('从最早开始发现账号完整时间线');
    assertTimelineStopReason('从最早开始补 N 期', timeline, ['end_of_timeline']);
    const pending = sortTimelineItemsByPublishTime(items, 'asc').filter(
      (item) => !checkpointWrittenIds.has(item.videoId),
    );
    return takeVideoIds(pending.slice(0, args.oldestCount));
  }

  throw new Error(`未知同步模式: ${args.syncMode}`);
}

async function retryOperation({ prefix, label, attempts, delayMs, fn }) {
  let lastError = null;
  for (let attempt = 1; attempt <= attempts; attempt++) {
    try {
      const result = await fn(attempt);
      if (attempt > 1) {
        logProgress(prefix, `${label}第 ${attempt}/${attempts} 次尝试成功`);
      }
      return result;
    } catch (err) {
      lastError = err;
      if (attempt >= attempts) {
        throw err;
      }
      const effectiveDelayMs = getAdaptiveRetryDelayMs(err, attempt, delayMs);
      const delayText =
        effectiveDelayMs > 0 ? `${formatElapsedMs(effectiveDelayMs)}后重试` : '立即重试';
      logProgress(
        prefix,
        `${label}失败（第 ${attempt}/${attempts} 次）: ${formatError(err)}；${delayText}`,
      );
      if (effectiveDelayMs > 0) {
        // Keep retries gentle to reduce transient upstream throttling.
        await sleep(effectiveDelayMs);
      }
    }
  }
  throw lastError || new Error(`${label}失败`);
}

function runAsync(cmd, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(cmd, args, {
      cwd: options.cwd,
      env: options.env || process.env,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';

    child.stdout.on('data', (chunk) => {
      stdout += String(chunk);
    });
    child.stderr.on('data', (chunk) => {
      stderr += String(chunk);
    });
    child.on('error', reject);
    child.on('close', (code) => {
      if (code === 0) {
        resolve(stdout);
        return;
      }

      const detail = stderr.trim() || stdout.trim() || `${cmd} exited with code ${code}`;
      const error = new Error(detail);
      error.code = code;
      error.stdout = stdout;
      error.stderr = stderr;
      reject(error);
    });
  });
}

async function withProgress(prefix, message, fn) {
  const startedAt = Date.now();
  logProgress(prefix, `${message}...`);
  let heartbeat = null;
  const scheduleHeartbeat = (delaySeconds) => {
    heartbeat = setTimeout(() => {
      heartbeat = null;
      if (activeRepeatHeartbeatSeconds > 0) {
        logProgress(prefix, `${message}进行中，已耗时 ${formatElapsedMs(Date.now() - startedAt)}`);
        scheduleHeartbeat(activeRepeatHeartbeatSeconds);
      }
    }, delaySeconds * 1000);
    if (typeof heartbeat.unref === 'function') {
      heartbeat.unref();
    }
  };

  if (activeFirstHeartbeatSeconds > 0) {
    scheduleHeartbeat(activeFirstHeartbeatSeconds);
  }

  try {
    const result = await fn();
    logProgress(prefix, `${message}完成，耗时 ${formatElapsedMs(Date.now() - startedAt)}`);
    return result;
  } finally {
    if (heartbeat) {
      clearTimeout(heartbeat);
    }
  }
}

function extractSummaryText(agentResult) {
  const payloads = agentResult?.result?.payloads || [];
  return payloads
    .map((payload) => String(payload?.text || '').trim())
    .filter(Boolean)
    .join('\n')
    .trim();
}

function normalizeKeyPoints(points) {
  return (Array.isArray(points) ? points : [])
    .map((item) => String(item || '').trim())
    .filter(Boolean)
    .map((item) => item.replace(/^[\-\d\.\)\s]+/, '').trim())
    .map((item) => item.replace(/[。；;]+$/u, '').trim())
    .filter(Boolean)
    .slice(0, 4);
}

function normalizeTopic(value) {
  const topic = String(value || '')
    .trim()
    .replace(/^#+/, '')
    .replace(/^[\-\d\.\)\s]+/, '')
    .replace(/[。；;：:，,、!?！？]+$/u, '')
    .trim();
  if (!topic) return '';
  if (/在抖音记录美好生活\d{8}$/u.test(topic)) return '';
  return topic.slice(0, 20);
}

function parseSummaryPayload(rawText) {
  const text = stripCodeFence(rawText);
  if (!text) {
    return { topic: '', keyPoints: [] };
  }

  try {
    const parsed = JSON.parse(text);
    if (Array.isArray(parsed)) {
      return { topic: '', keyPoints: normalizeKeyPoints(parsed) };
    }
    if (Array.isArray(parsed?.keyPoints)) {
      return {
        topic: normalizeTopic(parsed.topic),
        keyPoints: normalizeKeyPoints(parsed.keyPoints),
      };
    }
  } catch {}

  const lines = text
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .filter((line) => /^(\d+[\.\)]|[-*•])\s+/.test(line));
  return { topic: '', keyPoints: normalizeKeyPoints(lines) };
}

function buildSummaryTarget(videoId) {
  const digits = String(videoId || '').replace(/\D/g, '');
  const suffix = digits.slice(-10).padStart(10, '0');
  return `+1${suffix}`;
}

function extractArkChatText(data) {
  const choices = Array.isArray(data?.choices) ? data.choices : [];
  const primary = choices[0]?.message?.content;
  if (typeof primary === 'string' && primary.trim()) {
    return primary.trim();
  }
  if (Array.isArray(primary)) {
    return primary
      .map((item) => {
        if (typeof item === 'string') return item;
        if (typeof item?.text === 'string') return item.text;
        return '';
      })
      .filter(Boolean)
      .join('\n')
      .trim();
  }
  return '';
}

function buildSummaryPrompt(record, transcript) {
  return [
    '你在为飞书知识库整理一条抖音短视频，请基于给定资料提炼 1 个简短主题和 2 到 4 条核心要点。',
    '要求：',
    '1. 仅输出 JSON，不要输出 markdown、解释或代码块。',
    '2. JSON 结构固定为 {"topic":"简短主题","keyPoints":["要点1","要点2","要点3","要点4"]}。',
    '3. topic 用 4 到 12 个汉字概括主旨，尽量像一个短标题，不要写日期、平台套话、模板文案或完整句子。',
    '4. 如果原始标题是“某某在抖音记录美好生活20220210”这类模板文案，忽略它，不要复用。',
    '5. 每条要点必须准确、具体、可读，不要空话，不要重复，不要编造原文没有的信息。',
    '6. 每条要点控制在 10 到 22 个汉字之间，尽量用短句或短语，不要写成长段复句。',
    '7. 不要出现“视频讲了”“视频提到”“作者认为”“重点是”等套话。',
    '8. 核心要点通常输出 2 到 4 条，按内容密度决定，不要固定凑成 3 条。',
    '9. 输出风格参考：{"topic":"面试准备","keyPoints":["估算题看逻辑推演","加入优秀团队促成长","关键岗位先测思维"]}。',
    '10. topic 无法确定时输出空字符串。',
    '',
    `标题：${record.title || '未知'}`,
    `发布时间：${record.publishTime || '未知'}`,
    `视频时长：${record.duration || '未知'}`,
    `互动数据：点赞 ${record.diggCount || 0}，收藏 ${record.collectCount || 0}，评论 ${record.commentCount || 0}，转发 ${record.shareCount || 0}`,
    '完整转写：',
    transcript,
  ].join('\n');
}

async function summarizeRecordWithArk(record) {
  const transcript = String(record.transcript || '').trim();
  if (!transcript) return { topic: '', keyPoints: [] };
  if (!ARK_API_KEY) {
    throw new Error('ARK_API_KEY 未配置，无法调用豆包 Ark 摘要接口');
  }

  const prompt = buildSummaryPrompt(record, transcript);
  const response = await axios.post(
    `${ARK_BASE_URL}/chat/completions`,
    {
      model: ARK_SUMMARY_MODEL,
      messages: [
        {
          role: 'system',
          content: '你是一个中文内容摘要助手。你只输出 JSON，不输出解释、markdown、前后缀文字或代码块。',
        },
        {
          role: 'user',
          content: prompt,
        },
      ],
      temperature: SUMMARY_TEMPERATURE,
      max_tokens: ARK_SUMMARY_MAX_TOKENS,
      thinking: { type: 'disabled' },
    },
    {
      headers: {
        Authorization: `Bearer ${ARK_API_KEY}`,
        'Content-Type': 'application/json',
      },
      timeout: SUMMARY_TIMEOUT_SECONDS * 1000,
    },
  );
  const rawText = extractArkChatText(response.data);
  if (!rawText) {
    throw new Error('豆包 Ark 摘要返回为空');
  }
  return parseSummaryPayload(rawText);
}

async function summarizeRecordWithOpenClaw(record) {
  const transcript = String(record.transcript || '').trim();
  if (!transcript) return { topic: '', keyPoints: [] };

  const prompt = buildSummaryPrompt(record, transcript);
  const raw = await runAsync(
    'openclaw',
    [
      '--log-level',
      'silent',
      'agent',
      '--json',
      '--timeout',
      String(SUMMARY_TIMEOUT_SECONDS),
      '--thinking',
      SUMMARY_THINKING,
      '--to',
      buildSummaryTarget(record.videoId),
      '--message',
      prompt,
    ],
  );

  const result = parseJsonFromOutput(raw);
  if (result?.status !== 'ok') {
    throw new Error(`OpenClaw 摘要调用失败: ${result?.summary || 'unknown_error'}`);
  }
  return parseSummaryPayload(extractSummaryText(result));
}

async function summarizeRecordWithAuto(record, options = {}) {
  const prefix = String(options.prefix || '').trim();
  if (!ARK_API_KEY) {
    if (prefix) {
      logProgress(prefix, '未检测到 ARK_API_KEY，自动回退 OpenClaw 摘要');
    }
    return summarizeRecordWithOpenClaw(record);
  }

  let lastArkError = null;
  const arkAttempts = 2;
  for (let attempt = 1; attempt <= arkAttempts; attempt++) {
    try {
      return await summarizeRecordWithArk(record);
    } catch (err) {
      lastArkError = err;
      if (attempt >= arkAttempts) {
        break;
      }
      if (prefix) {
        logProgress(
          prefix,
          `Ark 摘要失败（第 ${attempt}/${arkAttempts} 次）: ${formatError(err)}；${formatElapsedMs(RETRY_SUMMARY_DELAY_MS)}后重试`,
        );
      }
      if (RETRY_SUMMARY_DELAY_MS > 0) {
        await sleep(RETRY_SUMMARY_DELAY_MS);
      }
    }
  }

  if (prefix) {
    logProgress(prefix, `Ark 摘要连续失败，自动回退 OpenClaw: ${formatError(lastArkError)}`);
  }
  try {
    return await summarizeRecordWithOpenClaw(record);
  } catch (fallbackErr) {
    throw new Error(
      `Ark 摘要失败后回退 OpenClaw 仍失败: Ark=${formatError(lastArkError)} | OpenClaw=${formatError(fallbackErr)}`,
    );
  }
}

async function summarizeRecord(record, options = {}) {
  if (SUMMARY_PROVIDER === 'openclaw') {
    return summarizeRecordWithOpenClaw(record);
  }
  if (SUMMARY_PROVIDER === 'ark') {
    return summarizeRecordWithArk(record);
  }
  if (SUMMARY_PROVIDER === 'auto' || !SUMMARY_PROVIDER) {
    return summarizeRecordWithAuto(record, options);
  }
  throw new Error(`不支持的摘要提供方: ${SUMMARY_PROVIDER}`);
}

function parseArgs(argv) {
  const args = {
    inputs: [],
    limit: Number(CONFIG.run.default_limit || 5),
    limitProvided: false,
    dryRun: false,
    resume: true,
    skipSummary: false,
    forceRewrite: false,
    syncMode: '',
    recentCount: 0,
    oldestCount: 0,
    targetDate: '',
    targetMonth: '',
    rewriteTarget: '',
    reconcileTarget: false,
    backfillMissingBackups: false,
    backfillDocPending: false,
    backfillDocAll: false,
    backfillBitableFields: false,
    backfillCommentsEngagement: false,
    refreshEngagementRecentDays: 0,
    skipDocWrite: false,
    backupDir: '',
    checkpoint: DEFAULT_CHECKPOINT_PATH,
    indexLogPath: '',
    douyinStorageStatePath: '',
    startAfterVideoId: '',
    runSummaryJson: '',
  };

  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--limit') {
      args.limit = Number(argv[++i]);
      args.limitProvided = true;
    }
    else if (a === '--doc-token') args.docToken = argv[++i];
    else if (a === '--bitable-app-token') args.bitableAppToken = argv[++i];
    else if (a === '--bitable-table-id') args.bitableTableId = argv[++i];
    else if (a === '--index-log') args.indexLogPath = argv[++i];
    else if (a === '--backup-dir') args.backupDir = argv[++i];
    else if (a === '--douyin-storage-state') args.douyinStorageStatePath = argv[++i];
    else if (a === '--start-after-video-id') args.startAfterVideoId = String(argv[++i] || '').trim();
    else if (a === '--sync-latest') args.syncMode = 'latest';
    else if (a === '--sync-incremental') args.syncMode = 'incremental';
    else if (a === '--sync-recent') {
      args.syncMode = 'recent';
      args.recentCount = Math.max(1, Number(argv[++i]) || 1);
    }
    else if (a === '--sync-date') {
      args.syncMode = 'date';
      args.targetDate = String(argv[++i] || '').trim();
    }
    else if (a === '--sync-month') {
      args.syncMode = 'month';
      args.targetMonth = String(argv[++i] || '').trim();
    }
    else if (a === '--sync-oldest') {
      args.syncMode = 'oldest';
      args.oldestCount = Math.max(1, Number(argv[++i]) || 1);
    }
    else if (a === '--rewrite') {
      args.syncMode = 'rewrite';
      args.forceRewrite = true;
      args.rewriteTarget = String(argv[++i] || '').trim();
    }
    else if (a === '--reconcile-target') args.reconcileTarget = true;
    else if (a === '--backfill-missing-backups' || a === '--repair-missing-backups') {
      args.backfillMissingBackups = true;
    }
    else if (a === '--backfill-doc-pending') args.backfillDocPending = true;
    else if (a === '--backfill-doc-all') args.backfillDocAll = true;
    else if (a === '--backfill-bitable-fields') args.backfillBitableFields = true;
    else if (a === '--backfill-comments-engagement') args.backfillCommentsEngagement = true;
    else if (a === '--refresh-engagement-recent-days') {
      args.refreshEngagementRecentDays = Math.max(1, Number(argv[++i]) || 7);
    }
    else if (a === '--skip-doc-write') args.skipDocWrite = true;
    else if (a === '--force-rewrite') args.forceRewrite = true;
    else if (a === '--batch') args.batchFile = argv[++i];
    else if (a === '--dry-run') args.dryRun = true;
    else if (a === '--no-resume') args.resume = false;
    else if (a === '--skip-summary') args.skipSummary = true;
    else if (a === '--checkpoint') args.checkpoint = argv[++i];
    else if (a === '--run-summary-json') args.runSummaryJson = argv[++i];
    else if (a === '--progress-heartbeat') {
      args.progressHeartbeatSeconds = Math.max(
        5,
        Number(argv[++i]) || DEFAULT_PROGRESS_REPEAT_HEARTBEAT_SECONDS,
      );
    }
    else args.inputs.push(a);
  }

  if (args.batchFile) {
    const lines = fs
      .readFileSync(args.batchFile, 'utf-8')
      .split(/\r?\n/)
      .map((s) => s.trim())
      .filter(Boolean);
    args.inputs.push(...lines);
  }

  args.docToken =
    args.docToken ||
    process.env.FEISHU_DOC_TOKEN ||
    process.env.DOUYIN_FEISHU_DOC_TOKEN ||
    CONFIG.feishu.doc_token;
  args.bitableAppToken =
    args.bitableAppToken ||
    process.env.FEISHU_BITABLE_APP_TOKEN ||
    process.env.DOUYIN_FEISHU_BITABLE_APP_TOKEN ||
    CONFIG.feishu.bitable_app_token;
  args.bitableTableId =
    args.bitableTableId ||
    process.env.FEISHU_BITABLE_TABLE_ID ||
    process.env.DOUYIN_FEISHU_BITABLE_TABLE_ID ||
    CONFIG.feishu.bitable_table_id;
  args.indexLogPath =
    resolveGenericPath(
      args.indexLogPath ||
        process.env.FEISHU_WRITE_INDEX_LOG ||
        process.env.DOUYIN_FEISHU_WRITE_INDEX_LOG ||
        DEFAULT_INDEX_LOG_PATH,
    );
  args.backupDir = resolveSkillPath(
    args.backupDir ||
      process.env.DOUYIN_BACKUP_DIR ||
      process.env.DOUYIN_TRANSCRIBE_BACKUP_DIR ||
      DEFAULT_BACKUP_DIR,
  );
  args.checkpoint = resolveGenericPath(
    args.checkpoint ||
      process.env.DOUYIN_TRANSCRIBE_CHECKPOINT_PATH ||
      process.env.DOUYIN_CHECKPOINT_PATH ||
      DEFAULT_CHECKPOINT_PATH,
  );
  args.douyinStorageStatePath = resolveSkillPath(
    args.douyinStorageStatePath ||
      process.env.DOUYIN_STORAGE_STATE_PATH ||
      process.env.DOUYIN_BROWSER_STORAGE_STATE ||
      CONFIG.browser?.douyin_storage_state_path ||
      DEFAULT_DOUYIN_STORAGE_STATE_PATH,
  );
  args.runSummaryJson = resolveGenericPath(args.runSummaryJson || '');

  if (args.syncMode === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(args.targetDate)) {
    throw new Error('--sync-date 需要 YYYY-MM-DD');
  }
  if (args.syncMode === 'month' && !/^\d{4}-\d{2}$/.test(args.targetMonth)) {
    throw new Error('--sync-month 需要 YYYY-MM');
  }
  if (args.syncMode === 'rewrite' && !args.rewriteTarget) {
    throw new Error('--rewrite 需要传入视频链接或视频 ID');
  }
  return args;
}

function getVideoDuration(videoPath) {
  try {
    const output = run('ffprobe', [
      '-v',
      'error',
      '-show_entries',
      'format=duration',
      '-of',
      'default=nk=1:nw=1',
      videoPath,
    ]);
    const seconds = parseFloat(output.trim());
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  } catch {
    return '00:00';
  }
}

async function extractAudio(videoPath, audioPath) {
  await runAsync(
    'ffmpeg',
    ['-i', videoPath, '-vn', '-acodec', 'pcm_s16le', '-ac', '1', '-ar', '16000', audioPath, '-y'],
  );
}

function loadCheckpoint(checkpointPath) {
  if (!fs.existsSync(checkpointPath)) {
    return { items: {} };
  }
  return JSON.parse(fs.readFileSync(checkpointPath, 'utf-8'));
}

function saveCheckpoint(checkpointPath, data) {
  fs.mkdirSync(path.dirname(checkpointPath), { recursive: true });
  fs.writeFileSync(checkpointPath, JSON.stringify(data, null, 2), 'utf-8');
}

function appendJsonl(logPath, payload) {
  if (!logPath) {
    return;
  }
  fs.mkdirSync(path.dirname(logPath), { recursive: true });
  fs.appendFileSync(logPath, `${JSON.stringify(payload)}\n`, 'utf-8');
}

function readJsonl(logPath) {
  if (!logPath || !fs.existsSync(logPath)) {
    return [];
  }
  return fs
    .readFileSync(logPath, 'utf-8')
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      try {
        return JSON.parse(line);
      } catch {
        return null;
      }
    })
    .filter(Boolean);
}

function getTargetBackupRoot(args) {
  const backupRoot = String(args?.backupDir || '').trim();
  if (!backupRoot) {
    return '';
  }
  const targetKey = sanitizePathSegment(buildWriteTargetKey(args.writeTarget || buildWriteTarget(args)));
  return path.join(backupRoot, targetKey);
}

function getTargetDedupeIndexPath(args) {
  const targetBackupRoot = getTargetBackupRoot(args);
  return targetBackupRoot ? path.join(targetBackupRoot, 'dedupe-index.json') : '';
}

function createDedupeStateEntry(candidate, match = null, updatedAt = new Date().toISOString()) {
  const base = {
    videoId: candidate.videoId,
    publishTime: candidate.publishTime || '',
    publishDate: candidate.publishDate || getPublishDate(candidate.publishTime || ''),
    title: candidate.title || '',
    topic: candidate.topic || '',
    duration: candidate.duration || '',
    backupPath: candidate.backupPath || '',
    contentFingerprint: candidate.contentFingerprint || '',
    normalizedTranscriptLength: Number(candidate.normalizedTranscriptLength || 0),
    dedupeUpdatedAt: updatedAt,
  };
  if (!match) {
    return {
      ...base,
      dedupeStatus: 'canonical',
      canonicalVideoId: candidate.videoId,
      duplicateOfVideoId: '',
      duplicateSimilarity: null,
      dedupeReason: '',
    };
  }
  return {
    ...base,
    dedupeStatus: 'duplicate',
    canonicalVideoId: match.canonical.videoId,
    duplicateOfVideoId: match.canonical.videoId,
    duplicateSimilarity: Number(match.similarity.toFixed(6)),
    dedupeReason: match.reason || '',
  };
}

function buildTargetDedupeStateFromBackups(args) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetRoot = getTargetBackupRoot(args);
  const state = {
    updatedAt: new Date().toISOString(),
    target,
    targetRoot,
    itemsByVideoId: new Map(),
    canonicalCandidates: [],
  };
  if (!DEDUPE_ENABLED || !targetRoot || !fs.existsSync(targetRoot)) {
    return state;
  }

  const candidates = fs
    .readdirSync(targetRoot, { withFileTypes: true })
    .filter((entry) => entry.isDirectory() && /^\d{10,}$/.test(entry.name))
    .map((entry) => {
      const backupPath = path.join(targetRoot, entry.name);
      const record = readJsonFileSafe(path.join(backupPath, 'record.json'));
      if (!record) {
        return null;
      }
      return buildDedupeCandidateFromRecord(record, backupPath);
    })
    .filter(Boolean)
    .sort(compareByPublishTimeThenVideoIdAsc);

  for (const candidate of candidates) {
    const match = findDuplicateCanonicalCandidate(candidate, state.canonicalCandidates);
    const entry = createDedupeStateEntry(candidate, match, state.updatedAt);
    state.itemsByVideoId.set(candidate.videoId, entry);
    if (!match) {
      state.canonicalCandidates.push(candidate);
    }
  }

  return state;
}

function createPersistedTargetDedupeIndex(args, state) {
  const target = args.writeTarget || buildWriteTarget(args);
  const items = [...(state?.itemsByVideoId?.values?.() || [])]
    .map((entry) => ({
      videoId: entry.videoId,
      publishTime: entry.publishTime || '',
      publishDate: entry.publishDate || '',
      title: entry.title || '',
      topic: entry.topic || '',
      duration: entry.duration || '',
      backupPath: entry.backupPath || '',
      contentFingerprint: entry.contentFingerprint || '',
      normalizedTranscriptLength: Number(entry.normalizedTranscriptLength || 0),
      dedupeStatus: entry.dedupeStatus || '',
      canonicalVideoId: entry.canonicalVideoId || '',
      duplicateOfVideoId: entry.duplicateOfVideoId || '',
      duplicateSimilarity: Number.isFinite(entry.duplicateSimilarity)
        ? entry.duplicateSimilarity
        : null,
      dedupeReason: entry.dedupeReason || '',
      dedupeUpdatedAt: entry.dedupeUpdatedAt || state?.updatedAt || new Date().toISOString(),
    }))
    .sort(compareByPublishTimeThenVideoIdAsc);

  const groups = new Map();
  for (const item of items) {
    const canonicalVideoId = String(item.canonicalVideoId || item.videoId || '').trim();
    if (!canonicalVideoId) continue;
    if (!groups.has(canonicalVideoId)) {
      groups.set(canonicalVideoId, []);
    }
    groups.get(canonicalVideoId).push(item.videoId);
  }

  const duplicateCount = items.filter((item) => item.dedupeStatus === 'duplicate').length;
  return {
    updatedAt: state?.updatedAt || new Date().toISOString(),
    target,
    count: items.length,
    canonicalCount: items.length - duplicateCount,
    duplicateCount,
    items,
    groups: [...groups.entries()]
      .map(([canonicalVideoId, videoIds]) => ({
        canonicalVideoId,
        videoIds: videoIds.slice(),
      }))
      .sort((left, right) => String(left.canonicalVideoId).localeCompare(String(right.canonicalVideoId))),
  };
}

function saveTargetDedupeIndex(args, state) {
  const dedupeIndexPath = getTargetDedupeIndexPath(args);
  if (!dedupeIndexPath) {
    return;
  }
  fs.mkdirSync(path.dirname(dedupeIndexPath), { recursive: true });
  writeJsonFile(dedupeIndexPath, createPersistedTargetDedupeIndex(args, state));
}

function patchBackupDedupeMetadataRecursive(dirPath, entry) {
  if (!dirPath || !fs.existsSync(dirPath) || !entry) {
    return;
  }
  for (const item of fs.readdirSync(dirPath, { withFileTypes: true })) {
    const fullPath = path.join(dirPath, item.name);
    if (item.isDirectory()) {
      patchBackupDedupeMetadataRecursive(fullPath, entry);
      continue;
    }
    if (item.name !== 'meta.json') continue;
    const payload = readJsonFileSafe(fullPath);
    if (!payload) continue;
    payload.contentFingerprint = entry.contentFingerprint || '';
    payload.contentNormalizedLength = Number(entry.normalizedTranscriptLength || 0);
    payload.dedupeStatus = entry.dedupeStatus || '';
    payload.canonicalVideoId = entry.canonicalVideoId || entry.videoId || '';
    payload.dedupeUpdatedAt = entry.dedupeUpdatedAt || new Date().toISOString();
    if (entry.dedupeStatus === 'duplicate') {
      payload.duplicateOfVideoId = entry.duplicateOfVideoId || '';
      payload.duplicateSimilarity = Number.isFinite(entry.duplicateSimilarity)
        ? entry.duplicateSimilarity
        : null;
      payload.dedupeReason = entry.dedupeReason || '';
    } else {
      delete payload.duplicateOfVideoId;
      delete payload.duplicateSimilarity;
      delete payload.dedupeReason;
    }
    writeJsonFile(fullPath, payload);
  }
}

function syncTargetDedupeMetadata(args, state) {
  const targetRoot = getTargetBackupRoot(args);
  if (!targetRoot || !fs.existsSync(targetRoot)) {
    return;
  }
  for (const entry of state?.itemsByVideoId?.values?.() || []) {
    const backupDir = path.join(targetRoot, String(entry.videoId || '').trim());
    if (!fs.existsSync(backupDir)) continue;
    patchBackupDedupeMetadataRecursive(backupDir, entry);
  }
}

function applyTargetDedupeStateToCatalog(args, state) {
  const catalog = loadTargetCatalog(args);
  const items = (Array.isArray(catalog.items) ? catalog.items : []).map((item) => {
    const entry = state?.itemsByVideoId?.get?.(String(item?.videoId || '').trim());
    if (!entry) {
      return item;
    }
    return {
      ...item,
      contentFingerprint: entry.contentFingerprint || '',
      contentNormalizedLength: Number(entry.normalizedTranscriptLength || 0),
      dedupeStatus: entry.dedupeStatus || '',
      canonicalVideoId: entry.canonicalVideoId || '',
      duplicateOfVideoId: entry.duplicateOfVideoId || '',
      duplicateSimilarity: Number.isFinite(entry.duplicateSimilarity)
        ? entry.duplicateSimilarity
        : null,
      dedupeReason: entry.dedupeReason || '',
    };
  });
  saveTargetCatalogEntries(args, items);
}

function applyTargetDedupeStateToCheckpoint(args, checkpoint, checkpointPath, state) {
  if (!checkpointPath) {
    return;
  }
  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  let changed = false;
  for (const entry of state?.itemsByVideoId?.values?.() || []) {
    const videoId = String(entry.videoId || '').trim();
    if (!videoId) continue;
    const existing = checkpoint.items?.[videoId];
    if (!existing || !matchesCheckpointTarget(existing, targetSignature)) {
      continue;
    }
    const nextItem = {
      ...existing,
      contentFingerprint: entry.contentFingerprint || '',
      contentNormalizedLength: Number(entry.normalizedTranscriptLength || 0),
      dedupeStatus: entry.dedupeStatus || '',
      canonicalVideoId: entry.canonicalVideoId || '',
      dedupeUpdatedAt: entry.dedupeUpdatedAt || new Date().toISOString(),
    };
    if (entry.dedupeStatus === 'duplicate') {
      nextItem.duplicateOfVideoId = entry.duplicateOfVideoId || '';
      nextItem.duplicateSimilarity = Number.isFinite(entry.duplicateSimilarity)
        ? entry.duplicateSimilarity
        : null;
      nextItem.dedupeReason = entry.dedupeReason || '';
      nextItem.docPending = false;
      if (!['written', 'doc_written'].includes(String(existing.status || '').trim())) {
        nextItem.status = 'duplicate_skipped';
        if (!isDocActionPresent(existing.docAction || '')) {
          nextItem.docAction = 'skip';
        }
      }
    } else {
      delete nextItem.duplicateOfVideoId;
      delete nextItem.duplicateSimilarity;
      delete nextItem.dedupeReason;
      if (String(existing.status || '').trim() === 'duplicate_skipped') {
        nextItem.status = existing.bitableRecordId
          ? 'bitable_written'
          : isDocActionPresent(existing.docAction || '')
            ? 'doc_written'
            : 'resolved';
      }
    }
    if (JSON.stringify(existing) !== JSON.stringify(nextItem)) {
      checkpoint.items[videoId] = nextItem;
      changed = true;
    }
  }
  if (changed) {
    saveCheckpoint(checkpointPath, checkpoint);
  }
}

function applyTargetDedupeStateToChecklist(args, state) {
  const entries = [...(state?.itemsByVideoId?.values?.() || [])].map((entry) => ({
    videoId: entry.videoId,
    publishTime: entry.publishTime || '',
    publishDate: entry.publishDate || '',
    title: entry.title || '',
    topic: entry.topic || '',
    backupAvailable: true,
    status: entry.dedupeStatus === 'duplicate' ? 'duplicate_skipped' : '',
    completed: entry.dedupeStatus === 'duplicate',
    dedupeStatus: entry.dedupeStatus || '',
    canonicalVideoId: entry.canonicalVideoId || '',
    duplicateOfVideoId: entry.duplicateOfVideoId || '',
    duplicateSimilarity: Number.isFinite(entry.duplicateSimilarity)
      ? entry.duplicateSimilarity
      : null,
    dedupeReason: entry.dedupeReason || '',
    contentFingerprint: entry.contentFingerprint || '',
    contentNormalizedLength: Number(entry.normalizedTranscriptLength || 0),
  }));
  saveTargetTimelineChecklistEntries(args, entries);
}

function refreshTargetDedupeState(args, checkpoint, checkpointPath) {
  const state = buildTargetDedupeStateFromBackups(args);
  args.dedupeState = state;
  saveTargetDedupeIndex(args, state);
  syncTargetDedupeMetadata(args, state);
  applyTargetDedupeStateToCatalog(args, state);
  applyTargetDedupeStateToCheckpoint(args, checkpoint, checkpointPath, state);
  applyTargetDedupeStateToChecklist(args, state);
  return state;
}

function getTargetDedupeEntry(args, videoId) {
  const key = String(videoId || '').trim();
  if (!key) {
    return null;
  }
  return args?.dedupeState?.itemsByVideoId?.get?.(key) || null;
}

function getTargetCatalogPath(args) {
  const targetBackupRoot = getTargetBackupRoot(args);
  return targetBackupRoot ? path.join(targetBackupRoot, 'catalog.json') : '';
}

function loadTargetCatalog(args) {
  const catalogPath = getTargetCatalogPath(args);
  if (!catalogPath || !fs.existsSync(catalogPath)) {
    return { items: [] };
  }
  return readJsonFileSafe(catalogPath) || { items: [] };
}

function saveTargetCatalog(args, catalog) {
  const catalogPath = getTargetCatalogPath(args);
  if (!catalogPath) {
    return;
  }
  fs.mkdirSync(path.dirname(catalogPath), { recursive: true });
  writeJsonFile(catalogPath, catalog);
}

function buildTargetCatalogEntry(args, result, record, bitableResult) {
  const target = args.writeTarget || buildWriteTarget(args);
  return {
    videoId: record.videoId || '',
    publishDate: getPublishDate(record.publishTime),
    publishTime: record.publishTime || '',
    title: record.title || '',
    topic: record.topic || '',
    summaryStatus: result.summaryStatus || '',
    docAction: result.docAction || '',
    bitableAction: result.bitableAction || '',
    bitableRecordId: bitableResult?.record?.record_id || result.bitableRecordId || '',
    backupPath: result.backupPath || '',
    backupPathRelative: result.backupPath ? safeRelativePath(result.backupPath) : '',
    backupAvailable: Boolean(result.backupPath),
    contentFingerprint: result.contentFingerprint || hashContentFingerprint(record.transcript || ''),
    contentNormalizedLength: Number(result.contentNormalizedLength || normalizeTranscriptForDedupe(record.transcript || '').length || 0),
    dedupeStatus: result.dedupeStatus || '',
    canonicalVideoId: result.canonicalVideoId || '',
    duplicateOfVideoId: result.duplicateOfVideoId || '',
    duplicateSimilarity: Number.isFinite(result.duplicateSimilarity) ? result.duplicateSimilarity : null,
    dedupeReason: result.dedupeReason || '',
    target,
    updatedAt: new Date().toISOString(),
  };
}

function compareCatalogEntriesDesc(left, right) {
  const leftTs = parsePublishTimestamp(left?.publishTime || '') ?? 0;
  const rightTs = parsePublishTimestamp(right?.publishTime || '') ?? 0;
  if (leftTs !== rightTs) {
    return rightTs - leftTs;
  }
  return String(right?.videoId || '').localeCompare(String(left?.videoId || ''));
}

function saveTargetCatalogEntries(args, entries) {
  const target = args.writeTarget || buildWriteTarget(args);
  const merged = new Map();
  for (const entry of Array.isArray(entries) ? entries : []) {
    const videoId = String(entry?.videoId || '').trim();
    if (!videoId) continue;
    const existing = merged.get(videoId) || {};
    merged.set(videoId, {
      ...existing,
      ...entry,
      videoId,
    });
  }
  const items = [...merged.values()].sort(compareCatalogEntriesDesc);
  saveTargetCatalog(args, {
    updatedAt: new Date().toISOString(),
    count: items.length,
    target,
    items,
  });
  return items;
}

function upsertTargetCatalogEntry(args, result, record, bitableResult) {
  const videoId = String(record?.videoId || '').trim();
  if (!videoId) {
    return;
  }
  const catalog = loadTargetCatalog(args);
  const items = Array.isArray(catalog.items) ? catalog.items.slice() : [];
  items.push(buildTargetCatalogEntry(args, result, record, bitableResult));
  saveTargetCatalogEntries(args, items);
}

function getTargetTimelineChecklistPath(args) {
  const targetBackupRoot = getTargetBackupRoot(args);
  if (targetBackupRoot) {
    return path.join(targetBackupRoot, 'timeline-checklist.json');
  }
  const checkpointPath = String(args?.checkpoint || '').trim();
  if (!checkpointPath) {
    return '';
  }
  const targetKey = sanitizePathSegment(buildWriteTargetKey(args.writeTarget || buildWriteTarget(args)));
  return path.join(path.dirname(checkpointPath), `${targetKey}.timeline-checklist.json`);
}

function buildEmptyTargetTimelineChecklist(args) {
  return {
    updatedAt: new Date().toISOString(),
    sort: 'publish_time_asc',
    account: {
      secUid: ACCOUNT_SEC_UID || '',
      profileUrl: ACCOUNT_PROFILE_URL || '',
    },
    target: args.writeTarget || buildWriteTarget(args),
    coverage: {
      completeTimeline: false,
      completeTimelineAt: '',
      completeTimelineSource: '',
      completeTimelineItemCount: 0,
      oldestPublishTime: '',
      newestPublishTime: '',
      lastDiscoveryAt: '',
      lastDiscoverySource: '',
      lastStopReason: '',
      lastHasMore: null,
      lastPageCount: 0,
      lastDiscoveredCount: 0,
    },
    items: [],
  };
}

function loadTargetTimelineChecklist(args) {
  const checklistPath = getTargetTimelineChecklistPath(args);
  const empty = buildEmptyTargetTimelineChecklist(args);
  if (!checklistPath || !fs.existsSync(checklistPath)) {
    return empty;
  }
  const payload = readJsonFileSafe(checklistPath) || {};
  return {
    ...empty,
    ...payload,
    account: {
      ...empty.account,
      ...(payload.account || {}),
    },
    target: {
      ...empty.target,
      ...(payload.target || {}),
    },
    coverage: {
      ...empty.coverage,
      ...(payload.coverage || {}),
    },
    items: Array.isArray(payload.items) ? payload.items : [],
  };
}

function saveTargetTimelineChecklist(args, checklist) {
  const checklistPath = getTargetTimelineChecklistPath(args);
  if (!checklistPath) {
    return;
  }
  fs.mkdirSync(path.dirname(checklistPath), { recursive: true });
  writeJsonFile(checklistPath, checklist);
}

function compareChecklistEntriesAsc(left, right) {
  const leftTs = parsePublishTimestamp(left?.publishTime || '') ?? 0;
  const rightTs = parsePublishTimestamp(right?.publishTime || '') ?? 0;
  if (leftTs !== rightTs) {
    return leftTs - rightTs;
  }
  return String(left?.videoId || '').localeCompare(String(right?.videoId || ''));
}

function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj || {}, key);
}

function isDocActionPresent(action) {
  return ['create', 'replace', 'keep'].includes(String(action || '').trim());
}

function isBitableActionPresent(action) {
  return ['create', 'update', 'keep'].includes(String(action || '').trim());
}

function computeChecklistStatus(payload = {}) {
  const statusHint = normalizeStatusValue(payload.status || payload.checkpointStatus || '');
  const dedupeStatus = String(payload.dedupeStatus || '').trim();
  if (dedupeStatus === 'duplicate' || statusHint === 'duplicate_skipped') {
    return 'duplicate_skipped';
  }
  if (statusHint === 'silence_skipped') {
    return 'silence_skipped';
  }
  if (
    payload.completed === true ||
    statusHint === 'written' ||
    (payload.docPresent === true && payload.bitablePresent === true)
  ) {
    return 'written';
  }
  if (statusHint === 'failed' || payload.error || payload.failedStage) {
    return 'failed';
  }
  if (payload.docPresent === true && payload.bitablePresent !== true) {
    return 'doc_only';
  }
  if (payload.bitablePresent === true && payload.docPresent !== true) {
    return 'bitable_only';
  }
  return statusHint || 'pending';
}

function mergeTimelineChecklistEntry(existing, payload = {}) {
  const publishTime = String(payload.publishTime || existing?.publishTime || '').trim();
  const docPresent = hasOwn(payload, 'docPresent')
    ? payload.docPresent === true
    : existing?.docPresent === true;
  const bitablePresent = hasOwn(payload, 'bitablePresent')
    ? payload.bitablePresent === true
    : existing?.bitablePresent === true;
  const baseCompleted = hasOwn(payload, 'completed')
    ? payload.completed === true
    : existing?.completed === true;
  const dedupeStatus = String(payload.dedupeStatus || existing?.dedupeStatus || '').trim();
  const merged = {
    ...(existing || {}),
    videoId: String(payload.videoId || existing?.videoId || '').trim(),
    publishTime,
    publishDate: String(payload.publishDate || existing?.publishDate || getPublishDate(publishTime)).trim(),
    title: String(payload.title || existing?.title || '').trim(),
    topic: String(payload.topic || existing?.topic || '').trim(),
    checkpointStatus: String(payload.checkpointStatus || existing?.checkpointStatus || '').trim(),
    summaryStatus: String(payload.summaryStatus || existing?.summaryStatus || '').trim(),
    docAction: String(payload.docAction || existing?.docAction || '').trim(),
    bitableAction: String(payload.bitableAction || existing?.bitableAction || '').trim(),
    bitableRecordId: String(payload.bitableRecordId || existing?.bitableRecordId || '').trim(),
    docPresent,
    bitablePresent,
    backupAvailable: hasOwn(payload, 'backupAvailable')
      ? payload.backupAvailable === true
      : existing?.backupAvailable === true,
    contentFingerprint: String(payload.contentFingerprint || existing?.contentFingerprint || '').trim(),
    contentNormalizedLength: Number(
      payload.contentNormalizedLength || existing?.contentNormalizedLength || 0,
    ),
    dedupeStatus,
    canonicalVideoId: String(payload.canonicalVideoId || existing?.canonicalVideoId || '').trim(),
    duplicateOfVideoId: String(
      payload.duplicateOfVideoId || existing?.duplicateOfVideoId || '',
    ).trim(),
    duplicateSimilarity: Number.isFinite(Number(payload.duplicateSimilarity))
      ? Number(payload.duplicateSimilarity)
      : Number.isFinite(Number(existing?.duplicateSimilarity))
        ? Number(existing.duplicateSimilarity)
        : null,
    dedupeReason: String(payload.dedupeReason || existing?.dedupeReason || '').trim(),
    timelinePresent: hasOwn(payload, 'timelinePresent')
      ? payload.timelinePresent === true
      : existing?.timelinePresent === true,
    timelineSource: String(payload.timelineSource || existing?.timelineSource || '').trim(),
    failedStage: payload.failedStage === null
      ? ''
      : String(payload.failedStage || existing?.failedStage || '').trim(),
    error: payload.error === null ? '' : String(payload.error || existing?.error || '').trim(),
    updatedAt: payload.updatedAt || new Date().toISOString(),
  };
  merged.completed =
    baseCompleted ||
    merged.dedupeStatus === 'duplicate' ||
    isCompletedCheckpointStatus(merged.checkpointStatus) ||
    (merged.docPresent === true && merged.bitablePresent === true);
  merged.status = computeChecklistStatus({
    status: payload.status || existing?.status || merged.checkpointStatus,
    checkpointStatus: merged.checkpointStatus,
    dedupeStatus: merged.dedupeStatus,
    completed: merged.completed,
    docPresent: merged.docPresent,
    bitablePresent: merged.bitablePresent,
    failedStage: merged.failedStage,
    error: merged.error,
  });
  if (merged.status === 'written') {
    merged.completed = true;
    merged.failedStage = '';
    merged.error = '';
  } else if (isTerminalSkipStatus(merged.status)) {
    merged.completed = true;
  }
  return merged;
}

function saveTargetTimelineChecklistEntries(args, entries, options = {}) {
  const checklistPath = getTargetTimelineChecklistPath(args);
  if (!checklistPath) {
    return [];
  }
  const checklist = loadTargetTimelineChecklist(args);
  const merged = new Map(
    (Array.isArray(checklist.items) ? checklist.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );

  for (const entry of Array.isArray(entries) ? entries : []) {
    const videoId = String(entry?.videoId || '').trim();
    if (!videoId) continue;
    merged.set(videoId, mergeTimelineChecklistEntry(merged.get(videoId), entry));
  }

  const items = [...merged.values()].sort(compareChecklistEntriesAsc);
  const nextChecklist = {
    ...checklist,
    updatedAt: new Date().toISOString(),
    target: args.writeTarget || buildWriteTarget(args),
    coverage: {
      ...(checklist.coverage || {}),
      ...(options.coveragePatch || {}),
    },
    items,
  };
  saveTargetTimelineChecklist(args, nextChecklist);
  return items;
}

function buildChecklistEntryFromCheckpointItem(args, videoId, item = {}, extra = {}) {
  const checkpointStatus = String(item?.status || '').trim();
  const docAction = String(extra.docAction || item?.docAction || '').trim();
  const bitableAction = String(extra.bitableAction || item?.bitableAction || '').trim();
  const payload = {
    videoId,
    publishTime: String(extra.publishTime || item?.publishTime || '').trim(),
    publishDate: String(extra.publishDate || item?.publishDate || '').trim(),
    title: String(extra.title || item?.title || '').trim(),
    topic: String(extra.topic || item?.summaryTopic || '').trim(),
    status: String(extra.status || checkpointStatus || '').trim(),
    checkpointStatus,
    summaryStatus: String(extra.summaryStatus || item?.summaryStatus || '').trim(),
    docAction,
    bitableAction,
    docPresent: hasOwn(extra, 'docPresent')
      ? extra.docPresent === true
      : checkpointStatus === 'written' || checkpointStatus === 'doc_written' || isDocActionPresent(docAction),
    bitablePresent: hasOwn(extra, 'bitablePresent')
      ? extra.bitablePresent === true
      : checkpointStatus === 'written' ||
        checkpointStatus === 'bitable_written' ||
        isBitableActionPresent(bitableAction),
    completed: hasOwn(extra, 'completed')
      ? extra.completed === true
      : isCompletedCheckpointStatus(checkpointStatus),
    backupAvailable: hasOwn(extra, 'backupAvailable')
      ? extra.backupAvailable === true
      : hasTargetBackupArtifacts(args, videoId, item),
    contentFingerprint: String(extra.contentFingerprint || item?.contentFingerprint || '').trim(),
    contentNormalizedLength: Number(
      extra.contentNormalizedLength || item?.contentNormalizedLength || 0,
    ),
    dedupeStatus: String(extra.dedupeStatus || item?.dedupeStatus || '').trim(),
    canonicalVideoId: String(extra.canonicalVideoId || item?.canonicalVideoId || '').trim(),
    duplicateOfVideoId: String(extra.duplicateOfVideoId || item?.duplicateOfVideoId || '').trim(),
    duplicateSimilarity: Number.isFinite(Number(extra.duplicateSimilarity))
      ? Number(extra.duplicateSimilarity)
      : Number.isFinite(Number(item?.duplicateSimilarity))
        ? Number(item.duplicateSimilarity)
        : null,
    dedupeReason: String(extra.dedupeReason || item?.dedupeReason || '').trim(),
    bitableRecordId: String(extra.bitableRecordId || item?.bitableRecordId || '').trim(),
    failedStage: extra.failedStage === null
      ? null
      : String(extra.failedStage || item?.failedStage || '').trim(),
    error: extra.error === null ? null : String(extra.error || item?.error || '').trim(),
  };
  if (hasOwn(extra, 'timelinePresent')) {
    payload.timelinePresent = extra.timelinePresent === true;
  }
  if (hasOwn(extra, 'timelineSource')) {
    payload.timelineSource = String(extra.timelineSource || '').trim();
  }
  return payload;
}

function seedTargetTimelineChecklistFromLocalState(args, checkpoint) {
  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  const catalog = loadTargetCatalog(args);
  const entries = [];

  for (const item of Array.isArray(catalog.items) ? catalog.items : []) {
    const videoId = String(item?.videoId || '').trim();
    if (!videoId) continue;
    entries.push({
      videoId,
      publishTime: String(item.publishTime || '').trim(),
      publishDate: String(item.publishDate || '').trim(),
      title: String(item.title || '').trim(),
      topic: String(item.topic || '').trim(),
      summaryStatus: String(item.summaryStatus || '').trim(),
      docAction: String(item.docAction || '').trim(),
      bitableAction: String(item.bitableAction || '').trim(),
      docPresent: isDocActionPresent(item.docAction),
      bitablePresent: isBitableActionPresent(item.bitableAction),
      completed: isDocActionPresent(item.docAction) && isBitableActionPresent(item.bitableAction),
      backupAvailable: item.backupAvailable === true || hasTargetBackupArtifacts(args, videoId, item),
      bitableRecordId: String(item.bitableRecordId || '').trim(),
    });
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    entries.push(buildChecklistEntryFromCheckpointItem(args, videoId, item));
  }

  return saveTargetTimelineChecklistEntries(args, entries);
}

function noteTimelineDiscoveryToChecklist(args, checkpoint, timeline, items) {
  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  const deduped = dedupeTimelineItems(Array.isArray(items) ? items : []);
  const entries = deduped.map((item) => {
    const checkpointItem = checkpoint.items?.[item.videoId];
    const matchedCheckpointItem =
      checkpointItem && matchesCheckpointTarget(checkpointItem, targetSignature) ? checkpointItem : {};
    return buildChecklistEntryFromCheckpointItem(args, item.videoId, matchedCheckpointItem, {
      publishTime: item.publishTime || matchedCheckpointItem.publishTime || '',
      publishDate: getPublishDate(item.publishTime || matchedCheckpointItem.publishTime || ''),
      title: item.title || matchedCheckpointItem.title || '',
      timelinePresent: true,
      timelineSource: timeline?.source || '',
      status: matchedCheckpointItem.status || 'pending',
    });
  });

  const ordered = deduped.slice().sort(compareChecklistEntriesAsc);
  const coveragePatch = {
    lastDiscoveryAt: new Date().toISOString(),
    lastDiscoverySource: String(timeline?.source || '').trim(),
    lastStopReason: String(timeline?.stopReason || '').trim(),
    lastHasMore: timeline?.hasMore === true,
    lastPageCount: Number(timeline?.pageCount || 0),
    lastDiscoveredCount: ordered.length,
  };
  if (String(timeline?.stopReason || '').trim() === 'end_of_timeline' && timeline?.hasMore !== true) {
    coveragePatch.completeTimeline = true;
    coveragePatch.completeTimelineAt = coveragePatch.lastDiscoveryAt;
    coveragePatch.completeTimelineSource = coveragePatch.lastDiscoverySource;
    coveragePatch.completeTimelineItemCount = ordered.length;
    coveragePatch.oldestPublishTime = ordered[0]?.publishTime || '';
    coveragePatch.newestPublishTime = ordered[ordered.length - 1]?.publishTime || '';
  }
  return saveTargetTimelineChecklistEntries(args, entries, { coveragePatch });
}

function getPendingOldestVideoIdsFromChecklist(args, checkpoint, limit) {
  const checklist = loadTargetTimelineChecklist(args);
  if (checklist.coverage?.completeTimeline !== true) {
    return { checklist, videoIds: [] };
  }
  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  const checkpointWrittenIds = getCheckpointWrittenVideoIds(checkpoint, targetSignature);
  const pending = (Array.isArray(checklist.items) ? checklist.items : [])
    .filter((item) => String(item?.videoId || '').trim())
    .filter((item) => item.timelinePresent !== false)
    .filter((item) => item.completed !== true)
    .filter((item) => String(item?.dedupeStatus || '').trim() !== 'duplicate')
    .filter((item) => !isTerminalSkipStatus(item?.status))
    .filter((item) => !(args.skipDocWrite && !args.forceRewrite && item.bitablePresent === true))
    .filter((item) => !checkpointWrittenIds.has(String(item.videoId || '').trim()))
    .sort(compareChecklistEntriesAsc)
    .slice(0, Math.max(1, Number(limit) || 1))
    .map((item) => String(item.videoId || '').trim())
    .filter(Boolean);
  return { checklist, videoIds: pending };
}

function getExistingTargetBackupDir(args, videoId) {
  const targetRoot = getTargetBackupRoot(args);
  if (!targetRoot || !videoId) {
    return '';
  }
  const targetDir = path.join(targetRoot, videoId);
  return fs.existsSync(targetDir) ? targetDir : '';
}

function listBackupTargetRoots(backupRoot) {
  if (!backupRoot || !fs.existsSync(backupRoot)) {
    return [];
  }
  return fs
    .readdirSync(backupRoot)
    .map((name) => path.join(backupRoot, name))
    .filter((candidate) => {
      try {
        return fs.statSync(candidate).isDirectory();
      } catch {
        return false;
      }
    });
}

function patchBackupTargetMetadataRecursive(dirPath, target) {
  if (!dirPath || !fs.existsSync(dirPath)) {
    return;
  }
  for (const entry of fs.readdirSync(dirPath, { withFileTypes: true })) {
    const fullPath = path.join(dirPath, entry.name);
    if (entry.isDirectory()) {
      patchBackupTargetMetadataRecursive(fullPath, target);
      continue;
    }
    if (entry.name !== 'meta.json') continue;
    const payload = readJsonFileSafe(fullPath);
    if (!payload) continue;
    payload.writeTarget = {
      docToken: target.docToken,
      bitableAppToken: target.bitableAppToken,
      bitableTableId: target.bitableTableId,
    };
    writeJsonFile(fullPath, payload);
  }
}

function rankBackupCandidate(candidate, targetRoot) {
  const meta = candidate?.meta || {};
  const score = [
    candidate?.dir === targetRoot ? 1000000 : 0,
    getAsrModelRank(meta.asrModel || ''),
    getSummaryStatusRank(meta.summaryStatus || ''),
    Date.parse(meta.backedUpAt || '') || 0,
  ];
  return score;
}

function compareRankTupleDesc(left, right) {
  for (let index = 0; index < Math.max(left.length, right.length); index += 1) {
    const diff = Number(right[index] || 0) - Number(left[index] || 0);
    if (diff !== 0) {
      return diff;
    }
  }
  return 0;
}

function findBestBackupCandidate(args, videoId) {
  const backupRoot = String(args?.backupDir || '').trim();
  if (!backupRoot || !videoId) {
    return null;
  }
  const targetRoot = getTargetBackupRoot(args);
  const candidates = [];
  for (const root of listBackupTargetRoots(backupRoot)) {
    const dir = path.join(root, videoId);
    if (!fs.existsSync(dir)) continue;
    const recordPath = path.join(dir, 'record.json');
    if (!fs.existsSync(recordPath)) continue;
    candidates.push({
      dir,
      recordPath,
      meta: readJsonFileSafe(path.join(dir, 'meta.json')) || {},
    });
  }
  if (!candidates.length) {
    return null;
  }
  candidates.sort((left, right) =>
    compareRankTupleDesc(rankBackupCandidate(left, targetRoot), rankBackupCandidate(right, targetRoot)),
  );
  return candidates[0];
}

function ensureTargetBackupFromCandidate(args, videoId, candidate) {
  const targetRoot = getTargetBackupRoot(args);
  if (!targetRoot || !videoId) {
    return '';
  }
  const targetDir = path.join(targetRoot, videoId);
  if (!fs.existsSync(targetDir)) {
    if (!candidate?.dir || !fs.existsSync(candidate.dir)) {
      return '';
    }
    fs.mkdirSync(path.dirname(targetDir), { recursive: true });
    fs.cpSync(candidate.dir, targetDir, { recursive: true });
  }
  patchBackupTargetMetadataRecursive(targetDir, args.writeTarget || buildWriteTarget(args));
  return targetDir;
}

function extractDocVideoIds(rawContent) {
  const text = String(rawContent || '');
  const ids = new Set();
  for (const match of text.matchAll(/https?:\/\/(?:www\.)?douyin\.com\/video\/(\d{10,32})/g)) {
    ids.add(String(match[1] || '').trim());
  }
  for (const match of text.matchAll(/https?:\/\/(?:www\.)?iesdouyin\.com\/share\/video\/(\d{10,32})/g)) {
    ids.add(String(match[1] || '').trim());
  }
  return [...ids].filter(Boolean);
}

function getBitableRecordVideoId(record) {
  return String(record?.fields?.['视频ID:'] || record?.fields?.视频ID || '').trim();
}

function getBitableRecordPublishTime(record) {
  const value = record?.fields?.发布日期;
  if (typeof value === 'string') {
    return value.trim();
  }
  if (Array.isArray(value)) {
    return String(value[0] || '').trim();
  }
  return '';
}

function getReconciledStatus(docPresent, bitablePresent) {
  if (docPresent && bitablePresent) return 'written';
  if (docPresent) return 'doc_only';
  if (bitablePresent) return 'bitable_only';
  return 'resolved';
}

function hasTargetBackupArtifacts(args, videoId, item = null) {
  if (!videoId) {
    return false;
  }
  if (getExistingTargetBackupDir(args, videoId)) {
    return true;
  }
  const backupPath = String(item?.backupPath || '').trim();
  if (backupPath && fs.existsSync(backupPath)) {
    return true;
  }
  return Boolean(findBestBackupCandidate(args, videoId)?.recordPath);
}

function collectMissingBackupInputs(args, checkpoint) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetSignature = buildWriteTargetSignature(target);
  const catalog = loadTargetCatalog(args);
  const candidates = new Map();

  const pushCandidate = (videoId, payload = {}) => {
    const key = String(videoId || '').trim();
    if (!key) return;
    const existing = candidates.get(key) || {};
    const merged = {
      videoId: key,
      publishTime: String(payload.publishTime || existing.publishTime || '').trim(),
      title: String(payload.title || existing.title || '').trim(),
      status: String(payload.status || existing.status || '').trim(),
    };
    candidates.set(key, merged);
  };

  for (const item of Array.isArray(catalog.items) ? catalog.items : []) {
    const videoId = String(item?.videoId || '').trim();
    if (!videoId) continue;
    if (hasTargetBackupArtifacts(args, videoId, item)) continue;
    pushCandidate(videoId, item);
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    if (hasTargetBackupArtifacts(args, videoId, item)) {
      continue;
    }
    pushCandidate(videoId, item);
  }

  const ordered = [...candidates.values()].sort((left, right) => {
    const leftTs = parsePublishTimestamp(left.publishTime) ?? 0;
    const rightTs = parsePublishTimestamp(right.publishTime) ?? 0;
    if (leftTs !== rightTs) {
      return rightTs - leftTs;
    }
    return String(right.videoId || '').localeCompare(String(left.videoId || ''));
  });

  const effectiveLimit = args.limitProvided
    ? Math.max(1, Number(args.limit) || ordered.length)
    : ordered.length;
  return ordered.slice(0, effectiveLimit).map((item) => item.videoId);
}

function collectDocPendingInputs(args, checkpoint) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetSignature = buildWriteTargetSignature(target);
  const checklist = loadTargetTimelineChecklist(args);
  const candidates = new Map();
  const rewriteAllDocs = args.backfillDocAll === true;

  const pushCandidate = (videoId, payload = {}) => {
    const key = String(videoId || '').trim();
    if (!key) return;
    if (!hasTargetBackupArtifacts(args, key, payload)) {
      return;
    }
    const existing = candidates.get(key) || {};
    candidates.set(key, {
      videoId: key,
      publishTime: String(payload.publishTime || existing.publishTime || '').trim(),
      title: String(payload.title || existing.title || '').trim(),
      status: String(payload.status || existing.status || '').trim(),
      docPending: payload.docPending === true || existing.docPending === true,
      docPresent: payload.docPresent === true || existing.docPresent === true,
      bitablePresent: payload.bitablePresent === true || existing.bitablePresent === true,
    });
  };

  for (const item of Array.isArray(checklist.items) ? checklist.items : []) {
    const videoId = String(item?.videoId || '').trim();
    if (!videoId) continue;
    const checkpointItem = checkpoint?.items?.[videoId] || null;
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    if (rewriteAllDocs && String(checkpointItem?.docRewriteCompletedAt || '').trim()) {
      continue;
    }
    const shouldQueue = rewriteAllDocs
      ? true
      : item?.bitablePresent === true &&
        item?.docPresent !== true &&
        String(item?.status || '').trim() !== 'written';
    if (!shouldQueue) continue;
    pushCandidate(videoId, item);
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    if (rewriteAllDocs && String(item?.docRewriteCompletedAt || '').trim()) {
      continue;
    }
    const shouldQueue = rewriteAllDocs
      ? true
      : item?.docPending === true ||
        (String(item?.status || '').trim() === 'bitable_written' &&
          !isDocActionPresent(item?.docAction || ''));
    if (!shouldQueue) continue;
    pushCandidate(videoId, {
      videoId,
      publishTime: item.publishTime || '',
      title: item.title || '',
      status: item.status || '',
      docPending: item.docPending === true,
      docPresent: false,
      bitablePresent: true,
      backupPath: item.backupPath || '',
    });
  }

  const ordered = [...candidates.values()].sort((left, right) => {
    const leftTs = parsePublishTimestamp(left.publishTime) ?? 0;
    const rightTs = parsePublishTimestamp(right.publishTime) ?? 0;
    if (leftTs !== rightTs) {
      return leftTs - rightTs;
    }
    return String(left.videoId || '').localeCompare(String(right.videoId || ''));
  });

  const effectiveLimit = args.limitProvided
    ? Math.max(1, Number(args.limit) || ordered.length)
    : ordered.length;
  let selected = ordered;
  const startAfterVideoId = String(args.startAfterVideoId || '').trim();
  if (startAfterVideoId) {
    const startIndex = selected.findIndex((item) => String(item.videoId || '').trim() === startAfterVideoId);
    if (startIndex >= 0) {
      selected = selected.slice(startIndex + 1);
    }
  }
  return selected.slice(0, effectiveLimit).map((item) => item.videoId);
}

function selectExplicitVideoInputs(args, checkpoint, mode = 'all') {
  const targetSignature = buildWriteTargetSignature(args.writeTarget || buildWriteTarget(args));
  const deduped = collectExplicitVideoIds(args);

  let selected = deduped.filter((videoId) => {
    const existing = checkpoint.items?.[videoId];
    if (!existing || !matchesCheckpointTarget(existing, targetSignature)) {
      return true;
    }
    if (mode === 'all') {
      return !String(existing.docRewriteCompletedAt || '').trim();
    }
    if (String(existing?.dedupeStatus || '').trim() === 'duplicate' || isTerminalSkipStatus(existing?.status)) {
      return false;
    }
    return (
      existing?.docPending === true ||
      (String(existing?.status || '').trim() === 'bitable_written' &&
        !isDocActionPresent(existing?.docAction || ''))
    );
  });
  const startAfterVideoId = String(args.startAfterVideoId || '').trim();
  if (startAfterVideoId) {
    const startIndex = selected.findIndex((videoId) => videoId === startAfterVideoId);
    if (startIndex >= 0) {
      selected = selected.slice(startIndex + 1);
    }
  }

  const effectiveLimit = args.limitProvided
    ? Math.max(1, Number(args.limit) || selected.length)
    : selected.length;
  return selected.slice(0, effectiveLimit);
}

function collectCommentsEngagementRefreshInputs(args, checkpoint) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetSignature = buildWriteTargetSignature(target);
  const catalog = loadTargetCatalog(args);
  const candidates = new Map();

  const pushCandidate = (videoId, payload = {}) => {
    const key = String(videoId || '').trim();
    if (!key) return;
    if (!hasTargetBackupArtifacts(args, key, payload)) {
      return;
    }
    const existing = candidates.get(key) || {};
    candidates.set(key, {
      videoId: key,
      publishTime: String(payload.publishTime || existing.publishTime || '').trim(),
      title: String(payload.title || existing.title || '').trim(),
      status: String(payload.status || existing.status || '').trim(),
      dedupeStatus: String(payload.dedupeStatus || existing.dedupeStatus || '').trim(),
    });
  };

  for (const item of Array.isArray(catalog.items) ? catalog.items : []) {
    const videoId = String(item?.videoId || '').trim();
    if (!videoId) continue;
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    pushCandidate(videoId, item);
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    pushCandidate(videoId, {
      videoId,
      publishTime: item.publishTime || '',
      title: item.title || '',
      status: item.status || '',
      dedupeStatus: item.dedupeStatus || '',
      backupPath: item.backupPath || '',
    });
  }

  const ordered = [...candidates.values()]
    .filter((item) => {
      if (args.forceRewrite) {
        return true;
      }
      const checkpointItem = checkpoint?.items?.[item.videoId];
      if (!checkpointItem) {
        return true;
      }
      if (!matchesCheckpointTarget(checkpointItem, targetSignature)) {
        return true;
      }
      return !String(checkpointItem.engagementRefreshedAt || '').trim();
    })
    .sort(compareCatalogEntriesDesc);
  const effectiveLimit = args.limitProvided
    ? Math.max(1, Number(args.limit) || ordered.length)
    : ordered.length;
  return ordered.slice(0, effectiveLimit).map((item) => item.videoId);
}

function normalizedCommentTextsForEngagementCompare(comments) {
  return (Array.isArray(comments) ? comments : [])
    .map((c) => String(c || '').trim())
    .filter(Boolean)
    .sort((a, b) => a.localeCompare(b, 'zh'));
}

function engagementCountsLine(source) {
  return [
    Number(source.diggCount || 0),
    Number(source.collectCount || 0),
    Number(source.commentCount || 0),
    Number(source.shareCount || 0),
  ].join('|');
}

function commentsEngagementFingerprint(comments) {
  const parts = normalizedCommentTextsForEngagementCompare(comments);
  return crypto.createHash('sha256').update(parts.join('\u0001'), 'utf8').digest('hex');
}

function formatEngagementCountChange(label, beforeValue, afterValue) {
  const before = Number(beforeValue || 0);
  const after = Number(afterValue || 0);
  if (before === after) {
    return '';
  }
  return `${label} ${before}->${after}`;
}

function buildEngagementUpdatedItem({
  videoId,
  record,
  previousSnapshot,
  comments,
  commentBodyStatus,
  action,
}) {
  const changes = [
    formatEngagementCountChange('点赞', previousSnapshot?.diggCount, record?.diggCount),
    formatEngagementCountChange('收藏', previousSnapshot?.collectCount, record?.collectCount),
    formatEngagementCountChange('评论', previousSnapshot?.commentCount, record?.commentCount),
    formatEngagementCountChange('转发', previousSnapshot?.shareCount, record?.shareCount),
  ].filter(Boolean);

  const previousCommentFingerprint = commentsEngagementFingerprint(previousSnapshot?.comments || []);
  const nextCommentFingerprint = commentsEngagementFingerprint(comments || []);
  if (commentBodyStatus === 'fetched') {
    if (previousCommentFingerprint !== nextCommentFingerprint) {
      changes.push('评论正文已刷新');
    } else if (Number(record?.commentCount || 0) > 0) {
      changes.push('评论正文已核对');
    }
  } else if (commentBodyStatus === 'unavailable_reused') {
    changes.push('评论正文不可见，沿用旧评论');
  } else if (commentBodyStatus === 'unavailable_empty') {
    changes.push('评论正文不可见');
  }

  if (!changes.length) {
    changes.push('评论与互动已刷新');
  }

  return {
    videoId: String(videoId || '').trim(),
    publishDate: getPublishDate(record?.publishTime || ''),
    topic: normalizeTopic(record?.topic || ''),
    title: String(record?.title || '').trim(),
    link: videoId ? `https://www.douyin.com/video/${videoId}` : '',
    action: String(action || 'update').trim() || 'update',
    changes,
  };
}

function shouldSkipEngagementRefreshAfterFetch(record, videoInfo, fetchedComments) {
  if (engagementCountsLine(record) !== engagementCountsLine(videoInfo)) {
    return false;
  }
  const rc = Number(videoInfo.commentCount || 0);
  const localNorm = normalizedCommentTextsForEngagementCompare(record.comments);
  if (rc === 0) {
    return localNorm.length === 0;
  }
  if (!fetchedComments.length && !localNorm.length) {
    return true;
  }
  return (
    commentsEngagementFingerprint(record.comments) === commentsEngagementFingerprint(fetchedComments)
  );
}

function collectRecentEngagementRefreshCandidates(args, checkpoint, recentDays) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetSignature = buildWriteTargetSignature(target);
  const catalog = loadTargetCatalog(args);
  const candidates = new Map();
  const windowMs = Math.max(1, Number(recentDays) || 7) * 86400000;
  const cutoff = Date.now() - windowMs;

  const pushCandidate = (videoId, payload = {}) => {
    const key = String(videoId || '').trim();
    if (!key) return;
    const publishTime = String(payload.publishTime || '').trim();
    const publishTs = parsePublishTimestamp(publishTime);
    if (publishTs === null || publishTs < cutoff) {
      return;
    }
    if (!hasTargetBackupArtifacts(args, key, payload)) {
      return;
    }
    const existing = candidates.get(key) || {};
    candidates.set(key, {
      videoId: key,
      publishTime: String(payload.publishTime || existing.publishTime || '').trim(),
      title: String(payload.title || existing.title || '').trim(),
      status: String(payload.status || existing.status || '').trim(),
      dedupeStatus: String(payload.dedupeStatus || existing.dedupeStatus || '').trim(),
    });
  };

  for (const item of Array.isArray(catalog.items) ? catalog.items : []) {
    const videoId = String(item?.videoId || '').trim();
    if (!videoId) continue;
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    pushCandidate(videoId, item);
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    if (
      String(item?.dedupeStatus || '').trim() === 'duplicate' ||
      isTerminalSkipStatus(item?.status)
    ) {
      continue;
    }
    pushCandidate(videoId, {
      videoId,
      publishTime: item.publishTime || '',
      title: item.title || '',
      status: item.status || '',
      dedupeStatus: item.dedupeStatus || '',
      backupPath: item.backupPath || '',
    });
  }

  const ordered = [...candidates.values()].sort(compareCatalogEntriesDesc);
  const effectiveLimit = args.limitProvided
    ? Math.max(1, Number(args.limit) || ordered.length)
    : ordered.length;
  return ordered.slice(0, effectiveLimit).map((item) => item.videoId);
}

function createWriteIndexEntry(payload = {}) {
  const publishTime = String(payload.publishTime || '').trim();
  return {
    videoId: String(payload.videoId || '').trim(),
    publishTime,
    publishTimestamp: parsePublishTimestamp(publishTime) ?? parsePublishTimestamp(payload.publishDate || ''),
    docPresent:
      ['create', 'replace', 'keep'].includes(String(payload.docAction || '').trim()) ||
      payload.docPresent === true,
  };
}

function applyWriteIndexStateEntry(state, payload) {
  const entry = createWriteIndexEntry(payload);
  if (!entry.videoId) {
    return;
  }

  const existing = state.entriesByVideoId.get(entry.videoId);
  const merged = {
    ...(existing || {}),
    ...entry,
    docPresent: entry.docPresent || existing?.docPresent || false,
  };
  state.entriesByVideoId.set(entry.videoId, merged);

  if (merged.docPresent) {
    state.docVideoIds.add(entry.videoId);
  } else {
    state.docVideoIds.delete(entry.videoId);
  }
}

function rebuildWriteIndexStateRanges(state) {
  const ordered = [...state.entriesByVideoId.values()]
    .filter((entry) => entry.docPresent && entry.publishTimestamp !== null)
    .sort((left, right) => right.publishTimestamp - left.publishTimestamp);
  state.orderedDocEntries = ordered;
  state.newestPublishTimestamp = ordered[0]?.publishTimestamp ?? null;
  state.oldestPublishTimestamp = ordered.length
    ? ordered[ordered.length - 1].publishTimestamp
    : null;
}

function loadWriteIndexState(args, checkpoint) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetKey = buildWriteTargetKey(target);
  const targetSignature = buildWriteTargetSignature(target);
  const state = {
    targetKey,
    targetSignature,
    entriesByVideoId: new Map(),
    docVideoIds: new Set(),
    orderedDocEntries: [],
    newestPublishTimestamp: null,
    oldestPublishTimestamp: null,
  };

  for (const row of readJsonl(args.indexLogPath)) {
    const rowTargetKey =
      String(row.targetKey || '').trim() ||
      buildWriteTargetKey(row.target || {});
    if (rowTargetKey !== targetKey) {
      continue;
    }
    applyWriteIndexStateEntry(state, row);
  }

  for (const [videoId, item] of Object.entries(checkpoint?.items || {})) {
    if (!matchesCheckpointTarget(item, targetSignature)) {
      continue;
    }
    if (String(item?.status || '').trim() !== 'written') {
      continue;
    }
    applyWriteIndexStateEntry(state, {
      videoId,
      publishTime: item.publishTime || '',
      publishDate: item.publishDate || '',
      docAction: item.docAction || 'create',
      docPresent: String(item.docAction || 'create').trim() !== 'skip',
    });
  }

  rebuildWriteIndexStateRanges(state);
  return state;
}

function noteWriteIndexSuccess(state, record, result) {
  if (!state || !record?.videoId) {
    return;
  }
  applyWriteIndexStateEntry(state, {
    videoId: record.videoId,
    publishTime: record.publishTime || '',
    publishDate: getPublishDate(record.publishTime),
    docAction: result.docAction || 'create',
    docPresent: isDocActionPresent(result.docAction),
  });
  rebuildWriteIndexStateRanges(state);
}

function updateItemCheckpoint(checkpoint, checkpointPath, videoId, patch) {
  if (!checkpointPath) {
    return;
  }
  const nextItem = {
    ...(checkpoint.items[videoId] || {}),
    ...patch,
    updatedAt: new Date().toISOString(),
  };
  for (const [key, value] of Object.entries(nextItem)) {
    if (value === null) {
      delete nextItem[key];
    }
  }
  checkpoint.items[videoId] = nextItem;
  saveCheckpoint(checkpointPath, checkpoint);
}

function checkpointClearFailurePatch() {
  return {
    failedStage: null,
    error: null,
    summaryError: null,
    summaryDocError: null,
    summaryBitableError: null,
  };
}

async function formatDoc(recordPath) {
  return runPython([path.join(LIB_DIR, 'pipeline_utils.py'), 'format-doc', recordPath]);
}

function appendWriteIndexLog(args, checkpointPath, result, record, bitableResult) {
  const target = args.writeTarget || buildWriteTarget(args);
  if (args.indexLogPath) {
    appendJsonl(args.indexLogPath, {
      writtenAt: new Date().toISOString(),
      publishDate: getPublishDate(record.publishTime),
      publishTime: record.publishTime || '',
      videoId: record.videoId || '',
      title: record.title || '',
      topic: record.topic || '',
      docToken: target.docToken,
      bitableAppToken: target.bitableAppToken,
      bitableTableId: target.bitableTableId,
      docAction: result.docAction || '',
      bitableAction: result.bitableAction || '',
      summaryStatus: result.summaryStatus || '',
      bitableRecordId: bitableResult?.record?.record_id || '',
      backupPath: result.backupPath || '',
      targetKey: buildWriteTargetKey(target),
      target: {
        docToken: target.docToken,
        bitableAppToken: target.bitableAppToken,
        bitableTableId: target.bitableTableId,
      },
      checkpointPath: checkpointPath || '',
    });
  }
  upsertTargetCatalogEntry(args, result, record, bitableResult);
}

async function reconcileTarget(client, args, checkpoint, checkpointPath) {
  const prefix = '[reconcile]';
  const targetSignature = buildWriteTargetSignature(args.writeTarget);
  const currentIndexState = loadWriteIndexState(args, checkpoint);
  const existingIndexIds = new Set(currentIndexState.docVideoIds || []);
  const existingCatalog = loadTargetCatalog(args);
  const existingCatalogIds = new Set(
    (Array.isArray(existingCatalog.items) ? existingCatalog.items : [])
      .map((item) => String(item?.videoId || '').trim())
      .filter(Boolean),
  );

  const rawContent = await withProgress(prefix, '读取飞书文档原始内容', () =>
    feishu.readDocumentRaw(client, args.docToken),
  );
  const docSections = await withProgress(prefix, '扫描飞书文档视频区块', () =>
    feishu.listVideoSections(client, args.docToken),
  );
  const docVideoIds = new Set(extractDocVideoIds(rawContent));

  const bitableRecords = await withProgress(prefix, '读取多维表格记录', () =>
    feishu.listAllRecords(client, args.bitableAppToken, args.bitableTableId),
  );
  const bitableByVideoId = new Map();
  for (const record of bitableRecords) {
    const videoId = getBitableRecordVideoId(record);
    if (!videoId || bitableByVideoId.has(videoId)) continue;
    bitableByVideoId.set(videoId, record);
  }

  const candidateIds = new Set([
    ...docVideoIds,
    ...bitableByVideoId.keys(),
    ...existingIndexIds,
    ...existingCatalogIds,
  ]);

  const unresolved = [];
  let addedIndexCount = 0;
  let copiedBackupCount = 0;
  let reconciledCount = 0;
  const catalogEntries = [];

  const orderedIds = [...candidateIds].sort((left, right) => {
    const leftCandidate = findBestBackupCandidate(args, left);
    const rightCandidate = findBestBackupCandidate(args, right);
    const leftRecord = leftCandidate ? readJsonFileSafe(leftCandidate.recordPath) : null;
    const rightRecord = rightCandidate ? readJsonFileSafe(rightCandidate.recordPath) : null;
    const leftCheckpoint = checkpoint.items?.[left] || {};
    const rightCheckpoint = checkpoint.items?.[right] || {};
    const leftBitable = bitableByVideoId.get(left);
    const rightBitable = bitableByVideoId.get(right);
    const leftPublishTime =
      leftRecord?.publishTime ||
      leftCheckpoint.publishTime ||
      getBitableRecordPublishTime(leftBitable) ||
      '';
    const rightPublishTime =
      rightRecord?.publishTime ||
      rightCheckpoint.publishTime ||
      getBitableRecordPublishTime(rightBitable) ||
      '';
    const leftTs = parsePublishTimestamp(leftPublishTime) ?? 0;
    const rightTs = parsePublishTimestamp(rightPublishTime) ?? 0;
    if (leftTs !== rightTs) {
      return rightTs - leftTs;
    }
    return String(right).localeCompare(String(left));
  });

  logProgress(
    prefix,
    `开始对账: 文档区块 ${docSections.length} 条 | 文档视频ID ${docVideoIds.size} 条 | 多维表格视频ID ${bitableByVideoId.size} 条 | 候选总数 ${orderedIds.length} 条`,
  );

  for (const [index, videoId] of orderedIds.entries()) {
    const itemPrefix = `${prefix}[${index + 1}/${orderedIds.length}][${videoId}]`;
    const docPresent = docVideoIds.has(videoId);
    const bitableRecord = bitableByVideoId.get(videoId) || null;
    const bitablePresent = Boolean(bitableRecord);
    const backupCandidate = findBestBackupCandidate(args, videoId);
    const previousTargetDir = getExistingTargetBackupDir(args, videoId);
    const targetBackupDir = ensureTargetBackupFromCandidate(args, videoId, backupCandidate);
    if (!previousTargetDir && targetBackupDir) {
      copiedBackupCount += 1;
    }

    const record =
      (targetBackupDir && readJsonFileSafe(path.join(targetBackupDir, 'record.json'))) ||
      (backupCandidate && readJsonFileSafe(backupCandidate.recordPath)) ||
      null;
    const meta =
      (targetBackupDir && readJsonFileSafe(path.join(targetBackupDir, 'meta.json'))) ||
      backupCandidate?.meta ||
      {};

    const publishTime =
      record?.publishTime ||
      checkpoint.items?.[videoId]?.publishTime ||
      getBitableRecordPublishTime(bitableRecord) ||
      '';

    if (!record) {
      unresolved.push({
        videoId,
        publishTime,
        docPresent,
        bitablePresent,
      });
      logProgress(
        itemPrefix,
        `缺少本地备份，已仅记录存在性: 文档 ${docPresent ? 'yes' : 'no'} | 表格 ${bitablePresent ? 'yes' : 'no'}`,
      );
    }

    const nextStatus = getReconciledStatus(docPresent, bitablePresent);
    const summaryCount = Array.isArray(record?.keyPoints)
      ? record.keyPoints.length
      : Number(checkpoint.items?.[videoId]?.summaryCount || 0);
    const result = {
      docAction: docPresent ? 'keep' : 'missing',
      bitableAction: bitablePresent ? 'keep' : 'missing',
      summaryStatus:
        checkpoint.items?.[videoId]?.summaryStatus ||
        (summaryCount || record?.topic ? 'ready' : meta.summaryStatus || ''),
      backupPath: targetBackupDir || '',
      bitableRecordId: bitableRecord?.record_id || checkpoint.items?.[videoId]?.bitableRecordId || '',
    };
    const normalizedRecord = record || {
      videoId,
      publishTime,
      title: checkpoint.items?.[videoId]?.title || '',
      topic: checkpoint.items?.[videoId]?.summaryTopic || '',
      keyPoints: [],
    };

    updateItemCheckpoint(checkpoint, checkpointPath, videoId, {
      input: checkpoint.items?.[videoId]?.input || videoId,
      title: normalizedRecord.title || checkpoint.items?.[videoId]?.title || '',
      publishTime,
      publishDate: getPublishDate(publishTime),
      status: nextStatus,
      asrModel: meta.asrModel || checkpoint.items?.[videoId]?.asrModel || '',
      asrAttempts: meta.asrAttempts || checkpoint.items?.[videoId]?.asrAttempts || [],
      asrFallbackUsed:
        meta.asrFallbackUsed === true ||
        checkpoint.items?.[videoId]?.asrFallbackUsed === true,
      asrPrimaryError: meta.asrPrimaryError || checkpoint.items?.[videoId]?.asrPrimaryError || '',
      summaryStatus: result.summaryStatus || null,
      summaryTopic: normalizedRecord.topic || checkpoint.items?.[videoId]?.summaryTopic || null,
      summaryCount,
      backupPath: targetBackupDir || checkpoint.items?.[videoId]?.backupPath || null,
      backupPathRelative:
        targetBackupDir
          ? safeRelativePath(targetBackupDir)
          : checkpoint.items?.[videoId]?.backupPathRelative || null,
      docSkipped: docPresent,
      docAction: result.docAction,
      docPending: false,
      bitableAction: result.bitableAction,
      bitableRecordId: result.bitableRecordId || null,
      ...checkpointClearFailurePatch(),
      ...buildCheckpointTargetPatch(args.writeTarget),
    });

    if (docPresent && !existingIndexIds.has(videoId)) {
      appendWriteIndexLog(args, checkpointPath, result, normalizedRecord, bitableRecord ? { record: bitableRecord } : null);
      existingIndexIds.add(videoId);
      addedIndexCount += 1;
    }

    catalogEntries.push({
      videoId,
      publishDate: getPublishDate(publishTime),
      publishTime,
      title: normalizedRecord.title || '',
      topic: normalizedRecord.topic || '',
      summaryStatus: result.summaryStatus || '',
      docAction: result.docAction,
      bitableAction: result.bitableAction,
      bitableRecordId: result.bitableRecordId || '',
      backupPath: targetBackupDir || '',
      backupPathRelative: targetBackupDir ? safeRelativePath(targetBackupDir) : '',
      backupAvailable: Boolean(targetBackupDir),
      target: args.writeTarget,
      updatedAt: new Date().toISOString(),
    });

    reconciledCount += 1;
  }

  const rebuiltCatalogItems = saveTargetCatalogEntries(args, catalogEntries);
  seedTargetTimelineChecklistFromLocalState(args, checkpoint);
  logProgress(
    prefix,
    `对账完成: checkpoint ${reconciledCount} 条 | 新增目录 ${copiedBackupCount} 条 | 新增索引 ${addedIndexCount} 条 | catalog ${rebuiltCatalogItems.length} 条`,
  );
  if (unresolved.length) {
    logProgress(prefix, `仍有 ${unresolved.length} 条缺少本地备份，后续如需重写需补原始产物`);
    for (const item of unresolved.slice(0, 10)) {
      logProgress(
        prefix,
        `缺备份: ${item.videoId} | 发布时间 ${item.publishTime || '未知'} | 文档 ${item.docPresent ? 'yes' : 'no'} | 表格 ${item.bitablePresent ? 'yes' : 'no'}`,
      );
    }
  }
}

function shouldBatchDocWrites(args, totalInputs) {
  if (args.dryRun || args.forceRewrite || args.skipDocWrite || args.backfillDocPending || totalInputs <= 1) {
    return false;
  }
  return ['oldest', 'date', 'month', 'recent'].includes(String(args.syncMode || '').trim());
}

function buildDocWritePolicy(args, totalInputs) {
  return {
    enabled: shouldBatchDocWrites(args, totalInputs),
    batchSize: FEISHU_DOC_BATCH_SIZE,
    singleMinIntervalMs: FEISHU_DOC_MIN_INTERVAL_MS,
    batchMinIntervalMs: FEISHU_DOC_BATCH_MIN_INTERVAL_MS,
  };
}

function compareByPublishTimeAsc(left, right) {
  const leftTs = parsePublishTimestamp(left?.record?.publishTime || left?.publishTime || '') ?? 0;
  const rightTs = parsePublishTimestamp(right?.record?.publishTime || right?.publishTime || '') ?? 0;
  return leftTs - rightTs;
}

function compareByPublishTimeDesc(left, right) {
  return compareByPublishTimeAsc(right, left);
}

function getLocalBatchInsertIndex(args, batchItems) {
  const state = args.writeIndexState;
  if (!state) {
    return undefined;
  }

  const ordered = batchItems.slice().sort(compareByPublishTimeDesc);
  const newestTs = parsePublishTimestamp(ordered[0]?.record?.publishTime || '') ?? null;
  const oldestTs =
    parsePublishTimestamp(ordered[ordered.length - 1]?.record?.publishTime || '') ?? null;

  if (!state.orderedDocEntries.length) {
    return null;
  }

  if (String(args.syncMode || '').trim() === 'oldest' && !args.forceRewrite) {
    return 0;
  }

  if (
    newestTs !== null &&
    state.newestPublishTimestamp !== null &&
    newestTs >= state.newestPublishTimestamp
  ) {
    return 0;
  }

  if (
    oldestTs !== null &&
    state.oldestPublishTimestamp !== null &&
    oldestTs <= state.oldestPublishTimestamp
  ) {
    return null;
  }

  return undefined;
}

async function resolveBatchInsertIndex(client, args, batchItems) {
  const localIndex = getLocalBatchInsertIndex(args, batchItems);
  if (localIndex !== undefined) {
    return localIndex;
  }
  const ordered = batchItems.slice().sort(compareByPublishTimeDesc);
  const newestItem = ordered[0];
  return feishu.findVideoSectionInsertIndex(client, args.docToken, newestItem?.record?.publishTime || '');
}

async function flushPendingDocBatch(client, args, checkpoint, checkpointPath, queue) {
  if (!queue.length) {
    return { flushed: 0, stoppedByRateLimit: false };
  }

  const batchItems = queue.splice(0, queue.length).sort(compareByPublishTimeDesc);
  const firstDate = getPublishDate(batchItems[0]?.record?.publishTime || '');
  const lastDate = getPublishDate(batchItems[batchItems.length - 1]?.record?.publishTime || '');
  const label =
    firstDate && lastDate && firstDate !== lastDate
      ? `批量写入飞书文档（${batchItems.length}条，${firstDate} -> ${lastDate}）`
      : `批量写入飞书文档（${batchItems.length}条）`;
  const prefix = '[doc-batch]';

  try {
    let flushedCount = 0;
    for (const [index, item] of batchItems.entries()) {
      const itemLabel = `${label} 第 ${index + 1}/${batchItems.length} 条`;
      await waitForFeishuDocWriteWindow(
        prefix,
        itemLabel,
        args.docWritePolicy.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
      );
      const docResult = await withProgress(prefix, itemLabel, () =>
        retryOperation({
          prefix,
          label: itemLabel,
          attempts: RETRY_FEISHU_DOC_ATTEMPTS,
          delayMs: Math.max(
            RETRY_FEISHU_DOC_DELAY_MS,
            args.docWritePolicy.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
          ),
          fn: () => maybeAppendDoc(client, args.docToken, item.record, item.sections),
        }),
      );

      updateItemCheckpoint(checkpoint, checkpointPath, item.record.videoId, {
        status: 'written',
        publishDate: getPublishDate(item.record.publishTime),
        docAction: docResult.skipped ? 'keep' : docResult.replaced ? 'replace' : 'create',
        bitableAction: item.result.bitableAction,
        bitableRecordId: item.bitableResult?.record?.record_id || '',
        docSkipped: docResult.skipped || false,
        docPending: false,
        ...checkpointClearFailurePatch(),
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      item.result.docAction = docResult.skipped ? 'keep' : docResult.replaced ? 'replace' : 'create';
      item.result.status = item.result.warnings.length ? 'success_with_warnings' : 'success';
      item.result.totalElapsedMs = Date.now() - item.result.taskStartedAtMs;
      item.result.pendingDoc = null;
      appendWriteIndexLog(args, checkpointPath, item.result, item.record, item.bitableResult);
      noteWriteIndexSuccess(args.writeIndexState, item.record, item.result);
      logProgress(
        buildStepPrefix(item.result.positionLabel, item.record.videoId),
        `文档已批量写入，总耗时 ${formatElapsedMs(item.result.totalElapsedMs)}`,
      );
      flushedCount += 1;
    }

    return { flushed: flushedCount, stoppedByRateLimit: false };
  } catch (err) {
    if (isFeishuRateLimitError(err)) {
      noteFeishuDocRateLimit(err);
    }
    const error = formatError(err);
    for (const item of batchItems) {
      item.result.status = 'failed';
      item.result.failedStage = '批量写入飞书文档';
      item.result.error = error;
      item.result.totalElapsedMs = Date.now() - item.result.taskStartedAtMs;
      item.result.pendingDoc = null;
      updateItemCheckpoint(checkpoint, checkpointPath, item.record.videoId, {
        status: 'failed',
        failedStage: '批量写入飞书文档',
        error,
        docPending: false,
      });
    }
    console.error(`[${nowClock()}]${prefix} 失败: ${error}`);
    return {
      flushed: 0,
      stoppedByRateLimit: STOP_ON_FEISHU_DOC_RATE_LIMIT && isFeishuRateLimitError(err),
    };
  }
}

async function bitableFields(recordPath) {
  return JSON.parse(
    runPython([path.join(LIB_DIR, 'pipeline_utils.py'), 'bitable-fields', recordPath]),
  );
}

async function docSections(recordPath) {
  return JSON.parse(
    runPython([path.join(LIB_DIR, 'pipeline_utils.py'), 'doc-sections', recordPath]),
  );
}

async function buildArtifacts(recordPath) {
  return {
    docContent: await formatDoc(recordPath),
    fields: await bitableFields(recordPath),
    sections: await docSections(recordPath),
  };
}

async function transcribeAudio(audioPath) {
  try {
    const raw = await runAsync(PYTHON_BIN, [path.join(LIB_DIR, 'transcribe.py'), audioPath]);
    return JSON.parse(raw.trim());
  } catch (err) {
    const candidates = [
      String(err?.stdout || '').trim(),
      String(err?.message || '').trim(),
    ].filter(Boolean);
    for (const candidate of candidates) {
      try {
        return JSON.parse(candidate);
      } catch (_parseErr) {
        // Ignore non-JSON stderr/stdout and rethrow the original error below.
      }
    }
    throw err;
  }
}

function buildRecord(videoInfo, transcript, asrDuration) {
  return applyTextCorrectionsToRecord({
    videoId: videoInfo.videoId,
    title: videoInfo.title || '',
    topic: '',
    publishTime: videoInfo.publishTime || '',
    duration: videoInfo.duration || '00:00',
    transcript: transcript || '',
    asrDuration: asrDuration || '约 5 秒',
    transcribedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
    diggCount: Number(videoInfo.diggCount || 0),
    collectCount: Number(videoInfo.collectCount || 0),
    commentCount: Number(videoInfo.commentCount || 0),
    shareCount: Number(videoInfo.shareCount || 0),
    comments: (videoInfo.comments || []).slice(0, 10),
    keyPoints: [],
  });
}

function printUsage() {
  console.log(
    '用法: node douyin-transcribe-to-feishu.js <抖音链接/分享文本/ID...> [--batch file] [--limit N] [--dry-run] [--skip-summary] [--checkpoint path] [--index-log path] [--backup-dir path] [--progress-heartbeat 秒] [--doc-token token] [--bitable-app-token token] [--bitable-table-id id] [--douyin-storage-state path] [--start-after-video-id videoId] [--sync-latest|--sync-incremental|--sync-recent N|--sync-date YYYY-MM-DD|--sync-month YYYY-MM|--sync-oldest N|--rewrite 链接或ID|--reconcile-target|--backfill-missing-backups|--backfill-bitable-fields|--backfill-comments-engagement|--refresh-engagement-recent-days N] [--force-rewrite]',
    '用法: node douyin-transcribe-to-feishu.js <抖音链接/分享文本/ID...> [--batch file] [--limit N] [--dry-run] [--skip-summary] [--skip-doc-write] [--backfill-doc-pending|--backfill-doc-all] [--checkpoint path] [--index-log path] [--backup-dir path] [--progress-heartbeat 秒] [--doc-token token] [--bitable-app-token token] [--bitable-table-id id] [--douyin-storage-state path] [--start-after-video-id videoId] [--sync-latest|--sync-incremental|--sync-recent N|--sync-date YYYY-MM-DD|--sync-month YYYY-MM|--sync-oldest N|--rewrite 链接或ID|--reconcile-target|--backfill-missing-backups|--backfill-bitable-fields|--backfill-comments-engagement|--refresh-engagement-recent-days N] [--force-rewrite]',
  );
}

async function maybeAppendDoc(client, docToken, record, sections, options = {}) {
  const headingText = extractSectionHeadingText(sections);
  return withTimeout(
    feishu.withDocumentMutationLock(docToken, async () => {
      const existingRange =
        (await feishu.findSectionRangeByHeading(client, docToken, headingText)) ||
        (await feishu.findSectionRangeByVideoId(client, docToken, record.videoId));
      if (existingRange) {
        await feishu.replaceVideoSectionSafely(client, docToken, existingRange, sections);
        return { skipped: false, replaced: true, insertIndex: existingRange.startIndex };
      }

      if (!options.skipDocContainsCheck) {
        const exists = await feishu.docContainsVideoId(client, docToken, record.videoId);
        if (exists) {
          return { skipped: true, reason: 'already_exists_in_doc_but_range_not_found' };
        }
      }

      const insertIndex =
        Number.isInteger(options.insertIndex)
          ? options.insertIndex
          : await feishu.findVideoSectionInsertIndex(client, docToken, record.publishTime);
      await feishu.appendVideoSection(client, docToken, sections, insertIndex);
      return { skipped: false, replaced: false, insertIndex };
    }),
    FEISHU_DOC_WRITE_TIMEOUT_MS,
    `飞书文档写入 ${record.videoId || ''}`.trim(),
  );
}

function extractSectionHeadingText(sections) {
  return String(sections?.title_text || sections?.header_markdown || '')
    .replace(/^#+\s*/, '')
    .replace(/^\d+\.\s*/, '')
    .trim();
}

async function upsertBitable(client, appToken, tableId, fields, existingRecord = null) {
  const key = String(fields['视频ID:'] || '').trim();
  if (!key) {
    throw new Error('Bitable 缺少主键字段 视频ID:');
  }
  const existing = existingRecord || (await feishu.findRecordByField(client, appToken, tableId, '视频ID:', key));
  if (existing) {
    return {
      action: 'update',
      record: await feishu.updateRecord(client, appToken, tableId, existing.record_id, fields),
    };
  }
  return {
    action: 'create',
    record: await feishu.createRecord(client, appToken, tableId, fields),
  };
}

async function tryGenerateSummary(videoPrefix, record, checkpoint, checkpointPath, warnings) {
  try {
        const summary = await withProgress(videoPrefix, '生成核心要点摘要', () =>
          retryOperation({
            prefix: videoPrefix,
            label: '生成核心要点摘要',
            attempts: RETRY_SUMMARY_ATTEMPTS,
            delayMs: RETRY_SUMMARY_DELAY_MS,
            fn: () => summarizeRecord(record, { prefix: videoPrefix }),
          }),
        );
    record.topic = normalizeTopic(summary?.topic);
    record.keyPoints = normalizeKeyPoints(summary?.keyPoints);
    applyTextCorrectionsToRecord(record);
    if (record.topic) {
      logProgress(videoPrefix, `自动主题: ${record.topic}`);
    }
    logProgress(videoPrefix, `核心要点数量: ${record.keyPoints.length}`);
    updateItemCheckpoint(checkpoint, checkpointPath, record.videoId, {
      summaryStatus: record.keyPoints.length || record.topic ? 'ready' : 'empty',
      summaryCount: record.keyPoints.length,
      summaryTopic: record.topic || null,
      summaryError: null,
    });
    return true;
  } catch (summaryErr) {
    const message = `摘要生成失败，已继续主链路: ${formatError(summaryErr)}`;
    console.warn(`[${nowClock()}]${videoPrefix} ${message}`);
    warnings.push(message);
    record.topic = '';
    record.keyPoints = [];
    updateItemCheckpoint(checkpoint, checkpointPath, record.videoId, {
      summaryStatus: 'failed',
      summaryTopic: null,
      summaryError: formatError(summaryErr),
    });
    return false;
  }
}

function createProcessResult(positionLabel, input) {
  return {
    positionLabel,
    input,
    taskStartedAtMs: Date.now(),
    videoId: '',
    title: '',
    publishTime: '',
    status: 'failed',
    skipReason: '',
    warnings: [],
    summaryStatus: SUMMARY_ENABLED ? 'pending' : 'skipped',
    docAction: 'not_run',
    bitableAction: 'not_run',
    failedStage: '',
    error: '',
    totalElapsedMs: 0,
    asrModel: '',
    asrAttempts: [],
    asrFallbackUsed: false,
    asrPrimaryError: '',
    backupPath: '',
    contentFingerprint: '',
    contentNormalizedLength: 0,
    dedupeStatus: '',
    canonicalVideoId: '',
    duplicateOfVideoId: '',
    duplicateSimilarity: null,
    dedupeReason: '',
    pendingDoc: null,
  };
}

function buildBitableResultRef(recordId) {
  const normalized = String(recordId || '').trim();
  return normalized ? { record: { record_id: normalized } } : null;
}

async function processPendingDocOne(client, args, checkpoint, checkpointPath, input, index, total) {
  const effectiveCheckpointPath = args.dryRun ? null : checkpointPath;
  const positionLabel = `${index}/${total}`;
  const taskStartedAt = Date.now();
  const result = createProcessResult(positionLabel, input);
  result.taskStartedAtMs = taskStartedAt;
  let currentStage = '初始化';
  const videoId = String(input || '').trim();
  result.videoId = videoId;
  const videoPrefix = buildStepPrefix(positionLabel, videoId);
  const rewriteExistingDoc = args.backfillDocAll === true || args.forceRewrite === true;

  try {
    if (!videoId) {
      throw new Error('缺少视频 ID');
    }
    logProgress(buildStepPrefix(positionLabel), `开始补写文档: ${videoId}`);

    const checkpointItem = checkpoint.items?.[videoId] || {};
    const backupCandidate = findBestBackupCandidate(args, videoId);
    const targetBackupDir = ensureTargetBackupFromCandidate(args, videoId, backupCandidate);
    const recordPath = targetBackupDir
      ? path.join(targetBackupDir, 'record.json')
      : backupCandidate?.recordPath || '';
    if (!recordPath || !fs.existsSync(recordPath)) {
      throw new Error(`缺少本地备份 record.json: ${videoId}`);
    }

    const record = readJsonFileSafe(recordPath);
    if (!record) {
      throw new Error(`本地备份 record.json 无法读取: ${videoId}`);
    }

    result.title = record.title || checkpointItem.title || '';
    result.publishTime = record.publishTime || checkpointItem.publishTime || '';
    result.summaryStatus =
      checkpointItem.summaryStatus ||
      ((Array.isArray(record.keyPoints) && record.keyPoints.length) || record.topic ? 'ready' : 'empty');
    result.bitableAction = checkpointItem.bitableAction || 'keep';
    result.backupPath = targetBackupDir || checkpointItem.backupPath || '';
    const dedupeEntry = getTargetDedupeEntry(args, videoId);
    if (dedupeEntry?.dedupeStatus === 'duplicate') {
      result.status = 'skipped';
      result.skipReason = 'duplicate_content';
      result.docAction = 'skip';
      result.dedupeStatus = 'duplicate';
      result.canonicalVideoId = dedupeEntry.canonicalVideoId || '';
      result.duplicateOfVideoId = dedupeEntry.duplicateOfVideoId || '';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'duplicate_skipped',
        docAction: 'skip',
        docPending: false,
        dedupeStatus: 'duplicate',
        canonicalVideoId: dedupeEntry.canonicalVideoId || null,
        duplicateOfVideoId: dedupeEntry.duplicateOfVideoId || null,
        duplicateSimilarity: Number.isFinite(dedupeEntry.duplicateSimilarity)
          ? dedupeEntry.duplicateSimilarity
          : null,
        dedupeReason: dedupeEntry.dedupeReason || null,
        contentFingerprint: dedupeEntry.contentFingerprint || null,
        contentNormalizedLength: Number(dedupeEntry.normalizedTranscriptLength || 0) || null,
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      logProgress(
        videoPrefix,
        `已跳过文档补写，命中内容级去重，归并到 ${dedupeEntry.duplicateOfVideoId || dedupeEntry.canonicalVideoId || '未知视频'}`,
      );
      return result;
    }

    logProgress(videoPrefix, `标题: ${result.title || '缺失'}`);
    logProgress(videoPrefix, `发布时间: ${result.publishTime || '缺失'}`);

    let sections =
      (targetBackupDir && readJsonFileSafe(path.join(targetBackupDir, 'doc-sections.json'))) ||
      (backupCandidate?.dir && readJsonFileSafe(path.join(backupCandidate.dir, 'doc-sections.json'))) ||
      null;
    if (!sections) {
      currentStage = '重建文档区块';
      sections = await withProgress(videoPrefix, '重建文档区块', () => docSections(recordPath));
    }
    if (!sections) {
      throw new Error(`缺少文档区块数据: ${videoId}`);
    }

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      input: checkpointItem.input || videoId,
      title: result.title,
      publishTime: result.publishTime,
      publishDate: getPublishDate(result.publishTime),
      summaryStatus: result.summaryStatus || null,
      summaryTopic: record.topic || checkpointItem.summaryTopic || null,
      summaryCount: Array.isArray(record.keyPoints) ? record.keyPoints.length : checkpointItem.summaryCount || 0,
      backupPath: result.backupPath || null,
      backupPathRelative: result.backupPath ? safeRelativePath(result.backupPath) : checkpointItem.backupPathRelative || null,
      bitableAction: result.bitableAction,
      bitableRecordId: checkpointItem.bitableRecordId || null,
      ...buildCheckpointTargetPatch(args.writeTarget),
    });

    const docIndexedAsWritten = Boolean(args.writeIndexState?.docVideoIds?.has(videoId));
    let existingDocRange = null;
    if (docIndexedAsWritten && !rewriteExistingDoc) {
      logProgress(videoPrefix, '本地索引显示当前目标文档已写入该视频，跳过飞书文档存在性探测');
    } else {
      currentStage = '检查飞书文档现有区块';
      existingDocRange = await withProgress(videoPrefix, '检查飞书文档现有区块', () =>
        Promise.resolve(feishu.findSectionRangeByHeading(client, args.docToken, extractSectionHeadingText(sections))).then(
          (match) => match || feishu.findSectionRangeByVideoId(client, args.docToken, videoId),
        ),
      );
    }

    if ((docIndexedAsWritten || existingDocRange) && !rewriteExistingDoc) {
      result.docAction = 'keep';
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'written',
        publishDate: getPublishDate(result.publishTime),
        docAction: 'keep',
        docPending: false,
        bitableAction: result.bitableAction,
        bitableRecordId: checkpointItem.bitableRecordId || null,
        ...checkpointClearFailurePatch(),
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      if (!docIndexedAsWritten) {
        appendWriteIndexLog(
          args,
          effectiveCheckpointPath,
          {
            docAction: 'keep',
            bitableAction: result.bitableAction,
            summaryStatus: result.summaryStatus,
            backupPath: result.backupPath || '',
            bitableRecordId: checkpointItem.bitableRecordId || '',
          },
          record,
          buildBitableResultRef(checkpointItem.bitableRecordId),
        );
        noteWriteIndexSuccess(args.writeIndexState, record, {
          docAction: 'keep',
        });
      }
      result.status = 'success';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      logProgress(videoPrefix, `文档已存在，已完成对账，总耗时 ${formatElapsedMs(result.totalElapsedMs)}`);
      return result;
    }

    if (args.dryRun) {
      result.status = 'success';
      result.docAction = 'dry_run';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      return result;
    }

    currentStage = '写入飞书文档';
    const insertIndexHint = getLocalBatchInsertIndex(args, [{ record }]);
    await waitForFeishuDocWriteWindow(
      videoPrefix,
      '写入飞书文档',
      args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
    );
    const docResult = await withProgress(videoPrefix, '写入飞书文档', () =>
      retryOperation({
        prefix: videoPrefix,
        label: '写入飞书文档',
        attempts: RETRY_FEISHU_DOC_ATTEMPTS,
        delayMs: Math.max(
          RETRY_FEISHU_DOC_DELAY_MS,
          args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
        ),
        fn: () =>
          maybeAppendDoc(client, args.docToken, record, sections, {
            ...(existingDocRange ? { existingRange: existingDocRange } : {}),
            ...(rewriteExistingDoc ? { skipDocContainsCheck: true } : {}),
            ...(insertIndexHint !== undefined ? { insertIndex: insertIndexHint } : {}),
          }),
      }),
    );

    const docRewriteCompletedAt = rewriteExistingDoc ? new Date().toISOString() : null;
    result.docAction = docResult.skipped ? 'keep' : docResult.replaced ? 'replace' : 'create';
    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      status: 'written',
      publishDate: getPublishDate(result.publishTime),
      docAction: result.docAction,
      docPending: false,
      docSkipped: docResult.skipped || false,
      docRewriteCompletedAt,
      bitableAction: result.bitableAction,
      bitableRecordId: checkpointItem.bitableRecordId || null,
      ...checkpointClearFailurePatch(),
      ...buildCheckpointTargetPatch(args.writeTarget),
    });
    appendWriteIndexLog(
      args,
      effectiveCheckpointPath,
      {
        docAction: result.docAction,
        bitableAction: result.bitableAction,
        summaryStatus: result.summaryStatus,
        backupPath: result.backupPath || '',
        bitableRecordId: checkpointItem.bitableRecordId || '',
      },
      record,
      buildBitableResultRef(checkpointItem.bitableRecordId),
    );
    noteWriteIndexSuccess(args.writeIndexState, record, {
      docAction: result.docAction,
    });

    result.status = 'success';
    result.totalElapsedMs = Date.now() - taskStartedAt;
    logProgress(videoPrefix, `文档回填完成，总耗时 ${formatElapsedMs(result.totalElapsedMs)}`);
    return result;
  } catch (err) {
    const error = formatError(err);
    if (currentStage.includes('飞书文档')) {
      noteFeishuDocRateLimit(err);
    }
    result.error = error;
    result.failedStage = currentStage;
    result.totalElapsedMs = Date.now() - taskStartedAt;
    if (videoId) {
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'failed',
        failedStage: currentStage,
        error,
      });
    }
    console.error(`[${nowClock()}]${videoPrefix} 失败: ${error}`);
    return result;
  }
}

async function resolveCommentsForEngagementRefresh(
  itemPrefix,
  videoId,
  record,
  videoInfo,
  args,
  summary,
  prefetchedComments,
) {
  if (Number(videoInfo.commentCount || 0) <= 0) {
    return {
      comments: [],
      commentBodyStatus: 'not_needed',
    };
  }
  let fetchedComments = prefetchedComments;
  if (!Array.isArray(fetchedComments)) {
    fetchedComments = await withProgress(itemPrefix, '刷新评论内容', () =>
      retryOperation({
        prefix: itemPrefix,
        label: '刷新评论内容',
        attempts: RETRY_METADATA_ATTEMPTS,
        delayMs: RETRY_METADATA_DELAY_MS,
        fn: () =>
          douyin.getVideoComments(videoId, {
            storageStatePath: args.douyinStorageStatePath,
            limit: 10,
          }),
      }),
    );
  }
  const prior = Array.isArray(record.comments) ? record.comments.slice() : [];
  if (fetchedComments.length) {
    return {
      comments: fetchedComments,
      commentBodyStatus: 'fetched',
    };
  }
  if (!prior.length) {
    summary.commentBodyUnavailable += 1;
    logProgress(itemPrefix, `评论数 ${videoInfo.commentCount}，评论正文当前不可见，保持为空`);
    return {
      comments: [],
      commentBodyStatus: 'unavailable_empty',
    };
  }
  summary.commentBodyUnavailable += 1;
  logProgress(itemPrefix, `评论数 ${videoInfo.commentCount}，评论正文当前不可见，已保留本地旧评论`);
  return {
    comments: prior,
    commentBodyStatus: 'unavailable_reused',
  };
}

async function maybeRefreshDocInfoTableForEngagement({
  client,
  args,
  itemPrefix,
  videoId,
  record,
  sections,
}) {
  const infoTableRows = Array.isArray(sections?.info_table_rows) ? sections.info_table_rows : [];
  if (!infoTableRows.length) {
    return { skipped: true, reason: 'missing_info_table_rows' };
  }

  const headingText = extractSectionHeadingText(sections);
  await waitForFeishuDocWriteWindow(
    itemPrefix,
    '回写飞书文档互动数据',
    args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
  );
  const docResult = await withProgress(itemPrefix, '回写飞书文档互动数据', () =>
    retryOperation({
      prefix: itemPrefix,
      label: '回写飞书文档互动数据',
      attempts: RETRY_FEISHU_DOC_ATTEMPTS,
      delayMs: Math.max(
        RETRY_FEISHU_DOC_DELAY_MS,
        args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
      ),
      fn: () =>
        feishu.withDocumentMutationLock(args.docToken, async () => {
          const currentRange =
            (headingText
              ? await feishu.findSectionRangeByHeading(client, args.docToken, headingText)
              : null) || (await feishu.findSectionRangeByVideoId(client, args.docToken, videoId));
          if (!currentRange) {
            throw new Error(`未找到视频章节: ${headingText || record.title || videoId}`);
          }
          return feishu.updateSectionInfoTable(client, args.docToken, currentRange, infoTableRows);
        }),
    }),
  );
  return {
    ...docResult,
    headingText,
    skipped: false,
  };
}

async function persistCommentsEngagementRefresh({
  client,
  args,
  checkpoint,
  checkpointPath,
  videoId,
  itemPrefix,
  summary,
  bitableByVideoId,
  catalogByVideoId,
  backupDir,
  record,
  videoInfo,
  comments,
  commentBodyStatus,
  checkpointItem,
  catalogItem,
  metadataRefreshMode = 'comments_engagement_v1',
}) {
  const recordPath = path.join(backupDir, 'record.json');
  const previousSnapshot = {
    diggCount: Number(record.diggCount || 0),
    collectCount: Number(record.collectCount || 0),
    commentCount: Number(record.commentCount || 0),
    shareCount: Number(record.shareCount || 0),
    comments: Array.isArray(record.comments) ? record.comments.slice() : [],
  };
  record.title = String(record.title || videoInfo.title || '').trim();
  record.publishTime = String(record.publishTime || videoInfo.publishTime || '').trim();
  record.diggCount = Number(videoInfo.diggCount || 0);
  record.collectCount = Number(videoInfo.collectCount || 0);
  record.commentCount = Number(videoInfo.commentCount || 0);
  record.shareCount = Number(videoInfo.shareCount || 0);
  record.comments = comments;
  applyTextCorrectionsToRecord(record);
  writeJsonFile(recordPath, record);

  const { docContent, fields, sections } = await withProgress(itemPrefix, '刷新本地备份产物', () =>
    buildArtifacts(recordPath),
  );
  const refreshedAt = new Date().toISOString();
  refreshBackupArtifactsInPlace(
    args,
    backupDir,
    record,
    { docContent, fields, sections },
    {
      metadataRefreshedAt: refreshedAt,
      engagementRefreshedAt: refreshedAt,
      commentsRefreshedAt: refreshedAt,
      metadataRefreshMode,
    },
  );

  const existingBitableRecord = bitableByVideoId.get(videoId) || null;
  const bitableResult = await withProgress(itemPrefix, '回填多维表格评论与互动', () =>
    retryOperation({
      prefix: itemPrefix,
      label: '回填多维表格评论与互动',
      attempts: RETRY_FEISHU_BITABLE_ATTEMPTS,
      delayMs: RETRY_FEISHU_BITABLE_DELAY_MS,
      fn: () =>
        upsertBitable(
          client,
          args.bitableAppToken,
          args.bitableTableId,
          fields,
          existingBitableRecord,
        ),
    }),
  );
  bitableByVideoId.set(videoId, bitableResult.record);

  const docAction = String(checkpointItem.docAction || catalogItem.docAction || '').trim();
  const docPresent = isDocActionPresent(docAction);
  if (docPresent) {
    try {
      const docUpdateResult = await maybeRefreshDocInfoTableForEngagement({
        client,
        args,
        itemPrefix,
        videoId,
        record,
        sections,
      });
      if (!docUpdateResult?.skipped) {
        summary.docUpdated += 1;
        logProgress(itemPrefix, '飞书文档互动数据已回写');
      }
    } catch (docErr) {
      noteFeishuDocRateLimit(docErr);
      const error = formatError(docErr);
      summary.docUpdateFailed += 1;
      summary.docUpdateFailedItems.push({
        videoId,
        publishDate: getPublishDate(record.publishTime),
        topic: record.topic || '',
        title: record.title || '',
        headingText: extractSectionHeadingText(sections),
        error,
      });
      console.warn(`[${nowClock()}]${itemPrefix} 飞书文档互动数据回写失败: ${error}`);
    }
  }
  const dedupeEntry = getTargetDedupeEntry(args, videoId);
  const result = {
    summaryStatus:
      checkpointItem.summaryStatus ||
      catalogItem.summaryStatus ||
      ((Array.isArray(record.keyPoints) && record.keyPoints.length) || record.topic ? 'ready' : 'empty'),
    docAction,
    bitableAction: bitableResult.action,
    bitableRecordId: bitableResult?.record?.record_id || '',
    backupPath: backupDir,
    contentFingerprint: dedupeEntry?.contentFingerprint || hashContentFingerprint(record.transcript || ''),
    contentNormalizedLength: Number(
      dedupeEntry?.normalizedTranscriptLength ||
        normalizeTranscriptForDedupe(record.transcript || '').length ||
        0,
    ),
    dedupeStatus: dedupeEntry?.dedupeStatus || '',
    canonicalVideoId: dedupeEntry?.canonicalVideoId || '',
    duplicateOfVideoId: dedupeEntry?.duplicateOfVideoId || '',
    duplicateSimilarity: Number.isFinite(dedupeEntry?.duplicateSimilarity)
      ? dedupeEntry.duplicateSimilarity
      : null,
    dedupeReason: dedupeEntry?.dedupeReason || '',
  };

  updateItemCheckpoint(checkpoint, checkpointPath, videoId, {
    input: checkpointItem.input || videoId,
    title: record.title || checkpointItem.title || catalogItem.title || '',
    publishTime:
      record.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
    publishDate: getPublishDate(
      record.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
    ),
    status: docPresent ? 'written' : 'bitable_written',
    summaryStatus: result.summaryStatus,
    summaryTopic: record.topic || checkpointItem.summaryTopic || null,
    summaryCount: Array.isArray(record.keyPoints) ? record.keyPoints.length : 0,
    docAction,
    docPending: !docPresent,
    bitableAction: bitableResult.action,
    bitableRecordId: bitableResult?.record?.record_id || '',
    backupPath: backupDir,
    backupPathRelative: backupDir ? safeRelativePath(backupDir) : null,
    engagementRefreshedAt: refreshedAt,
    detectedExisting: true,
    ...checkpointClearFailurePatch(),
    ...buildCheckpointTargetPatch(args.writeTarget),
  });
  upsertTargetCatalogEntry(args, result, record, bitableResult);

  if (bitableResult.action === 'create') {
    summary.created += 1;
  } else {
    summary.updated += 1;
  }
  summary.success += 1;
  summary.updatedItems.push(
    buildEngagementUpdatedItem({
      videoId,
      record,
      previousSnapshot,
      comments,
      commentBodyStatus,
      action: bitableResult.action,
    }),
  );
  logProgress(
    itemPrefix,
    `已刷新：点赞 ${record.diggCount} | 收藏 ${record.collectCount} | 评论 ${record.commentCount} | 转发 ${record.shareCount} | 评论正文 ${comments.length} 条`,
  );
}

async function backfillCommentsEngagement(client, args, checkpoint, checkpointPath) {
  const prefix = '[comments-engagement]';
  const catalog = loadTargetCatalog(args);
  const catalogByVideoId = new Map(
    (Array.isArray(catalog.items) ? catalog.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );
  const explicitInputs = Array.isArray(args.inputs) ? args.inputs.slice() : [];
  const targets = [];

  if (explicitInputs.length) {
    for (const rawInput of explicitInputs) {
      const rawText = String(rawInput || '').trim();
      if (!rawText) continue;
      const videoId = /^\d{16,}$/.test(rawText)
        ? rawText
        : await withProgress(prefix, `解析视频ID ${rawText}`, () =>
            retryOperation({
              prefix,
              label: `解析视频ID ${rawText}`,
              attempts: RETRY_METADATA_ATTEMPTS,
              delayMs: RETRY_METADATA_DELAY_MS,
              fn: () => douyin.resolveInputToVideoId(rawText),
            }),
          );
      if (videoId) {
        targets.push(String(videoId).trim());
      }
    }
  } else {
    targets.push(...collectCommentsEngagementRefreshInputs(args, checkpoint));
  }

  const uniqueTargets = [...new Set(targets.filter(Boolean))];
  if (!uniqueTargets.length) {
    logProgress(prefix, '没有可刷新的评论/互动数据目标');
    return;
  }

  const allRecords = await withProgress(prefix, '读取多维表格记录', () =>
    feishu.listAllRecords(client, args.bitableAppToken, args.bitableTableId),
  );
  const bitableByVideoId = new Map();
  for (const record of allRecords) {
    const videoId = getBitableRecordVideoId(record);
    if (!videoId || bitableByVideoId.has(videoId)) continue;
    bitableByVideoId.set(videoId, record);
  }

  logProgress(prefix, `准备刷新 ${uniqueTargets.length} 条视频的评论与互动数据`);

  const summary = {
    success: 0,
    created: 0,
    updated: 0,
    docUpdated: 0,
    docUpdateFailed: 0,
    docUpdateFailedItems: [],
    missingBackup: 0,
    failed: 0,
    commentBodyUnavailable: 0,
    updatedItems: [],
  };

  for (const [index, videoId] of uniqueTargets.entries()) {
    const itemPrefix = buildStepPrefix(`${index + 1}/${uniqueTargets.length}`, videoId);
    try {
      const backupCandidate = findBestBackupCandidate(args, videoId);
      if (!backupCandidate?.recordPath || !fs.existsSync(backupCandidate.recordPath)) {
        summary.missingBackup += 1;
        logProgress(itemPrefix, '跳过：缺少本地备份 record.json');
        continue;
      }

      const targetBackupDir = ensureTargetBackupFromCandidate(args, videoId, backupCandidate);
      const backupDir = targetBackupDir || backupCandidate.dir;
      const recordPath = path.join(backupDir, 'record.json');
      const record = readJsonFileSafe(recordPath);
      if (!record || typeof record !== 'object') {
        throw new Error(`本地备份 record.json 无法读取: ${videoId}`);
      }

      const checkpointItem = checkpoint.items?.[videoId] || {};
      const catalogItem = catalogByVideoId.get(videoId) || {};
      const videoInfo = await withProgress(itemPrefix, '刷新抖音互动数据', () =>
        retryOperation({
          prefix: itemPrefix,
          label: '刷新抖音互动数据',
          attempts: RETRY_METADATA_ATTEMPTS,
          delayMs: RETRY_METADATA_DELAY_MS,
          fn: () =>
            douyin.getVideoInfo(videoId, {
              storageStatePath: args.douyinStorageStatePath,
            }),
        }),
      );

      const commentRefresh = await resolveCommentsForEngagementRefresh(
        itemPrefix,
        videoId,
        record,
        videoInfo,
        args,
        summary,
        undefined,
      );

      await persistCommentsEngagementRefresh({
        client,
        args,
        checkpoint,
        checkpointPath,
        videoId,
        itemPrefix,
        summary,
        bitableByVideoId,
        catalogByVideoId,
        backupDir,
        record,
        videoInfo,
        comments: commentRefresh.comments,
        commentBodyStatus: commentRefresh.commentBodyStatus,
        checkpointItem,
        catalogItem,
        metadataRefreshMode: 'comments_engagement_v1',
      });
    } catch (err) {
      summary.failed += 1;
      console.error(`[${nowClock()}]${itemPrefix} 评论/互动刷新失败: ${formatError(err)}`);
    }
  }

  seedTargetTimelineChecklistFromLocalState(args, checkpoint);
  logProgress(
    prefix,
    `评论/互动刷新完成: 成功 ${summary.success} 条 | 更新 ${summary.updated} 条 | 新建 ${summary.created} 条 | 文档回写 ${summary.docUpdated} 条 | 文档失败 ${summary.docUpdateFailed} 条 | 缺备份 ${summary.missingBackup} 条 | 评论正文不可见 ${summary.commentBodyUnavailable} 条 | 失败 ${summary.failed} 条`,
  );
}

async function refreshEngagementRecentIfDiff(client, args, checkpoint, checkpointPath) {
  const prefix = '[engagement-recent-diff]';
  const recentDays = Math.max(1, Number(args.refreshEngagementRecentDays) || 7);
  const uniqueTargets = collectRecentEngagementRefreshCandidates(args, checkpoint, recentDays);
  if (!uniqueTargets.length) {
    const message = `最近 ${recentDays} 天内没有可核对的视频（需有本地备份）`;
    logProgress(prefix, message);
    return {
      status: 'noop',
      message,
      recentDays,
      summary: {
        success: 0,
        created: 0,
        updated: 0,
        docUpdated: 0,
        docUpdateFailed: 0,
        docUpdateFailedItems: [],
        missingBackup: 0,
        failed: 0,
        commentBodyUnavailable: 0,
        skippedNoDiff: 0,
        updatedItems: [],
      },
    };
  }

  const catalog = loadTargetCatalog(args);
  const catalogByVideoId = new Map(
    (Array.isArray(catalog.items) ? catalog.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );

  const allRecords = await withProgress(prefix, '读取多维表格记录', () =>
    feishu.listAllRecords(client, args.bitableAppToken, args.bitableTableId),
  );
  const bitableByVideoId = new Map();
  for (const record of allRecords) {
    const videoId = getBitableRecordVideoId(record);
    if (!videoId || bitableByVideoId.has(videoId)) continue;
    bitableByVideoId.set(videoId, record);
  }

  logProgress(
    prefix,
    `最近 ${recentDays} 天共 ${uniqueTargets.length} 条待核对（与线上一致则跳过写入）`,
  );

  const summary = {
    success: 0,
    created: 0,
    updated: 0,
    docUpdated: 0,
    docUpdateFailed: 0,
    docUpdateFailedItems: [],
    missingBackup: 0,
    failed: 0,
    commentBodyUnavailable: 0,
    skippedNoDiff: 0,
    updatedItems: [],
  };

  for (const [index, videoId] of uniqueTargets.entries()) {
    const itemPrefix = buildStepPrefix(`${index + 1}/${uniqueTargets.length}`, videoId);
    try {
      const backupCandidate = findBestBackupCandidate(args, videoId);
      if (!backupCandidate?.recordPath || !fs.existsSync(backupCandidate.recordPath)) {
        summary.missingBackup += 1;
        logProgress(itemPrefix, '跳过：缺少本地备份 record.json');
        continue;
      }

      const targetBackupDir = ensureTargetBackupFromCandidate(args, videoId, backupCandidate);
      const backupDir = targetBackupDir || backupCandidate.dir;
      const recordPath = path.join(backupDir, 'record.json');
      const record = readJsonFileSafe(recordPath);
      if (!record || typeof record !== 'object') {
        throw new Error(`本地备份 record.json 无法读取: ${videoId}`);
      }

      const checkpointItem = checkpoint.items?.[videoId] || {};
      const catalogItem = catalogByVideoId.get(videoId) || {};
      const videoInfo = await withProgress(itemPrefix, '拉取抖音互动数据（核对）', () =>
        retryOperation({
          prefix: itemPrefix,
          label: '拉取抖音互动数据（核对）',
          attempts: RETRY_METADATA_ATTEMPTS,
          delayMs: RETRY_METADATA_DELAY_MS,
          fn: () =>
            douyin.getVideoInfo(videoId, {
              storageStatePath: args.douyinStorageStatePath,
            }),
        }),
      );

      let prefetchedComments = null;
      const rc = Number(videoInfo.commentCount || 0);
      if (engagementCountsLine(record) === engagementCountsLine(videoInfo)) {
        if (rc === 0) {
          if (normalizedCommentTextsForEngagementCompare(record.comments).length === 0) {
            summary.skippedNoDiff += 1;
            logProgress(itemPrefix, '互动与评论与线上一致，跳过');
            continue;
          }
        } else {
          prefetchedComments = await withProgress(itemPrefix, '拉取评论正文（核对）', () =>
            retryOperation({
              prefix: itemPrefix,
              label: '拉取评论正文（核对）',
              attempts: RETRY_METADATA_ATTEMPTS,
              delayMs: RETRY_METADATA_DELAY_MS,
              fn: () =>
                douyin.getVideoComments(videoId, {
                  storageStatePath: args.douyinStorageStatePath,
                  limit: 10,
                }),
            }),
          );
          if (shouldSkipEngagementRefreshAfterFetch(record, videoInfo, prefetchedComments)) {
            summary.skippedNoDiff += 1;
            logProgress(itemPrefix, '互动与评论与线上一致，跳过');
            continue;
          }
        }
      }

      const commentRefresh = await resolveCommentsForEngagementRefresh(
        itemPrefix,
        videoId,
        record,
        videoInfo,
        args,
        summary,
        prefetchedComments,
      );

      await persistCommentsEngagementRefresh({
        client,
        args,
        checkpoint,
        checkpointPath,
        videoId,
        itemPrefix,
        summary,
        bitableByVideoId,
        catalogByVideoId,
        backupDir,
        record,
        videoInfo,
        comments: commentRefresh.comments,
        commentBodyStatus: commentRefresh.commentBodyStatus,
        checkpointItem,
        catalogItem,
        metadataRefreshMode: 'comments_engagement_recent_diff_v1',
      });
    } catch (err) {
      summary.failed += 1;
      console.error(`[${nowClock()}]${itemPrefix} 近窗互动核对失败: ${formatError(err)}`);
    }
  }

  seedTargetTimelineChecklistFromLocalState(args, checkpoint);
  logProgress(
    prefix,
    `近窗互动核对完成: 已刷新 ${summary.success} 条 | 无差异跳过 ${summary.skippedNoDiff} 条 | 更新 ${summary.updated} 条 | 新建 ${summary.created} 条 | 文档回写 ${summary.docUpdated} 条 | 文档失败 ${summary.docUpdateFailed} 条 | 缺备份 ${summary.missingBackup} 条 | 评论正文不可见 ${summary.commentBodyUnavailable} 条 | 失败 ${summary.failed} 条`,
  );
  return {
    status:
      summary.failed > 0
        ? summary.success > 0 || summary.skippedNoDiff > 0
          ? 'partial_failure'
          : 'failed'
        : summary.docUpdateFailed > 0
          ? 'success_with_warnings'
          : 'success',
    message: '',
    recentDays,
    summary,
  };
}

async function backfillBitableFieldsFromBackups(client, args, checkpoint, checkpointPath) {
  const prefix = '[bitable-backfill]';
  const catalog = loadTargetCatalog(args);
  const catalogByVideoId = new Map(
    (Array.isArray(catalog.items) ? catalog.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );
  const allRecords = await withProgress(prefix, '读取多维表格记录', () =>
    feishu.listAllRecords(client, args.bitableAppToken, args.bitableTableId),
  );
  const uniqueRecords = new Map();
  let duplicateTableRows = 0;
  let missingVideoIdRows = 0;
  for (const record of allRecords) {
    const videoId = getBitableRecordVideoId(record);
    if (!videoId) {
      missingVideoIdRows += 1;
      continue;
    }
    if (uniqueRecords.has(videoId)) {
      duplicateTableRows += 1;
      continue;
    }
    uniqueRecords.set(videoId, record);
  }

  const orderedRecords = [...uniqueRecords.values()].sort((left, right) => {
    const leftTs = parsePublishTimestamp(getBitableRecordPublishTime(left)) ?? 0;
    const rightTs = parsePublishTimestamp(getBitableRecordPublishTime(right)) ?? 0;
    if (leftTs !== rightTs) {
      return rightTs - leftTs;
    }
    return String(getBitableRecordVideoId(right) || '').localeCompare(
      String(getBitableRecordVideoId(left) || ''),
    );
  });
  const explicitVideoIds = collectExplicitVideoIds(args);
  const explicitVideoIdSet = explicitVideoIds.length ? new Set(explicitVideoIds) : null;
  const candidateRecords = explicitVideoIdSet
    ? orderedRecords.filter((record) => explicitVideoIdSet.has(getBitableRecordVideoId(record)))
    : orderedRecords;
  const targets = args.limitProvided
    ? candidateRecords.slice(0, Math.max(1, Number(args.limit) || candidateRecords.length))
    : candidateRecords;
  const matchedExplicitIds = explicitVideoIdSet
    ? new Set(targets.map((record) => getBitableRecordVideoId(record)).filter(Boolean))
    : null;
  const missingExplicitIds = explicitVideoIdSet
    ? explicitVideoIds.filter((videoId) => !matchedExplicitIds.has(videoId))
    : [];

  logProgress(
    prefix,
    `${explicitVideoIdSet ? '按显式清单' : '准备'}回填多维表格字段: 目标 ${targets.length} 条 | 表内去重后 ${orderedRecords.length} 条 | 原始记录 ${allRecords.length} 条 | 缺视频ID ${missingVideoIdRows} 条 | 重复视频ID ${duplicateTableRows} 条${explicitVideoIdSet ? ` | 清单 ${explicitVideoIds.length} 条 | 未命中 ${missingExplicitIds.length} 条` : ''}`,
  );

  const summary = {
    success: 0,
    missingBackup: 0,
    failed: 0,
  };

  for (const [index, bitableRecord] of targets.entries()) {
    const videoId = getBitableRecordVideoId(bitableRecord);
    const itemPrefix = buildStepPrefix(`${index + 1}/${targets.length}`, videoId);
    try {
      const backupCandidate = findBestBackupCandidate(args, videoId);
      if (!backupCandidate?.recordPath || !fs.existsSync(backupCandidate.recordPath)) {
        summary.missingBackup += 1;
        logProgress(itemPrefix, '跳过：缺少本地备份 record.json');
        continue;
      }

      const targetBackupDir = ensureTargetBackupFromCandidate(args, videoId, backupCandidate);
      const backupDir = targetBackupDir || backupCandidate.dir;
      const recordPath = path.join(backupDir, 'record.json');
      const record = readJsonFileSafe(recordPath);
      if (!record || typeof record !== 'object') {
        throw new Error(`本地备份 record.json 无法读取: ${videoId}`);
      }

      record.videoId = String(record.videoId || videoId).trim();
      applyTextCorrectionsToRecord(record);
      let summaryStatus =
        (Array.isArray(record.keyPoints) && record.keyPoints.length) || record.topic ? 'ready' : 'empty';
      if (SUMMARY_ENABLED && !record.topic && !(Array.isArray(record.keyPoints) && record.keyPoints.length)) {
        try {
          const summary = await withProgress(itemPrefix, '补做摘要', () =>
            retryOperation({
              prefix: itemPrefix,
              label: '补做摘要',
              attempts: RETRY_SUMMARY_ATTEMPTS,
              delayMs: RETRY_SUMMARY_DELAY_MS,
              fn: () => summarizeRecord(record, { prefix: itemPrefix }),
            }),
          );
          record.topic = normalizeTopic(summary?.topic);
          record.keyPoints = normalizeKeyPoints(summary?.keyPoints);
          applyTextCorrectionsToRecord(record);
          summaryStatus = record.topic || record.keyPoints.length ? 'ready' : 'empty';
        } catch (summaryErr) {
          summaryStatus = 'failed';
          console.warn(
            `[${nowClock()}]${itemPrefix} 补做摘要失败，继续回填其余字段: ${formatError(summaryErr)}`,
          );
        }
      }
      writeJsonFile(recordPath, record);

      const { docContent, fields, sections } = await withProgress(itemPrefix, '刷新本地格式化产物', () =>
        buildArtifacts(recordPath),
      );
      refreshBackupArtifactsInPlace(args, backupDir, record, { docContent, fields, sections }, { summaryStatus });

      await withProgress(itemPrefix, '回填多维表格字段', () =>
        retryOperation({
          prefix: itemPrefix,
          label: '回填多维表格字段',
          attempts: RETRY_FEISHU_BITABLE_ATTEMPTS,
          delayMs: RETRY_FEISHU_BITABLE_DELAY_MS,
          fn: () =>
            feishu.updateRecord(
              client,
              args.bitableAppToken,
              args.bitableTableId,
              bitableRecord.record_id,
              fields,
            ),
        }),
      );

      const checkpointItem = checkpoint.items?.[videoId] || {};
      const catalogItem = catalogByVideoId.get(videoId) || {};
      const docAction = String(checkpointItem.docAction || catalogItem.docAction || '').trim();
      const docPresent = isDocActionPresent(docAction);
      const dedupeEntry = getTargetDedupeEntry(args, videoId);
      const result = {
        summaryStatus,
        docAction,
        bitableAction: 'update',
        bitableRecordId: bitableRecord.record_id,
        backupPath: backupDir,
        contentFingerprint: dedupeEntry?.contentFingerprint || hashContentFingerprint(record.transcript || ''),
        contentNormalizedLength: Number(
          dedupeEntry?.normalizedTranscriptLength ||
            normalizeTranscriptForDedupe(record.transcript || '').length ||
            0,
        ),
        dedupeStatus: dedupeEntry?.dedupeStatus || '',
        canonicalVideoId: dedupeEntry?.canonicalVideoId || '',
        duplicateOfVideoId: dedupeEntry?.duplicateOfVideoId || '',
        duplicateSimilarity: Number.isFinite(dedupeEntry?.duplicateSimilarity)
          ? dedupeEntry.duplicateSimilarity
          : null,
        dedupeReason: dedupeEntry?.dedupeReason || '',
      };

      updateItemCheckpoint(checkpoint, checkpointPath, videoId, {
        input: checkpointItem.input || videoId,
        title: record.title || checkpointItem.title || catalogItem.title || '',
        publishTime:
          record.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
        publishDate: getPublishDate(
          record.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
        ),
        status: docPresent ? 'written' : 'bitable_written',
        summaryStatus,
        summaryTopic: record.topic || null,
        summaryCount: Array.isArray(record.keyPoints) ? record.keyPoints.length : 0,
        docAction,
        docPending: !docPresent,
        bitableAction: 'update',
        bitableRecordId: bitableRecord.record_id,
        backupPath: backupDir,
        backupPathRelative: backupDir ? safeRelativePath(backupDir) : null,
        detectedExisting: true,
        ...checkpointClearFailurePatch(),
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      upsertTargetCatalogEntry(
        args,
        result,
        record,
        { record: { record_id: bitableRecord.record_id } },
      );
      summary.success += 1;
      logProgress(itemPrefix, `已刷新多维表格字段: ${record.title || record.topic || videoId}`);
    } catch (err) {
      summary.failed += 1;
      console.error(`[${nowClock()}]${itemPrefix} 历史字段回填失败: ${formatError(err)}`);
    }
  }

  args.dedupeState = refreshTargetDedupeState(args, checkpoint, checkpointPath);
  seedTargetTimelineChecklistFromLocalState(args, checkpoint);
  logProgress(
    prefix,
    `多维表格字段回填完成: 成功 ${summary.success} 条 | 缺备份 ${summary.missingBackup} 条 | 失败 ${summary.failed} 条`,
  );
}

async function processOne(client, args, checkpoint, checkpointPath, input, index, total) {
  if (args.backfillDocPending || args.backfillDocAll) {
    return processPendingDocOne(client, args, checkpoint, checkpointPath, input, index, total);
  }
  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'douyin-transcribe-'));
  const effectiveCheckpointPath = args.dryRun ? null : checkpointPath;
  const positionLabel = `${index}/${total}`;
  const taskStartedAt = Date.now();
  const result = createProcessResult(positionLabel, input);
  result.taskStartedAtMs = taskStartedAt;
  let currentStage = '初始化';

  let videoInfo;
  let videoId = '';
  try {
    logProgress(buildStepPrefix(positionLabel), `开始处理: ${input}`);
    currentStage = '解析抖音视频信息';
    videoInfo = await withProgress(buildStepPrefix(positionLabel), '解析抖音视频信息', () =>
      retryOperation({
        prefix: buildStepPrefix(positionLabel),
        label: '解析抖音视频信息',
        attempts: RETRY_METADATA_ATTEMPTS,
        delayMs: RETRY_METADATA_DELAY_MS,
        fn: () =>
          douyin.getVideoInfo(input, {
            storageStatePath: args.douyinStorageStatePath,
          }),
      }),
    );
    videoId = videoInfo.videoId;
    if (!videoId) {
      throw new Error('无法解析视频 ID');
    }
    result.videoId = videoId;
    result.title = videoInfo.title || '';
    result.publishTime = videoInfo.publishTime || '';
    const videoPrefix = buildStepPrefix(positionLabel, videoId);
    logProgress(videoPrefix, `标题: ${videoInfo.title || '缺失'}`);
    logProgress(videoPrefix, `发布时间: ${videoInfo.publishTime || '缺失'}`);

    const existing = checkpoint.items[videoId];
    if (
      args.resume &&
      ['written', 'duplicate_skipped', 'silence_skipped', ...(args.skipDocWrite ? ['bitable_written'] : [])].includes(existing?.status) &&
      matchesCheckpointTarget(existing, buildWriteTargetSignature(args.writeTarget)) &&
      !args.dryRun &&
      !args.forceRewrite
    ) {
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status:
          isTerminalSkipStatus(existing?.status)
            ? existing?.status
            : args.skipDocWrite && existing?.status === 'bitable_written'
              ? 'bitable_written'
              : 'written',
        publishDate: getPublishDate(videoInfo.publishTime),
        ...checkpointClearFailurePatch(),
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      logProgress(
        videoPrefix,
        existing?.status === 'duplicate_skipped'
          ? `已跳过，命中内容级去重，归并到 ${existing?.duplicateOfVideoId || existing?.canonicalVideoId || '未知视频'}`
          : existing?.status === 'silence_skipped'
          ? '已跳过，ASR 判定为静音/无有效语音'
          : args.skipDocWrite && existing?.status === 'bitable_written'
          ? '已跳过，checkpoint 显示当前目标已完成表格录入，文档待后补'
          : '已跳过，checkpoint 显示当前目标已写入',
      );
      result.status = 'skipped';
      result.skipReason =
        existing?.status === 'duplicate_skipped'
          ? 'checkpoint_duplicate_skipped'
          : existing?.status === 'silence_skipped'
          ? 'checkpoint_silence_skipped'
          : args.skipDocWrite && existing?.status === 'bitable_written'
          ? 'checkpoint_bitable_written'
          : 'checkpoint_written';
      result.docAction =
        isTerminalSkipStatus(existing?.status)
          ? 'skip'
          : args.skipDocWrite && existing?.status === 'bitable_written'
          ? existing?.docAction || 'queued'
          : 'keep';
      result.bitableAction =
        isTerminalSkipStatus(existing?.status)
          ? existing?.bitableAction || 'skip'
          : args.skipDocWrite && existing?.status === 'bitable_written'
          ? existing?.bitableAction || 'keep'
          : 'keep';
      result.dedupeStatus = existing?.dedupeStatus || 'duplicate';
      result.canonicalVideoId = existing?.canonicalVideoId || '';
      result.duplicateOfVideoId = existing?.duplicateOfVideoId || '';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      return result;
    }

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      input,
      title: videoInfo.title,
      publishTime: videoInfo.publishTime,
      publishDate: getPublishDate(videoInfo.publishTime),
      status: 'resolved',
      ...checkpointClearFailurePatch(),
      ...buildCheckpointTargetPatch(args.writeTarget),
    });

    let preflightDocRange = null;
    let preflightBitableRecord = null;
    let docIndexedAsWritten = false;
    if (!args.dryRun && !args.forceRewrite) {
      currentStage = '检查目标是否已存在';
      docIndexedAsWritten = Boolean(args.writeIndexState?.docVideoIds?.has(videoId));
      const checkpointDocPresent =
        existing?.status === 'written' ||
        existing?.status === 'doc_written' ||
        isDocActionPresent(existing?.docAction || '');
      if (args.skipDocWrite) {
        logProgress(videoPrefix, '已启用 skip-doc-write，跳过飞书文档存在性探测');
      } else if (docIndexedAsWritten) {
        logProgress(videoPrefix, '本地索引显示当前目标文档已写入该视频，跳过飞书文档存在性探测');
      } else {
        preflightDocRange = await withProgress(videoPrefix, '检查飞书文档是否已存在该视频', () =>
          feishu.findSectionRangeByVideoId(client, args.docToken, videoId),
        );
      }
      preflightBitableRecord = await withProgress(videoPrefix, '检查多维表格是否已存在该视频', () =>
        feishu.findRecordByField(
          client,
          args.bitableAppToken,
          args.bitableTableId,
          '视频ID:',
          videoId,
        ),
      );

      if (args.skipDocWrite && preflightBitableRecord) {
        const docPresent = Boolean(preflightDocRange || docIndexedAsWritten || checkpointDocPresent);
        updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
          status: docPresent ? 'written' : 'bitable_written',
          publishDate: getPublishDate(videoInfo.publishTime),
          docAction: docPresent ? existing?.docAction || 'keep' : 'queued',
          docPending: !docPresent,
          bitableAction: 'keep',
          existingHeading: preflightDocRange?.headingText || '',
          bitableRecordId: preflightBitableRecord.record_id || '',
          detectedExisting: true,
          ...checkpointClearFailurePatch(),
          ...buildCheckpointTargetPatch(args.writeTarget),
        });
        logProgress(
          videoPrefix,
          docPresent
            ? '检测到当前目标中已存在文档和表格，保持原样未重写'
            : '检测到当前目标中已存在表格记录，保持原样，文档继续待后补',
        );
        result.status = 'skipped';
        result.skipReason = docPresent ? 'already_exists_in_targets' : 'bitable_already_written_doc_deferred';
        result.docAction = docPresent ? 'keep' : 'queued';
        result.bitableAction = 'keep';
        result.summaryStatus = 'skipped';
        result.totalElapsedMs = Date.now() - taskStartedAt;
        return result;
      }

      if ((preflightDocRange || docIndexedAsWritten) && preflightBitableRecord) {
        logProgress(
          videoPrefix,
          '检测到当前目标中已存在该视频，保持原样未重写；如需替换请显式传入 --force-rewrite 或 --rewrite',
        );
        updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
          status: 'written',
          publishDate: getPublishDate(videoInfo.publishTime),
          docAction: 'keep',
          bitableAction: 'keep',
          existingHeading: preflightDocRange?.headingText || '',
          bitableRecordId: preflightBitableRecord.record_id || '',
          detectedExisting: true,
          ...checkpointClearFailurePatch(),
          ...buildCheckpointTargetPatch(args.writeTarget),
        });
        result.status = 'skipped';
        result.skipReason = 'already_exists_in_targets';
        result.docAction = 'keep';
        result.bitableAction = 'keep';
        result.summaryStatus = 'skipped';
        result.totalElapsedMs = Date.now() - taskStartedAt;
        return result;
      }
    }

    const videoPath = path.join(workDir, `${videoId}.mp4`);
    currentStage = '下载视频文件';
    await withProgress(videoPrefix, '下载视频文件', () =>
      douyin.downloadVideo(videoInfo.videoUrl, videoPath, null, {
        referer: videoInfo.downloadReferer,
        storageStatePath: args.douyinStorageStatePath,
      }),
    );
    videoInfo.outputPath = videoPath;
    videoInfo.duration = getVideoDuration(videoPath);
    logProgress(videoPrefix, `视频时长: ${videoInfo.duration}`);

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, { status: 'downloaded' });

    const audioPath = path.join(workDir, `${videoId}.wav`);
    currentStage = '提取音频';
    await withProgress(videoPrefix, '提取音频', () => extractAudio(videoPath, audioPath));
    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, { status: 'audio_extracted' });

    currentStage = '执行语音转文字';
    const asr = await withProgress(videoPrefix, '执行语音转文字', () => transcribeAudio(audioPath));
    const asrAttempts = summarizeAsrAttempts(asr.attempts);
    const asrPrimaryError = getPrimaryAsrFailure(asrAttempts);
    const asrFallbackUsed = didAsrFallbackSucceed(asrAttempts);
    const failedAsrModel = asrAttempts[asrAttempts.length - 1]?.model || asr.model || '';
    if (!asr.success) {
      const asrErrorText = String(asr.error || asrPrimaryError || 'ASR 未返回可用文本').trim();
      if (isSilenceAsrFailure(asr)) {
        result.asrModel = failedAsrModel;
        result.asrAttempts = asrAttempts;
        result.asrFallbackUsed = asrFallbackUsed;
        result.asrPrimaryError = asrPrimaryError || asrErrorText;
        result.status = 'skipped';
        result.skipReason = 'silence_audio';
        result.docAction = 'skip';
        result.bitableAction = 'skip';
        result.summaryStatus = 'skipped';
        result.totalElapsedMs = Date.now() - taskStartedAt;
        updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
          status: 'silence_skipped',
          publishDate: getPublishDate(videoInfo.publishTime),
          asrModel: failedAsrModel,
          asrAttempts,
          asrFallbackUsed,
          asrPrimaryError: asrPrimaryError || asrErrorText,
          failedStage: currentStage,
          error: asrErrorText,
          ...buildCheckpointTargetPatch(args.writeTarget),
        });
        logProgress(videoPrefix, 'ASR 判定为静音/无有效语音，已标记为跳过，不写入飞书');
        return result;
      }
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'asr_failed',
        asrModel: failedAsrModel,
        asrAttempts,
        asrFallbackUsed,
        asrPrimaryError,
        failedStage: currentStage,
        error: asrErrorText,
      });
      throw new Error(`ASR失败: ${asrErrorText}`);
    }
    logProgress(videoPrefix, `语音转文字完成: ${asr.asr_duration || '未知耗时'}，模型 ${asr.model}`);
    result.asrModel = asr.model || '';
    result.asrAttempts = asrAttempts;
    result.asrFallbackUsed = asrFallbackUsed;
    result.asrPrimaryError = asrPrimaryError;
    if (asrFallbackUsed) {
      const fallbackMessage = `云端 ASR 主模型失败后已切换备用模型 ${result.asrModel}: ${asrPrimaryError || '未返回明确原因'}`;
      result.warnings.push(fallbackMessage);
      logProgress(videoPrefix, fallbackMessage);
    }

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      status: 'transcribed',
      asrModel: asr.model,
      asrAttempts,
      asrFallbackUsed,
      asrPrimaryError,
    });

    if (Number(videoInfo.commentCount || 0) > 0) {
      currentStage = '抓取评论';
      videoInfo.comments = await withProgress(videoPrefix, '抓取评论', () =>
        douyin.getVideoComments(videoId, {
          storageStatePath: args.douyinStorageStatePath,
          limit: 10,
        }),
      );
    } else {
      videoInfo.comments = [];
    }
    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      status: 'comments_loaded',
    });

    const record = buildRecord(videoInfo, asr.text || '', asr.asr_duration || '约 5 秒');
    const recordPath = path.join(workDir, `${videoId}.json`);
    fs.writeFileSync(recordPath, JSON.stringify(record, null, 2), 'utf-8');

    currentStage = '格式化文档内容';
    let { docContent, fields, sections } = await withProgress(videoPrefix, '格式化文档内容', () =>
      buildArtifacts(recordPath),
    );
    result.backupPath = persistLocalBackup(
      args,
      record,
      { docContent, fields, sections },
      {
        input,
        asrModel: result.asrModel,
        asrAttempts: result.asrAttempts,
        asrFallbackUsed: result.asrFallbackUsed,
        asrPrimaryError: result.asrPrimaryError,
        summaryStatus: result.summaryStatus,
      },
    );
    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      backupPath: result.backupPath || null,
      backupPathRelative: result.backupPath ? safeRelativePath(result.backupPath) : null,
    });
    const dedupeState = refreshTargetDedupeState(args, checkpoint, effectiveCheckpointPath);
    const dedupeEntry = dedupeState?.itemsByVideoId?.get(videoId) || null;
    if (dedupeEntry) {
      result.contentFingerprint = dedupeEntry.contentFingerprint || '';
      result.contentNormalizedLength = Number(dedupeEntry.normalizedTranscriptLength || 0);
      result.dedupeStatus = dedupeEntry.dedupeStatus || '';
      result.canonicalVideoId = dedupeEntry.canonicalVideoId || '';
      result.duplicateOfVideoId = dedupeEntry.duplicateOfVideoId || '';
      result.duplicateSimilarity = Number.isFinite(dedupeEntry.duplicateSimilarity)
        ? dedupeEntry.duplicateSimilarity
        : null;
      result.dedupeReason = dedupeEntry.dedupeReason || '';
    }
    if (dedupeEntry?.dedupeStatus === 'duplicate') {
      result.status = 'skipped';
      result.skipReason = 'duplicate_content';
      result.docAction = 'skip';
      result.bitableAction = 'skip';
      result.summaryStatus = 'skipped';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      logProgress(
        videoPrefix,
        `命中内容级去重，已跳过飞书写入，归并到 ${dedupeEntry.duplicateOfVideoId || dedupeEntry.canonicalVideoId || '未知视频'}`,
      );
      return result;
    }
    let headingText = extractSectionHeadingText(sections);
    const shouldSkipSummary = args.skipSummary || !SUMMARY_ENABLED;
    if (shouldSkipSummary) {
      result.summaryStatus = 'skipped';
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        summaryStatus: 'skipped',
        summaryTopic: null,
        summaryError: null,
        summaryDocError: null,
        summaryBitableError: null,
      });
    }

    let existingDocRange = null;
    let existingBitableRecord = null;
    if (!args.dryRun) {
      const shouldScanExistingDocRange =
        !args.skipDocWrite &&
        !docIndexedAsWritten && (!args.docWritePolicy?.enabled || Boolean(preflightDocRange));
      if (shouldScanExistingDocRange) {
        currentStage = '检查飞书文档现有区块';
        existingDocRange = await withProgress(videoPrefix, '检查飞书文档现有区块', () =>
          Promise.resolve(preflightDocRange).then(
            (range) =>
              range ||
              feishu.findSectionRangeByHeading(client, args.docToken, headingText).then(
                (match) => match || feishu.findSectionRangeByVideoId(client, args.docToken, record.videoId),
              ),
          ),
        );
      } else if (args.skipDocWrite) {
        logProgress(videoPrefix, '已启用 skip-doc-write，跳过现有文档区块扫描');
      } else if (!docIndexedAsWritten) {
        logProgress(videoPrefix, '历史批量模式下已跳过二次文档区块扫描');
      } else {
        logProgress(videoPrefix, '已根据本地索引确认文档存在，跳过现有区块扫描');
      }

      currentStage = '检查多维表格现有记录';
      existingBitableRecord = await withProgress(videoPrefix, '检查多维表格现有记录', () =>
        Promise.resolve(preflightBitableRecord).then(
          (recordMatch) =>
            recordMatch ||
            feishu.findRecordByField(
              client,
              args.bitableAppToken,
              args.bitableTableId,
              '视频ID:',
              fields['视频ID:'],
            ),
        ),
      );
    }

    const deferSummary =
      !shouldSkipSummary &&
      SUMMARY_MODE === 'post_write' &&
      !args.dryRun &&
      !existingDocRange;

    if (!shouldSkipSummary && !deferSummary) {
      currentStage = '生成核心要点摘要';
      const summaryReady = await tryGenerateSummary(
        videoPrefix,
        record,
        checkpoint,
        effectiveCheckpointPath,
        result.warnings,
      );
      result.summaryStatus = summaryReady
        ? record.keyPoints.length || record.topic
          ? 'ready'
          : 'empty'
        : 'failed';
      if (summaryReady) {
        fs.writeFileSync(recordPath, JSON.stringify(record, null, 2), 'utf-8');
        currentStage = '刷新摘要后的文档内容';
        ({ docContent, fields, sections } = await withProgress(
          videoPrefix,
          '刷新摘要后的文档内容',
          () => buildArtifacts(recordPath),
        ));
        result.backupPath = persistLocalBackup(
          args,
          record,
          { docContent, fields, sections },
          {
            input,
            asrModel: result.asrModel,
            asrAttempts: result.asrAttempts,
            asrFallbackUsed: result.asrFallbackUsed,
            asrPrimaryError: result.asrPrimaryError,
            summaryStatus: result.summaryStatus,
          },
        );
      }
    } else if (deferSummary) {
      result.summaryStatus = 'deferred';
      logProgress(videoPrefix, '已启用“正文先写、摘要后补”模式');
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        summaryStatus: 'deferred',
        summaryTopic: null,
        summaryError: null,
        summaryDocError: null,
        summaryBitableError: null,
      });
    }

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      status: args.dryRun ? 'dry_run_ready' : 'formatted',
    });

    logProgress(videoPrefix, `字数: ${fields['字数']}`);

    if (args.dryRun) {
      const previewPath = path.join(workDir, `${videoId}.md`);
      fs.writeFileSync(previewPath, docContent, 'utf-8');
      logProgress(videoPrefix, `dry-run 预览: ${previewPath}`);
      result.status = result.warnings.length ? 'success_with_warnings' : 'success';
      result.docAction = 'dry_run';
      result.bitableAction = 'dry_run';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      return result;
    }

    let bitableResult = null;
    const canQueueDocCreate =
      !args.skipDocWrite &&
      args.docWritePolicy?.enabled &&
      !docIndexedAsWritten &&
      !existingDocRange &&
      !args.forceRewrite;

    if (args.skipDocWrite) {
      result.docAction = 'queued';
      logProgress(videoPrefix, '已启用 skip-doc-write，本条文档暂不写入');
    } else if (docIndexedAsWritten) {
      result.docAction = 'keep';
      logProgress(videoPrefix, '文档已根据本地索引保持原样');
    } else if (canQueueDocCreate) {
      result.docAction = 'queued';
      logProgress(videoPrefix, '当前视频将进入文档批量写入队列');
    } else {
      currentStage = '写入飞书文档';
      const insertIndexHint =
        !existingDocRange && !args.forceRewrite ? getLocalBatchInsertIndex(args, [{ record }]) : undefined;
      await waitForFeishuDocWriteWindow(
        videoPrefix,
        '写入飞书文档',
        args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
      );
      const docResult = await withProgress(videoPrefix, '写入飞书文档', () =>
        retryOperation({
          prefix: videoPrefix,
          label: '写入飞书文档',
          attempts: RETRY_FEISHU_DOC_ATTEMPTS,
          delayMs: Math.max(
            RETRY_FEISHU_DOC_DELAY_MS,
            args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
          ),
          fn: () =>
            maybeAppendDoc(client, args.docToken, record, sections, {
              existingRange: existingDocRange,
              skipDocContainsCheck: !existingBitableRecord,
              ...(insertIndexHint !== undefined ? { insertIndex: insertIndexHint } : {}),
            }),
        }),
      );
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'doc_written',
        docSkipped: docResult.skipped || false,
        failedStage: null,
        error: null,
      });
      result.docAction = docResult.skipped ? 'keep' : docResult.replaced ? 'replace' : 'create';
      logProgress(
        videoPrefix,
        `飞书文档已${docResult.skipped ? '保持原样' : docResult.replaced ? '替换旧区块' : '新增写入'}`,
      );
    }

    currentStage = '写入多维表格';
    bitableResult = await withProgress(videoPrefix, '写入多维表格', () =>
      retryOperation({
        prefix: videoPrefix,
        label: '写入多维表格',
        attempts: RETRY_FEISHU_BITABLE_ATTEMPTS,
        delayMs: RETRY_FEISHU_BITABLE_DELAY_MS,
        fn: () =>
          upsertBitable(
            client,
            args.bitableAppToken,
            args.bitableTableId,
            fields,
            existingBitableRecord,
          ),
      }),
    );
    result.bitableAction = bitableResult.action;

    logProgress(videoPrefix, `多维表格: ${bitableResult.action}`);
    if (args.skipDocWrite) {
      const checkpointDocPresent =
        existing?.status === 'written' ||
        existing?.status === 'doc_written' ||
        isDocActionPresent(existing?.docAction || '');
      const knownDocPresent = docIndexedAsWritten || checkpointDocPresent;
      result.docAction = knownDocPresent ? existing?.docAction || 'keep' : 'queued';
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: knownDocPresent ? 'written' : 'bitable_written',
        bitableAction: bitableResult.action,
        publishDate: getPublishDate(record.publishTime),
        docAction: result.docAction,
        docPending: !knownDocPresent,
        bitableRecordId: bitableResult?.record?.record_id || '',
        failedStage: null,
        error: null,
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      upsertTargetCatalogEntry(
        args,
        {
          docAction: result.docAction,
          bitableAction: bitableResult.action,
          summaryStatus: result.summaryStatus,
          backupPath: result.backupPath || '',
          bitableRecordId: bitableResult?.record?.record_id || '',
        },
        record,
        bitableResult,
      );
      result.status = result.warnings.length ? 'success_with_warnings' : 'success';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      logProgress(
        videoPrefix,
        knownDocPresent ? '本条已完成表格录入，文档保持原样' : '本条已完成表格录入，文档待后补',
      );
      return result;
    }

    if (canQueueDocCreate) {
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'bitable_written',
        bitableAction: bitableResult.action,
        publishDate: getPublishDate(record.publishTime),
        docAction: 'queued',
        docPending: true,
        bitableRecordId: bitableResult?.record?.record_id || '',
        failedStage: null,
        error: null,
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      result.status = 'pending_doc';
      result.pendingDoc = {
        record,
        sections,
        bitableResult,
      };
      result.totalElapsedMs = Date.now() - taskStartedAt;
      logProgress(videoPrefix, '文档待批量写入，本条先完成转写与表格录入');
      return result;
    }

    updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
      status: 'written',
      bitableAction: bitableResult.action,
      publishDate: getPublishDate(record.publishTime),
      docAction: result.docAction,
      docPending: false,
      bitableRecordId: bitableResult?.record?.record_id || '',
      ...checkpointClearFailurePatch(),
      ...buildCheckpointTargetPatch(args.writeTarget),
    });
    appendWriteIndexLog(args, effectiveCheckpointPath, result, record, bitableResult);
    noteWriteIndexSuccess(args.writeIndexState, record, result);

    if (deferSummary) {
      currentStage = '生成核心要点摘要';
      const summaryReady = await tryGenerateSummary(
        videoPrefix,
        record,
        checkpoint,
        effectiveCheckpointPath,
        result.warnings,
      );
      result.summaryStatus = summaryReady
        ? record.keyPoints.length || record.topic
          ? 'ready'
          : 'empty'
        : 'failed';

      if (summaryReady && (record.keyPoints.length || record.topic)) {
        fs.writeFileSync(recordPath, JSON.stringify(record, null, 2), 'utf-8');
        currentStage = '刷新摘要后的回填内容';
        const enriched = await withProgress(videoPrefix, '刷新摘要后的回填内容', async () => ({
          fields: await bitableFields(recordPath),
          sections: await docSections(recordPath),
        }));
        const enrichedHeadingText = extractSectionHeadingText(enriched.sections);
        result.backupPath = persistLocalBackup(
          args,
          record,
          { docContent, fields: enriched.fields, sections: enriched.sections },
          {
            input,
            asrModel: result.asrModel,
            asrAttempts: result.asrAttempts,
            asrFallbackUsed: result.asrFallbackUsed,
            asrPrimaryError: result.asrPrimaryError,
            summaryStatus: result.summaryStatus,
          },
        );
        updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
          backupPath: result.backupPath || null,
          backupPathRelative: result.backupPath ? safeRelativePath(result.backupPath) : null,
        });

        const summaryRecordId = bitableResult?.record?.record_id || existingBitableRecord?.record_id;
        if (summaryRecordId) {
          try {
            currentStage = '回填多维表格摘要';
            await withProgress(videoPrefix, '回填多维表格摘要', () =>
              retryOperation({
                prefix: videoPrefix,
                label: '回填多维表格摘要',
                attempts: RETRY_FEISHU_BITABLE_ATTEMPTS,
                delayMs: RETRY_FEISHU_BITABLE_DELAY_MS,
                fn: () =>
                  feishu.updateRecord(
                    client,
                    args.bitableAppToken,
                    args.bitableTableId,
                    summaryRecordId,
                    {
                      核心要点: enriched.fields['核心要点'],
                      标签: enriched.fields['标签'],
                      主题: enriched.fields['主题'],
                    },
                  ),
              }),
            );
            updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
              summaryBitableError: null,
            });
          } catch (summaryBitableErr) {
            const warning = `多维表格摘要回填失败: ${formatError(summaryBitableErr)}`;
            console.warn(`[${nowClock()}]${videoPrefix} ${warning}`);
            result.warnings.push(warning);
            updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
              summaryBitableStatus: 'failed',
              summaryBitableError: formatError(summaryBitableErr),
            });
          }
        }

        try {
          currentStage = '回填飞书文档全文';
          await waitForFeishuDocWriteWindow(
            videoPrefix,
            '回填飞书文档全文',
            args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
          );
          await withProgress(videoPrefix, '回填飞书文档全文', async () => {
            return retryOperation({
              prefix: videoPrefix,
              label: '回填飞书文档全文',
              attempts: RETRY_FEISHU_DOC_ATTEMPTS,
              delayMs: Math.max(
                RETRY_FEISHU_DOC_DELAY_MS,
                args.docWritePolicy?.singleMinIntervalMs || FEISHU_DOC_MIN_INTERVAL_MS,
              ),
              fn: () =>
                feishu.withDocumentMutationLock(args.docToken, async () => {
                  const currentRange =
                    (await feishu.findSectionRangeByHeading(client, args.docToken, headingText)) ||
                    (await feishu.findSectionRangeByVideoId(client, args.docToken, record.videoId));
                  if (!currentRange) {
                    throw new Error(`未找到待更新区块: ${headingText}`);
                  }
                  return feishu.replaceVideoSectionSafely(
                    client,
                    args.docToken,
                    currentRange,
                    enriched.sections,
                  );
                }),
            });
          });
          headingText = enrichedHeadingText || headingText;
          result.summaryStatus = 'written';
          updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
            summaryStatus: 'written',
            summaryTopic: record.topic || null,
            summaryError: null,
            summaryDocError: null,
            summaryBitableError: null,
          });
        } catch (summaryDocErr) {
          const warning = `飞书文档回填失败: ${formatError(summaryDocErr)}`;
          console.warn(`[${nowClock()}]${videoPrefix} ${warning}`);
          result.warnings.push(warning);
          result.summaryStatus = 'partial';
          updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
            summaryStatus: 'partial',
            summaryDocError: formatError(summaryDocErr),
            summaryError: null,
          });
        }
      }
    }

    result.status = result.warnings.length ? 'success_with_warnings' : 'success';
    result.totalElapsedMs = Date.now() - taskStartedAt;
    logProgress(videoPrefix, `当前视频处理完成，总耗时 ${formatElapsedMs(Date.now() - taskStartedAt)}`);
    return result;
  } catch (err) {
    const error = formatError(err);
    const prefix = buildStepPrefix(positionLabel, videoId);
    if (currentStage.includes('飞书文档')) {
      noteFeishuDocRateLimit(err);
    }
    if (videoId && currentStage === '执行语音转文字' && isSilenceAsrFailure(err)) {
      result.error = '';
      result.failedStage = '';
      result.status = 'skipped';
      result.skipReason = 'silence_audio';
      result.docAction = 'skip';
      result.bitableAction = 'skip';
      result.summaryStatus = 'skipped';
      result.totalElapsedMs = Date.now() - taskStartedAt;
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'silence_skipped',
        publishDate: getPublishDate(videoInfo?.publishTime || ''),
        failedStage: currentStage,
        error,
        ...buildCheckpointTargetPatch(args.writeTarget),
      });
      logProgress(prefix, 'ASR 判定为静音/无有效语音，已标记为跳过，不写入飞书');
      return result;
    }
    result.error = error;
    result.failedStage = currentStage;
    result.totalElapsedMs = Date.now() - taskStartedAt;
    if (videoId) {
      updateItemCheckpoint(checkpoint, effectiveCheckpointPath, videoId, {
        status: 'failed',
        failedStage: currentStage,
        error,
      });
    }
    console.error(`[${nowClock()}]${prefix} 失败: ${error}`);
    return result;
  }
}

function printRunSummary(results, checkpointPath) {
  const counts = {
    success: 0,
    successWithWarnings: 0,
    skipped: 0,
    failed: 0,
  };

  for (const item of results) {
    if (item.status === 'success') counts.success += 1;
    else if (item.status === 'success_with_warnings') counts.successWithWarnings += 1;
    else if (item.status === 'skipped') counts.skipped += 1;
    else counts.failed += 1;
  }

  logProgress(
    '',
    `处理汇总: 成功 ${counts.success}，成功但有告警 ${counts.successWithWarnings}，跳过 ${counts.skipped}，失败 ${counts.failed}`,
  );

  for (const item of results) {
    const prefix = buildStepPrefix(item.positionLabel, item.videoId);
    if (item.status === 'skipped') {
      logProgress(prefix, `结果: 跳过 | 原因 ${item.skipReason || 'unknown'} | 总耗时 ${formatElapsedMs(item.totalElapsedMs)}`);
      continue;
    }
    if (item.status === 'failed') {
      logProgress(
        prefix,
        `结果: 失败 | 阶段 ${item.failedStage || 'unknown'} | 原因 ${item.error || 'unknown'} | 总耗时 ${formatElapsedMs(item.totalElapsedMs)}`,
      );
      continue;
    }

    const warningText = item.warnings.length ? ` | 告警 ${item.warnings.join('；')}` : '';
    logProgress(
      prefix,
      `结果: 成功 | 文档 ${item.docAction} | 表格 ${item.bitableAction} | 摘要 ${item.summaryStatus} | 总耗时 ${formatElapsedMs(item.totalElapsedMs)}${warningText}`,
    );
  }

  logProgress('', `全部处理完成，checkpoint: ${checkpointPath}`);
  return counts;
}

function isSuccessLikeResultStatus(status) {
  return status === 'success' || status === 'success_with_warnings';
}

function buildResultStateValidation(
  args,
  checkpoint,
  result,
  targetSignature,
  writeIndexState,
  catalogByVideoId,
  checklistByVideoId,
) {
  const videoId = String(result?.videoId || '').trim();
  if (!videoId) {
    return {
      backupAvailable: false,
      checkpointWritten: false,
      indexPresent: false,
      catalogPresent: false,
      checklistStatus: '',
      checklistCompleted: false,
      bitableRecordId: '',
      passed: false,
    };
  }

  const checkpointItem = checkpoint?.items?.[videoId];
  const matchedCheckpointItem =
    checkpointItem && matchesCheckpointTarget(checkpointItem, targetSignature) ? checkpointItem : null;
  const catalogItem = catalogByVideoId.get(videoId) || null;
  const checklistItem = checklistByVideoId.get(videoId) || null;
  const indexEntry = writeIndexState?.entriesByVideoId?.get(videoId) || null;
  const backupAvailable = hasTargetBackupArtifacts(args, videoId, result);
  const checkpointStatus = String(matchedCheckpointItem?.status || '').trim();
  const checkpointWritten = checkpointStatus === 'written';
  const indexPresent = Boolean(indexEntry?.docPresent);
  const catalogPresent = Boolean(
    catalogItem &&
      isDocActionPresent(catalogItem.docAction) &&
      isBitableActionPresent(catalogItem.bitableAction),
  );
  const checklistStatus = String(checklistItem?.status || '').trim();
  const checklistCompleted = checklistItem?.completed === true || checklistStatus === 'written';
  const bitableRecordId = String(
    matchedCheckpointItem?.bitableRecordId || catalogItem?.bitableRecordId || result?.bitableRecordId || '',
  ).trim();
  const bitableOnlyPassed =
    backupAvailable &&
    Boolean(bitableRecordId) &&
    (checkpointStatus === 'bitable_written' ||
      checklistItem?.bitablePresent === true ||
      isBitableActionPresent(catalogItem?.bitableAction || '') ||
      isBitableActionPresent(result?.bitableAction || ''));
  const passed = args.dryRun
    ? backupAvailable
    : args.skipDocWrite
      ? bitableOnlyPassed
    : backupAvailable &&
      checkpointWritten &&
      indexPresent &&
      catalogPresent &&
      checklistCompleted &&
      Boolean(bitableRecordId);

  return {
    backupAvailable,
    checkpointWritten,
    indexPresent,
    catalogPresent,
    checklistStatus,
    checklistCompleted,
    bitableRecordId,
    passed,
  };
}

function serializeRunResult(
  args,
  checkpoint,
  result,
  targetSignature,
  writeIndexState,
  catalogByVideoId,
  checklistByVideoId,
) {
  const videoId = String(result?.videoId || '').trim();
  const targetBackupDir = getExistingTargetBackupDir(args, videoId);
  const backupCandidate = !targetBackupDir && videoId ? findBestBackupCandidate(args, videoId) : null;
  const record =
    (targetBackupDir && readJsonFileSafe(path.join(targetBackupDir, 'record.json'))) ||
    (backupCandidate && readJsonFileSafe(backupCandidate.recordPath)) ||
    null;
  const checkpointItem = checkpoint?.items?.[videoId] || {};
  const catalogItem = catalogByVideoId.get(videoId) || {};
  const validation = buildResultStateValidation(
    args,
    checkpoint,
    result,
    targetSignature,
    writeIndexState,
    catalogByVideoId,
    checklistByVideoId,
  );

  return {
    positionLabel: result.positionLabel,
    input: result.input,
    videoId,
    title: result.title || record?.title || checkpointItem.title || catalogItem.title || '',
    topic: record?.topic || checkpointItem.summaryTopic || catalogItem.topic || '',
    publishTime: result.publishTime || record?.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
    publishDate: getPublishDate(
      result.publishTime || record?.publishTime || checkpointItem.publishTime || catalogItem.publishTime || '',
    ),
    status: result.status,
    skipReason: result.skipReason || '',
    warnings: Array.isArray(result.warnings) ? result.warnings.slice() : [],
    summaryStatus: result.summaryStatus || '',
    docAction: result.docAction || '',
    bitableAction: result.bitableAction || '',
    failedStage: result.failedStage || '',
    error: result.error || '',
    totalElapsedMs: Number(result.totalElapsedMs || 0),
    asrModel: result.asrModel || checkpointItem.asrModel || '',
    backupPath: result.backupPath || targetBackupDir || backupCandidate?.dir || '',
    contentFingerprint:
      result.contentFingerprint || checkpointItem.contentFingerprint || catalogItem.contentFingerprint || '',
    contentNormalizedLength: Number(
      result.contentNormalizedLength ||
        checkpointItem.contentNormalizedLength ||
        catalogItem.contentNormalizedLength ||
        0,
    ),
    dedupeStatus: result.dedupeStatus || checkpointItem.dedupeStatus || catalogItem.dedupeStatus || '',
    canonicalVideoId:
      result.canonicalVideoId || checkpointItem.canonicalVideoId || catalogItem.canonicalVideoId || '',
    duplicateOfVideoId:
      result.duplicateOfVideoId || checkpointItem.duplicateOfVideoId || catalogItem.duplicateOfVideoId || '',
    duplicateSimilarity:
      result.duplicateSimilarity ??
      checkpointItem.duplicateSimilarity ??
      catalogItem.duplicateSimilarity ??
      null,
    pendingDoc: Boolean(result.pendingDoc),
    validation,
  };
}

function buildSyncRunSummary(args, checkpoint, results, counts, stopRequested = false) {
  const target = args.writeTarget || buildWriteTarget(args);
  const targetSignature = buildWriteTargetSignature(target);
  const catalog = loadTargetCatalog(args);
  const checklist = loadTargetTimelineChecklist(args);
  const catalogByVideoId = new Map(
    (Array.isArray(catalog.items) ? catalog.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );
  const checklistByVideoId = new Map(
    (Array.isArray(checklist.items) ? checklist.items : [])
      .map((item) => [String(item?.videoId || '').trim(), item])
      .filter(([videoId]) => videoId),
  );
  const serializedResults = results.map((item) =>
    serializeRunResult(
      args,
      checkpoint,
      item,
      targetSignature,
      args.writeIndexState,
      catalogByVideoId,
      checklistByVideoId,
    ),
  );
  const validatedWritten = serializedResults
    .filter((item) => isSuccessLikeResultStatus(item.status) && item.validation.passed)
    .sort((left, right) => {
      const leftTs = parsePublishTimestamp(left.publishTime) ?? 0;
      const rightTs = parsePublishTimestamp(right.publishTime) ?? 0;
      if (leftTs !== rightTs) return rightTs - leftTs;
      return String(right.videoId || '').localeCompare(String(left.videoId || ''));
    });
  const reportableWritten = validatedWritten.filter((item) => {
    const checklistStatus = String(item.validation?.checklistStatus || '').trim();
    const itemStatus = String(item.status || '').trim();
    const dedupeStatus = String(item.dedupeStatus || '').trim();
    return (
      !['duplicate_skipped', 'silence_skipped'].includes(checklistStatus) &&
      !['duplicate_skipped', 'silence_skipped'].includes(itemStatus) &&
      dedupeStatus !== 'duplicate'
    );
  });
  const duplicateSkipped = serializedResults.filter((item) => {
    const checklistStatus = String(item.validation?.checklistStatus || '').trim();
    const itemStatus = String(item.status || '').trim();
    const dedupeStatus = String(item.dedupeStatus || '').trim();
    return checklistStatus === 'duplicate_skipped' || itemStatus === 'duplicate_skipped' || dedupeStatus === 'duplicate';
  }).length;
  const validationFailed = serializedResults.filter(
    (item) => isSuccessLikeResultStatus(item.status) && !item.validation.passed,
  );

  let status = 'success';
  if (!serializedResults.length) {
    status = 'noop';
  } else if ((counts.failed || 0) >= serializedResults.length) {
    status = 'failed';
  } else if ((counts.failed || 0) > 0 || validationFailed.length > 0 || stopRequested) {
    status = 'partial_failure';
  }

  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    operation: 'sync',
    status,
    syncMode: args.syncMode || '',
    dryRun: args.dryRun === true,
    stopRequested: stopRequested === true,
    target,
    paths: {
      checkpointPath: args.checkpoint || '',
      indexLogPath: args.indexLogPath || '',
      catalogPath: getTargetCatalogPath(args) || '',
      checklistPath: getTargetTimelineChecklistPath(args) || '',
      backupRoot: getTargetBackupRoot(args) || '',
    },
    counts: {
      total: serializedResults.length,
      success: Number(counts.success || 0),
      successWithWarnings: Number(counts.successWithWarnings || 0),
      skipped: Number(counts.skipped || 0),
      failed: Number(counts.failed || 0),
      validatedWritten: validatedWritten.length,
      reportableWritten: reportableWritten.length,
      duplicateSkipped,
      validationFailed: validationFailed.length,
    },
    representativeVideos: reportableWritten.slice(0, 3).map((item) => ({
      videoId: item.videoId,
      publishTime: item.publishTime,
      publishDate: item.publishDate,
      title: item.title,
      topic: item.topic,
      link: item.videoId ? `https://www.douyin.com/video/${item.videoId}` : '',
    })),
    results: serializedResults,
  };
}

function buildNoopRunSummary(args, operation, message, extra = {}) {
  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    operation,
    status: 'noop',
    message,
    target: args.writeTarget || buildWriteTarget(args),
    paths: {
      checkpointPath: args.checkpoint || '',
      indexLogPath: args.indexLogPath || '',
      catalogPath: getTargetCatalogPath(args) || '',
      checklistPath: getTargetTimelineChecklistPath(args) || '',
      backupRoot: getTargetBackupRoot(args) || '',
    },
    ...extra,
  };
}

function buildEngagementRunSummary(args, refreshResult) {
  const summary = refreshResult?.summary || {
    success: 0,
    created: 0,
    updated: 0,
    docUpdated: 0,
    docUpdateFailed: 0,
    docUpdateFailedItems: [],
    missingBackup: 0,
    failed: 0,
    commentBodyUnavailable: 0,
    skippedNoDiff: 0,
    updatedItems: [],
  };
  return {
    schemaVersion: 1,
    generatedAt: new Date().toISOString(),
    operation: 'refresh_engagement_recent_diff',
    status:
      refreshResult?.status ||
      (Number(summary.docUpdateFailed || 0) > 0 ? 'success_with_warnings' : 'success'),
    message: refreshResult?.message || '',
    recentDays: Number(refreshResult?.recentDays || args.refreshEngagementRecentDays || 0),
    target: args.writeTarget || buildWriteTarget(args),
    paths: {
      checkpointPath: args.checkpoint || '',
      indexLogPath: args.indexLogPath || '',
      catalogPath: getTargetCatalogPath(args) || '',
      checklistPath: getTargetTimelineChecklistPath(args) || '',
      backupRoot: getTargetBackupRoot(args) || '',
    },
    counts: {
      success: Number(summary.success || 0),
      created: Number(summary.created || 0),
      updated: Number(summary.updated || 0),
      docUpdated: Number(summary.docUpdated || 0),
      docUpdateFailed: Number(summary.docUpdateFailed || 0),
      missingBackup: Number(summary.missingBackup || 0),
      failed: Number(summary.failed || 0),
      commentBodyUnavailable: Number(summary.commentBodyUnavailable || 0),
      skippedNoDiff: Number(summary.skippedNoDiff || 0),
    },
    updatedItems: Array.isArray(summary.updatedItems) ? summary.updatedItems : [],
    docUpdateFailedItems: Array.isArray(summary.docUpdateFailedItems)
      ? summary.docUpdateFailedItems
      : [],
  };
}

function maybeWriteRunSummary(args, payload) {
  const outputPath = String(args?.runSummaryJson || '').trim();
  if (!outputPath || !payload) {
    return;
  }
  ensureParentDir(outputPath);
  writeJsonFile(outputPath, payload);
}

async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (
    !args.inputs.length &&
    !args.syncMode &&
    !args.rewriteTarget &&
    !args.reconcileTarget &&
    !args.backfillMissingBackups &&
    !args.backfillDocPending &&
    !args.backfillDocAll &&
    !args.backfillBitableFields &&
    !args.backfillCommentsEngagement &&
    !(args.refreshEngagementRecentDays > 0)
  ) {
    printUsage();
    process.exit(1);
  }

  const checkpoint = args.resume ? loadCheckpoint(args.checkpoint) : { items: {} };
  activeFirstHeartbeatSeconds = args.progressHeartbeatSeconds || DEFAULT_PROGRESS_FIRST_HEARTBEAT_SECONDS;
  activeRepeatHeartbeatSeconds =
    args.progressHeartbeatSeconds || DEFAULT_PROGRESS_REPEAT_HEARTBEAT_SECONDS;

  const client = feishu.createClient();
  args.docToken = await withProgress('', '解析飞书文档 token', () =>
    feishu.resolveDocToken(client, args.docToken),
  );
  args.bitableAppToken = await withProgress('', '解析多维表格 token', () =>
    feishu.resolveBitableAppToken(client, args.bitableAppToken),
  );
  args.writeTarget = buildWriteTarget(args);
  args.writeIndexState = loadWriteIndexState(args, checkpoint);
  seedTargetTimelineChecklistFromLocalState(args, checkpoint);
  args.dedupeState = refreshTargetDedupeState(args, checkpoint, args.checkpoint);
  const dedupeItems = [...(args.dedupeState?.itemsByVideoId?.values?.() || [])];
  const dedupeDuplicateCount = dedupeItems.filter((item) => item.dedupeStatus === 'duplicate').length;
  if (dedupeItems.length) {
    logProgress(
      '',
      `内容去重索引已刷新: canonical ${dedupeItems.length - dedupeDuplicateCount} 条 | duplicate ${dedupeDuplicateCount} 条`,
    );
  }

  if (args.reconcileTarget) {
    await reconcileTarget(client, args, checkpoint, args.checkpoint);
    logProgress('', `对账完成，checkpoint: ${args.checkpoint}`);
    process.exit(0);
  }

  if (args.backfillBitableFields) {
    await backfillBitableFieldsFromBackups(client, args, checkpoint, args.checkpoint);
    logProgress('', `多维表格字段回填完成，checkpoint: ${args.checkpoint}`);
    process.exit(0);
  }

  if (args.backfillCommentsEngagement) {
    await backfillCommentsEngagement(client, args, checkpoint, args.checkpoint);
    logProgress('', `评论与互动数据刷新完成，checkpoint: ${args.checkpoint}`);
    process.exit(0);
  }

  if (args.refreshEngagementRecentDays > 0) {
    const refreshResult = await refreshEngagementRecentIfDiff(client, args, checkpoint, args.checkpoint);
    maybeWriteRunSummary(args, buildEngagementRunSummary(args, refreshResult));
    return;
  }

  let inputs;
  if (args.backfillMissingBackups) {
    args.forceRewrite = true;
    inputs = collectMissingBackupInputs(args, checkpoint);
    if (!inputs.length) {
      logProgress('', '当前目标没有缺本地备份的条目');
      process.exit(0);
    }
    logProgress(
      '',
      `缺备份补齐模式: 共 ${inputs.length} 条，将执行“重新抓取 -> 本地补齐 -> 覆盖飞书为最新格式”`,
    );
  } else if (args.backfillDocPending) {
    inputs = args.inputs.length ? selectExplicitVideoInputs(args, checkpoint, 'pending') : collectDocPendingInputs(args, checkpoint);
    if (!inputs.length) {
      logProgress('', '当前目标没有待补写文档的条目');
      process.exit(0);
    }
    const appliedLimit = args.limitProvided
      ? Math.max(1, Number(args.limit) || inputs.length)
      : BACKFILL_DOC_PENDING_DEFAULT_LIMIT;
    logProgress(
      '',
      args.inputs.length
        ? `文档回填模式: 共 ${inputs.length} 条，按显式清单直接复用本地备份补写飞书文档`
        : `文档回填模式: 共 ${inputs.length} 条，将直接复用本地备份补写飞书文档`,
    );
    if (!args.limitProvided && inputs.length > appliedLimit) {
      inputs = inputs.slice(0, appliedLimit);
      logProgress(
        '',
        `文档回填默认限流已生效：本轮仅处理 ${inputs.length} 条，剩余条目留待下次 cron 继续补写`,
      );
    } else if (args.limitProvided) {
      logProgress('', `文档回填已应用显式 limit=${appliedLimit}`);
    }
  } else if (args.backfillDocAll) {
    args.forceRewrite = true;
    inputs = args.inputs.length ? selectExplicitVideoInputs(args, checkpoint, 'all') : collectDocPendingInputs(args, checkpoint);
    if (!inputs.length) {
      logProgress('', '当前目标没有可重写的文档条目');
      process.exit(0);
    }
    logProgress(
      '',
      args.inputs.length
        ? `文档全量重写模式: 共 ${inputs.length} 条，按显式清单直接复用本地备份重写飞书文档`
        : `文档全量重写模式: 共 ${inputs.length} 条，将直接复用本地备份重写飞书文档`,
    );
  } else {
    inputs = await resolveSyncInputs(args, checkpoint);
  }
  if (!inputs.length) {
    const message = '本次没有待处理视频';
    logProgress('', message);
    maybeWriteRunSummary(
      args,
      buildNoopRunSummary(args, 'sync', message, {
        syncMode: args.syncMode || '',
        dryRun: args.dryRun === true,
        counts: {
          total: 0,
          success: 0,
          successWithWarnings: 0,
          skipped: 0,
          failed: 0,
          validatedWritten: 0,
          validationFailed: 0,
        },
        representativeVideos: [],
        results: [],
      }),
    );
    return;
  }
  args.docWritePolicy = buildDocWritePolicy(args, inputs.length);

  logProgress(
    '',
    args.backfillDocAll
      ? `本次共 ${inputs.length} 条，按“本地备份 -> 重写文档”顺序执行`
      : args.backfillDocPending
      ? `本次共 ${inputs.length} 条，按“本地备份 -> 补写文档”顺序执行`
      : args.skipDocWrite
        ? `本次共 ${inputs.length} 条，按“转写一条、表格一条、文档后补”顺序执行`
        : args.docWritePolicy.enabled
      ? `本次共 ${inputs.length} 条，按“转写一条、表格一条、文档批量写入”顺序执行`
      : `本次共 ${inputs.length} 条，按“转写一条，写入一条”顺序执行`,
  );
  logProgress(
    '',
    `写入目标: 文档 ${args.writeTarget.docToken} | 表格 ${args.writeTarget.bitableAppToken}/${args.writeTarget.bitableTableId}`,
  );
  logProgress('', `索引日志: ${args.indexLogPath}`);
  logProgress('', `本地 checklist: ${getTargetTimelineChecklistPath(args) || '未启用'}`);
  if (args.docWritePolicy.enabled) {
    logProgress(
      '',
      `文档策略: 历史回填批量写入 | 批次 ${args.docWritePolicy.batchSize} 条 | 单次最小间隔 ${formatElapsedMs(args.docWritePolicy.batchMinIntervalMs)}`,
    );
  } else if (args.skipDocWrite) {
    logProgress('', '文档策略: 主链路跳过，后续通过 --backfill-doc-pending 单独补写');
  } else if (args.backfillDocAll) {
    logProgress('', `文档策略: 全量重写已有与缺失条目 | 单次最小间隔 ${formatElapsedMs(args.docWritePolicy.singleMinIntervalMs)}`);
  } else if (args.backfillDocPending) {
    logProgress('', `文档策略: 仅补写待补条目 | 单次最小间隔 ${formatElapsedMs(args.docWritePolicy.singleMinIntervalMs)}`);
  } else {
    logProgress('', `文档策略: 即时写入 | 单次最小间隔 ${formatElapsedMs(args.docWritePolicy.singleMinIntervalMs)}`);
  }
  if (args.syncMode && !args.backfillDocPending && !args.backfillDocAll) {
    logProgress('', `抖音登录态: ${args.douyinStorageStatePath}`);
  }

  const results = [];
  const pendingDocQueue = [];
  let stopRequested = false;
  for (const [index, input] of inputs.entries()) {
    // eslint-disable-next-line no-await-in-loop
    const result =
      // eslint-disable-next-line no-await-in-loop
      await processOne(client, args, checkpoint, args.checkpoint, input, index + 1, inputs.length);
    results.push(result);
    seedTargetTimelineChecklistFromLocalState(args, checkpoint);

    const currentDocRateLimited =
      result.status === 'failed' &&
      String(result.failedStage || '').includes('飞书文档') &&
      String(result.error || '').includes('99991400');
    const currentDocWriteBlocked =
      result.status === 'failed' &&
      String(result.failedStage || '').includes('飞书文档') &&
      (String(result.error || '').includes('99991400') ||
        String(result.error || '').includes('超时'));

    if (currentDocRateLimited && STOP_ON_FEISHU_DOC_RATE_LIMIT) {
      logProgress('', '命中飞书文档限频，已停止后续处理');
      stopRequested = true;
      break;
    }
    if (
      currentDocWriteBlocked &&
      (args.backfillDocPending || args.backfillDocAll) &&
      !currentDocRateLimited
    ) {
      logProgress('', '文档后补命中飞书文档阻塞（超时/限频），已停止后续处理，剩余条目留待下次继续');
      stopRequested = true;
      break;
    }

    if (args.docWritePolicy.enabled) {
      if (result.pendingDoc) {
        pendingDocQueue.push({
          result,
          ...result.pendingDoc,
        });
      }

      const shouldFlushByBoundary = pendingDocQueue.length > 0 && !result.pendingDoc;
      const shouldFlushBySize = pendingDocQueue.length >= args.docWritePolicy.batchSize;
      const shouldFlushByEnd = pendingDocQueue.length > 0 && index === inputs.length - 1;
      if (shouldFlushByBoundary || shouldFlushBySize || shouldFlushByEnd) {
        // eslint-disable-next-line no-await-in-loop
        const flushOutcome = await flushPendingDocBatch(
          client,
          args,
          checkpoint,
          args.checkpoint,
          pendingDocQueue,
        );
        seedTargetTimelineChecklistFromLocalState(args, checkpoint);
        if (!flushOutcome.flushed) {
          if (flushOutcome.stoppedByRateLimit) {
            logProgress('', '批量写入命中飞书文档限频，已停止后续处理');
          } else {
            logProgress('', '批量写入飞书文档失败，已停止后续处理');
          }
          stopRequested = true;
          break;
        }
      }
    }
  }

  if (!stopRequested && args.docWritePolicy.enabled && pendingDocQueue.length) {
    const flushOutcome = await flushPendingDocBatch(
      client,
      args,
      checkpoint,
      args.checkpoint,
      pendingDocQueue,
    );
    seedTargetTimelineChecklistFromLocalState(args, checkpoint);
    if (!flushOutcome.flushed) {
      if (flushOutcome.stoppedByRateLimit) {
        logProgress('', '批量写入命中飞书文档限频，已提前结束');
      } else {
        logProgress('', '批量写入飞书文档失败，已提前结束');
      }
    }
  }

  const counts = printRunSummary(results, args.checkpoint);
  maybeWriteRunSummary(args, buildSyncRunSummary(args, checkpoint, results, counts, stopRequested));
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

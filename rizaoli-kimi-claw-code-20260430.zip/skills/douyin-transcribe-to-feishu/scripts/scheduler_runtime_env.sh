#!/usr/bin/env bash

# Scheduler runtime helpers shared by launchd / systemd / cron entrypoints.

append_path_entries() {
  local entry
  for entry in "$@"; do
    [[ -n "${entry}" && -d "${entry}" ]] || continue
    case ":${PATH:-}:" in
      *":${entry}:"*) ;;
      *)
        if [[ -n "${PATH:-}" ]]; then
          PATH="${entry}:${PATH}"
        else
          PATH="${entry}"
        fi
        ;;
    esac
  done
  export PATH
}

setup_scheduler_runtime_env() {
  append_path_entries \
    "/opt/homebrew/bin" \
    "/usr/local/bin" \
    "/usr/local/sbin" \
    "/usr/bin" \
    "/bin" \
    "${HOME}/.npm-global/bin" \
    "${HOME}/.local/bin" \
    "${HOME}/.fnm/current/bin" \
    "${HOME}/.volta/bin" \
    "${HOME}/.asdf/shims" \
    "${HOME}/.cargo/bin"
}

resolve_command_bin() {
  local command_name=${1:-}
  local explicit_path=${2:-}
  shift 2 || true

  local candidate=""
  local expanded=""
  local match=""

  if [[ -n "${explicit_path}" ]]; then
    expanded="${explicit_path/#\~/${HOME}}"
    if [[ -x "${expanded}" ]]; then
      printf '%s\n' "${expanded}"
      return 0
    fi
  fi

  if command -v "${command_name}" >/dev/null 2>&1; then
    command -v "${command_name}"
    return 0
  fi

  for candidate in "$@"; do
    expanded="${candidate/#\~/${HOME}}"
    if [[ "${expanded}" == *'*'* || "${expanded}" == *'?'* || "${expanded}" == *'['* ]]; then
      while IFS= read -r match; do
        if [[ -x "${match}" ]]; then
          printf '%s\n' "${match}"
          return 0
        fi
      done < <(compgen -G "${expanded}" || true)
      continue
    fi

    if [[ -x "${expanded}" ]]; then
      printf '%s\n' "${expanded}"
      return 0
    fi
  done

  return 1
}

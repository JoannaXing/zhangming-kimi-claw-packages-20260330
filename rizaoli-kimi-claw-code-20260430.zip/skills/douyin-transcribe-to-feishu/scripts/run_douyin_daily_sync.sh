#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SKILL_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
# shellcheck source=./scheduler_runtime_env.sh
source "$SCRIPT_DIR/scheduler_runtime_env.sh"

eval "$(
  python3 "$SCRIPT_DIR/read_scheduler_config.py" --format env
)"

RUNS_DIR="$SKILL_DIR/.state/runs"
TIMESTAMP="$(date '+%Y%m%d-%H%M%S')"
RUN_ID="$TIMESTAMP"
RUN_DIR="$RUNS_DIR/$RUN_ID"
DEDUPE_DIR="$SKILL_DIR/.state/cron-dedupe"
SYNC_SUMMARY_PATH="$RUN_DIR/sync-summary.json"
ENGAGEMENT_SUMMARY_PATH="$RUN_DIR/engagement-summary.json"
RUN_SUMMARY_PATH="$RUN_DIR/run-summary.json"
RUN_REPORT_PATH="$RUN_DIR/run-report.md"
LATEST_SUMMARY_PATH="$RUNS_DIR/latest.json"
LATEST_REPORT_PATH="$RUNS_DIR/latest-report.md"

mkdir -p "$scheduler_log_dir" "$(dirname "$scheduler_lock_file")" "$checkpoint_dir" "$RUN_DIR" "$DEDUPE_DIR"

if [[ -f "$scheduler_env_file" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$scheduler_env_file"
  set +a
fi

setup_scheduler_runtime_env

LOCK_DIR="${scheduler_lock_file}.lockdir"
LOG_FILE="$scheduler_log_dir/douyin-sync-$TIMESTAMP.log"
LOCK_META_FILE="$LOCK_DIR/owner.env"
LOCK_STALE_AFTER_SECS="${DOUYIN_SYNC_LOCK_STALE_AFTER_SECS:-900}"
BUSINESS_TIMEZONE="${DOUYIN_SYNC_BUSINESS_TIMEZONE:-Asia/Singapore}"
FORCE_RUN_RAW="${DOUYIN_SYNC_FORCE_RUN:-0}"

get_path_mtime_epoch() {
  python3 - "$1" <<'PY'
import os
import sys

path = sys.argv[1]
try:
    print(int(os.path.getmtime(path)))
except Exception:
    print(0)
PY
}

is_truthy() {
  case "${1:-}" in
    1|true|TRUE|yes|YES|on|ON)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

compute_business_date() {
  TZ="$BUSINESS_TIMEZONE" python3 - <<'PY'
from datetime import datetime
print(datetime.now().strftime("%Y-%m-%d"))
PY
}

read_json_field() {
  local json_path="${1:-}"
  local field_name="${2:-}"
  python3 - "$json_path" "$field_name" <<'PY'
import json
import sys
from pathlib import Path

path = Path(sys.argv[1])
field = sys.argv[2]
if not path.is_file():
    raise SystemExit(0)
try:
    payload = json.loads(path.read_text(encoding="utf-8"))
except Exception:
    raise SystemExit(0)
value = payload.get(field, "")
if value is None:
    value = ""
print(str(value))
PY
}

write_dedupe_stamp() {
  python3 - "$DEDUPE_STAMP_PATH" "$RUN_ID" "$LOG_FILE" "$RUN_SUMMARY_PATH" "$BUSINESS_DATE" "$BUSINESS_TIMEZONE" "$PIPELINE_MODE" "$SYNC_MODE" <<'PY'
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

out_path = Path(sys.argv[1])
payload = {
    "schemaVersion": 1,
    "completedAt": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
    "runId": sys.argv[2],
    "logFile": sys.argv[3],
    "summaryPath": sys.argv[4],
    "businessDate": sys.argv[5],
    "businessTimezone": sys.argv[6],
    "pipelineMode": sys.argv[7],
    "syncMode": sys.argv[8],
}
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
}

pid_is_running() {
  local pid="${1:-}"
  [[ "$pid" =~ ^[0-9]+$ ]] || return 1
  kill -0 "$pid" 2>/dev/null
}

write_lock_metadata() {
  cat >"$LOCK_META_FILE" <<EOF
pid=$$
run_id=$RUN_ID
pipeline_mode=${PIPELINE_MODE:-${DOUYIN_SYNC_PIPELINE_MODE:-full}}
started_at_epoch=$(date '+%s')
started_at_iso=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
EOF
}

write_lock_skip_summary() {
  local reason="${1:-}"
  local report_body="${2:-}"
  python3 - "$RUN_SUMMARY_PATH" "$RUN_ID" "$LOG_FILE" "$reason" "$report_body" <<'PY'
import json
import sys
from datetime import datetime
from pathlib import Path

out_path = Path(sys.argv[1])
payload = {
    "schemaVersion": 1,
    "generatedAt": datetime.now().isoformat(),
    "runId": sys.argv[2],
    "status": "skipped",
    "logFile": sys.argv[3],
    "reason": sys.argv[4],
    "report": sys.argv[5],
}
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
PY
}

emit_lock_skip_report() {
  local reason="${1:-检测到同步锁，本轮跳过}"
  local report_body
  report_body="$(cat <<EOF
🎬 视频知识库日更简报
执行时间：$(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M')
执行状态：跳过
新增视频：未执行
抖音链接：无
近7天互动核对：未执行
异常摘要：$reason
日志路径：$LOG_FILE
EOF
)"
  printf '%s\n' "$report_body" >"$RUN_REPORT_PATH"
  write_lock_skip_summary "$reason" "$report_body"
  cp "$RUN_SUMMARY_PATH" "$LATEST_SUMMARY_PATH"
  cp "$RUN_REPORT_PATH" "$LATEST_REPORT_PATH"
  {
    echo "[$(date '+%F %T')] skipped"
    echo "reason=$reason"
    echo "run_id=$RUN_ID"
    echo "run_summary=$RUN_SUMMARY_PATH"
    echo "run_report=$RUN_REPORT_PATH"
  } >>"$LOG_FILE"
  printf 'RUN_ID=%s\n' "$RUN_ID"
  printf 'RUN_LOG_PATH=%s\n' "$LOG_FILE"
  printf 'RUN_SUMMARY_PATH=%s\n' "$RUN_SUMMARY_PATH"
  printf 'RUN_REPORT_PATH=%s\n\n' "$RUN_REPORT_PATH"
  printf '%s\n' "$report_body"
}

emit_dedupe_skip_report() {
  local reason="${1:-当前业务日已完成，本轮跳过}"
  local report_body
  report_body="$(cat <<EOF
🎬 视频知识库日更简报
执行时间：$(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M')
执行状态：跳过
新增视频：未执行
抖音链接：无
近7天互动核对：未执行
异常摘要：$reason
日志路径：$LOG_FILE
EOF
)"
  printf '%s\n' "$report_body" >"$RUN_REPORT_PATH"
  write_lock_skip_summary "$reason" "$report_body"
  cp "$RUN_SUMMARY_PATH" "$LATEST_SUMMARY_PATH"
  cp "$RUN_REPORT_PATH" "$LATEST_REPORT_PATH"
  {
    echo "[$(date '+%F %T')] skipped"
    echo "reason=$reason"
    echo "run_id=$RUN_ID"
    echo "business_date=$BUSINESS_DATE"
    echo "pipeline_mode=$PIPELINE_MODE"
    echo "sync_mode=$SYNC_MODE"
    echo "dedupe_stamp=$DEDUPE_STAMP_PATH"
  } >>"$LOG_FILE"
  printf 'RUN_ID=%s\n' "$RUN_ID"
  printf 'RUN_LOG_PATH=%s\n' "$LOG_FILE"
  printf 'RUN_SUMMARY_PATH=%s\n' "$RUN_SUMMARY_PATH"
  printf 'RUN_REPORT_PATH=%s\n\n' "$RUN_REPORT_PATH"
  printf '%s\n' "$report_body"
}

acquire_lock_or_exit() {
  if mkdir "$LOCK_DIR" 2>/dev/null; then
    write_lock_metadata
    return 0
  fi

  local lock_pid=""
  local lock_run_id=""
  local lock_started_at=""
  if [[ -f "$LOCK_META_FILE" ]]; then
    while IFS='=' read -r key value; do
      case "$key" in
        pid) lock_pid="$value" ;;
        run_id) lock_run_id="$value" ;;
        started_at_iso) lock_started_at="$value" ;;
      esac
    done <"$LOCK_META_FILE"
  fi

  if pid_is_running "$lock_pid"; then
    emit_lock_skip_report "检测到同步仍在运行（pid=${lock_pid}${lock_run_id:+，run_id=${lock_run_id}}），为避免并发，本轮跳过"
    exit 0
  fi

  local now_epoch lock_mtime lock_age
  now_epoch="$(date '+%s')"
  lock_mtime="$(get_path_mtime_epoch "$LOCK_DIR")"
  lock_age=$(( now_epoch - lock_mtime ))
  if [[ "$lock_mtime" -gt 0 && "$lock_age" -ge "$LOCK_STALE_AFTER_SECS" ]]; then
    {
      echo "[$(date '+%F %T')] stale lock detected"
      echo "stale_lock_dir=$LOCK_DIR"
      echo "stale_lock_age_secs=$lock_age"
      echo "stale_lock_pid=${lock_pid:-<none>}"
      echo "stale_lock_run_id=${lock_run_id:-<none>}"
      echo "stale_lock_started_at=${lock_started_at:-<unknown>}"
    } >>"$LOG_FILE"
    rm -rf "$LOCK_DIR"
    if mkdir "$LOCK_DIR" 2>/dev/null; then
      write_lock_metadata
      {
        echo "[$(date '+%F %T')] stale lock cleared"
        echo "lock_dir=$LOCK_DIR"
      } >>"$LOG_FILE"
      return 0
    fi
  fi

  local detail="检测到同步锁，本轮跳过"
  if [[ -n "$lock_started_at" ]]; then
    detail="检测到未释放的同步锁（开始于 ${lock_started_at}），本轮跳过"
  elif [[ "$lock_mtime" -gt 0 ]]; then
    detail="检测到最近创建的同步锁（age=${lock_age}s），本轮跳过"
  fi
  emit_lock_skip_report "$detail"
  exit 0
}

SYNC_MODE="${DOUYIN_SYNC_MODE:-$scheduler_sync_mode}"
RECENT_COUNT="${DOUYIN_SYNC_RECENT_COUNT:-$scheduler_recent_count}"
PIPELINE_MODE="${DOUYIN_SYNC_PIPELINE_MODE:-full}"
BUSINESS_DATE="${DOUYIN_SYNC_BUSINESS_DATE:-$(compute_business_date)}"
DEDUPE_STAMP_PATH="$DEDUPE_DIR/${PIPELINE_MODE}__${SYNC_MODE}__${BUSINESS_DATE}.json"

acquire_lock_or_exit

cleanup() {
  rm -rf "$LOCK_DIR"
}
trap cleanup EXIT INT TERM

if ! is_truthy "$FORCE_RUN_RAW" && [[ -f "$DEDUPE_STAMP_PATH" ]]; then
  COMPLETED_AT="$(read_json_field "$DEDUPE_STAMP_PATH" completedAt)"
  PREVIOUS_RUN_ID="$(read_json_field "$DEDUPE_STAMP_PATH" runId)"
  PREVIOUS_LOG_FILE="$(read_json_field "$DEDUPE_STAMP_PATH" logFile)"
  DEDUPE_REASON="业务日 ${BUSINESS_DATE} 的 ${PIPELINE_MODE}/${SYNC_MODE} 已完成"
  if [[ -n "$COMPLETED_AT" ]]; then
    DEDUPE_REASON="${DEDUPE_REASON}（completed_at=${COMPLETED_AT}"
    if [[ -n "$PREVIOUS_RUN_ID" ]]; then
      DEDUPE_REASON="${DEDUPE_REASON}，run_id=${PREVIOUS_RUN_ID}"
    fi
    DEDUPE_REASON="${DEDUPE_REASON}）"
  fi
  if [[ -n "$PREVIOUS_LOG_FILE" ]]; then
    DEDUPE_REASON="${DEDUPE_REASON}，原日志：${PREVIOUS_LOG_FILE}"
  fi
  emit_dedupe_skip_report "$DEDUPE_REASON"
  exit 0
fi

ARGS=()
case "$PIPELINE_MODE" in
  full|skip_doc_write)
    case "$SYNC_MODE" in
      incremental)
        ARGS+=(--sync-incremental)
        ;;
      latest)
        ARGS+=(--sync-latest)
        ;;
      recent)
        ARGS+=(--sync-recent "$RECENT_COUNT")
        ;;
      *)
        echo "不支持的同步模式: $SYNC_MODE" >&2
        exit 2
        ;;
    esac
    if [[ "$PIPELINE_MODE" == "skip_doc_write" ]]; then
      ARGS+=(--skip-doc-write)
    fi
    ;;
  backfill_doc_pending)
    ARGS+=(--backfill-doc-pending)
    ;;
  *)
    echo "不支持的执行模式: $PIPELINE_MODE" >&2
    exit 2
    ;;
esac

if [[ -n "${DOUYIN_SYNC_EXTRA_ARGS:-}" ]]; then
  # shellcheck disable=SC2206
  EXTRA_ARGS=( ${DOUYIN_SYNC_EXTRA_ARGS} )
  ARGS+=("${EXTRA_ARGS[@]}")
fi

RUN_IS_DRY_RUN=0
for arg in "${ARGS[@]}"; do
  if [[ "$arg" == "--dry-run" ]]; then
    RUN_IS_DRY_RUN=1
    break
  fi
done

{
  echo "[$(date '+%F %T')] start"
  echo "skill_dir=$SKILL_DIR"
  echo "pipeline_mode=$PIPELINE_MODE"
  echo "mode=$SYNC_MODE"
  echo "checkpoint=$checkpoint_path"
  echo "index_log=$index_log_path"
  echo "storage_state=$douyin_storage_state_path"
} >>"$LOG_FILE"

NODE_BIN_HINT="${DOUYIN_NODE_BIN:-${NODE_BIN:-}}"
NODE_BIN="$(
  resolve_command_bin \
    node \
    "$NODE_BIN_HINT" \
    "/opt/homebrew/bin/node" \
    "/usr/local/bin/node" \
    "/usr/bin/node" \
    "${HOME}/.npm-global/bin/node" \
    "${HOME}/.local/bin/node" \
    "${HOME}/.fnm/current/bin/node" \
    "${HOME}/.volta/bin/node" \
    "${HOME}/.asdf/shims/node" \
    "${HOME}/.nvm/versions/node"/*/bin/node
)" || {
  {
    echo "[$(date '+%F %T')] 未找到 node 可执行文件"
    echo "PATH=$PATH"
    echo "如为定时环境，请在 ${scheduler_env_file} 写入 NODE_BIN=/绝对路径/node"
  } >>"$LOG_FILE"
  echo "未找到 node 可执行文件，详见日志: $LOG_FILE" >&2
  exit 127
}
append_path_entries "$(dirname "$NODE_BIN")"
export NODE_BIN

{
  echo "node_bin=$NODE_BIN"
  echo "PATH=$PATH"
} >>"$LOG_FILE"

SYNC1_EXIT=0
(
  cd "$SKILL_DIR"
  "$NODE_BIN" "$SKILL_DIR/douyin-transcribe-to-feishu.js" \
    "${ARGS[@]}" \
    --checkpoint "$checkpoint_path" \
    --index-log "$index_log_path" \
    --douyin-storage-state "$douyin_storage_state_path" \
    --run-summary-json "$SYNC_SUMMARY_PATH"
) >>"$LOG_FILE" 2>&1 || SYNC1_EXIT=$?

ENG_RAN=0
SYNC2_EXIT=0
if [[ "$PIPELINE_MODE" != "backfill_doc_pending" ]] && [[ "${scheduler_engagement_refresh_enabled}" == "true" ]]; then
  ENG_RAN=1
  echo "[$(date '+%F %T')] engagement-recent-diff start (days=${scheduler_engagement_refresh_days})" >>"$LOG_FILE"
  ENG_ARGS=(
    --refresh-engagement-recent-days "${scheduler_engagement_refresh_days}"
    --checkpoint "$checkpoint_path"
    --index-log "$index_log_path"
    --douyin-storage-state "$douyin_storage_state_path"
  )
  if [[ -n "${scheduler_engagement_refresh_max_videos}" && "${scheduler_engagement_refresh_max_videos}" != "0" ]]; then
    ENG_ARGS+=(--limit "${scheduler_engagement_refresh_max_videos}")
  fi
  (
    cd "$SKILL_DIR"
    "$NODE_BIN" "$SKILL_DIR/douyin-transcribe-to-feishu.js" \
      "${ENG_ARGS[@]}" \
      --run-summary-json "$ENGAGEMENT_SUMMARY_PATH"
  ) >>"$LOG_FILE" 2>&1 || SYNC2_EXIT=$?
  echo "[$(date '+%F %T')] engagement-recent-diff done" >>"$LOG_FILE"
fi

echo "[$(date '+%F %T')] done" >>"$LOG_FILE"

COMBINE_EXIT=0
REPORT_BODY="$(
  TZ=Asia/Shanghai python3 "$SCRIPT_DIR/build_sync_run_artifacts.py" \
    --sync-summary "$SYNC_SUMMARY_PATH" \
    --engagement-summary "$ENGAGEMENT_SUMMARY_PATH" \
    --sync-exit "$SYNC1_EXIT" \
    --engagement-exit "$SYNC2_EXIT" \
    --engagement-ran "$ENG_RAN" \
    --log-file "$LOG_FILE" \
    --out-summary "$RUN_SUMMARY_PATH" \
    --out-report "$RUN_REPORT_PATH" \
    --run-id "$RUN_ID" \
    2>>"$LOG_FILE"
)" || COMBINE_EXIT=$?

if [[ "$COMBINE_EXIT" -ne 0 ]]; then
  REPORT_BODY="$(cat <<EOF
🎬 视频知识库日更简报
执行时间：$(TZ=Asia/Shanghai date '+%Y-%m-%d %H:%M')
执行状态：失败
新增视频：待从日志补充
抖音链接：无
近7天互动核对：待从日志补充
异常摘要：汇总阶段失败 | 建议先查看 $LOG_FILE
日志路径：$LOG_FILE
EOF
)"
  printf '%s\n' "$REPORT_BODY" >"$RUN_REPORT_PATH"
fi

if [[ -f "$RUN_SUMMARY_PATH" ]]; then
  cp "$RUN_SUMMARY_PATH" "$LATEST_SUMMARY_PATH"
fi
if [[ -f "$RUN_REPORT_PATH" ]]; then
  cp "$RUN_REPORT_PATH" "$LATEST_REPORT_PATH"
fi

{
  echo "run_id=$RUN_ID"
  echo "run_dir=$RUN_DIR"
  echo "run_summary=$RUN_SUMMARY_PATH"
  echo "run_report=$RUN_REPORT_PATH"
} >>"$LOG_FILE"
printf '%s\n' "$REPORT_BODY" >>"$LOG_FILE"

printf 'RUN_ID=%s\n' "$RUN_ID"
printf 'RUN_LOG_PATH=%s\n' "$LOG_FILE"
printf 'RUN_SUMMARY_PATH=%s\n' "$RUN_SUMMARY_PATH"
printf 'RUN_REPORT_PATH=%s\n\n' "$RUN_REPORT_PATH"
printf '%s\n' "$REPORT_BODY"

if [[ "${OPENCLAW_SKIP_NOTIFY:-0}" != "1" ]]; then
  /bin/bash "$SCRIPT_DIR/notify_openclaw_progress.sh" "$LOG_FILE" "$SYNC1_EXIT" "$SYNC2_EXIT" "$ENG_RAN" "$RUN_REPORT_PATH" || true
fi

FINAL_EXIT=0
if [[ "$SYNC1_EXIT" -ne 0 ]] || { [[ "$ENG_RAN" == "1" ]] && [[ "$SYNC2_EXIT" -ne 0 ]]; } || [[ "$COMBINE_EXIT" -ne 0 ]]; then
  FINAL_EXIT=1
fi
if [[ "$FINAL_EXIT" -eq 0 ]]; then
  COMBINED_STATUS="$(read_json_field "$RUN_SUMMARY_PATH" status)"
  case "$COMBINED_STATUS" in
    success|success_with_warnings|noop)
      if [[ "$RUN_IS_DRY_RUN" -eq 1 ]]; then
        {
          echo "[$(date '+%F %T')] dry-run detected; dedupe stamp skipped"
          echo "business_date=$BUSINESS_DATE"
          echo "pipeline_mode=$PIPELINE_MODE"
          echo "sync_mode=$SYNC_MODE"
          echo "status=$COMBINED_STATUS"
          echo "dedupe_stamp=$DEDUPE_STAMP_PATH"
        } >>"$LOG_FILE"
      else
        write_dedupe_stamp
        {
          echo "[$(date '+%F %T')] dedupe stamp written"
          echo "business_date=$BUSINESS_DATE"
          echo "pipeline_mode=$PIPELINE_MODE"
          echo "sync_mode=$SYNC_MODE"
          echo "status=$COMBINED_STATUS"
          echo "dedupe_stamp=$DEDUPE_STAMP_PATH"
        } >>"$LOG_FILE"
      fi
      ;;
    *)
      {
        echo "[$(date '+%F %T')] dedupe stamp skipped"
        echo "business_date=$BUSINESS_DATE"
        echo "pipeline_mode=$PIPELINE_MODE"
        echo "sync_mode=$SYNC_MODE"
        echo "status=${COMBINED_STATUS:-<missing>}"
      } >>"$LOG_FILE"
      ;;
  esac
fi
exit "$FINAL_EXIT"

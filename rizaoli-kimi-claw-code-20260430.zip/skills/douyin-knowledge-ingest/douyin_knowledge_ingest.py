#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from lib.knowledge_base_profiles import get_source_config
from lib.knowledge_base_profiles import load_profile
from lib.knowledge_base_profiles import load_scheduler
from lib.knowledge_base_profiles import sync_source_records


def has_any_flag(values: list[str], *flags: str) -> bool:
    return any(flag in values for flag in flags)


def append_flag(args: list[str], flag: str, value: str) -> None:
    if not value or flag in args:
        return
    args.extend([flag, value])


def build_scheduled_args(profile_name: str) -> list[str]:
    scheduler = load_scheduler(profile_name)
    if not scheduler.get("enabled"):
        return []

    sync_mode = str(scheduler.get("sync_mode") or "").strip()
    args: list[str] = []
    if sync_mode == "latest":
        args.append("--sync-latest")
    elif sync_mode == "incremental":
        args.append("--sync-incremental")
    elif sync_mode == "recent" and int(scheduler.get("recent_count") or 0) > 0:
        args.extend(["--sync-recent", str(int(scheduler["recent_count"]))])
    elif sync_mode == "date" and scheduler.get("target_date"):
        args.extend(["--sync-date", str(scheduler["target_date"])])
    elif sync_mode == "month" and scheduler.get("target_month"):
        args.extend(["--sync-month", str(scheduler["target_month"])])
    elif sync_mode == "oldest" and int(scheduler.get("oldest_count") or 0) > 0:
        args.extend(["--sync-oldest", str(int(scheduler["oldest_count"]))])

    refresh_days = int(scheduler.get("refresh_engagement_recent_days") or 0)
    if refresh_days > 0:
        args.extend(["--refresh-engagement-recent-days", str(refresh_days)])
    return args


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="按 profile 运行抖音知识库入库")
    parser.add_argument("inputs", nargs="*", help="抖音链接 / 分享文本 / 视频ID")
    parser.add_argument("--profile", default="rizaoli-douyin", help="知识库 profile")
    parser.add_argument("--source", default="douyin", help="source 名称")
    parser.add_argument("--scheduled", action="store_true", help="读取 scheduler.toml 生成同步参数")
    parser.add_argument("--import-legacy", action="store_true", help="同步时额外导入 legacy 备份")
    parser.add_argument("--sync-only", action="store_true", help="不触发转写，只做统一知识库同步")
    args, passthrough = parser.parse_known_args(argv)

    profile = load_profile(args.profile)
    source = get_source_config(profile, args.source)
    if not source.get("ingest_script"):
        raise SystemExit(f"profile {args.profile} 缺少 {args.source} ingest_script 配置")

    scheduled_args = []
    if args.scheduled and not args.inputs and not has_any_flag(
        passthrough,
        "--sync-latest",
        "--sync-incremental",
        "--sync-recent",
        "--sync-date",
        "--sync-month",
        "--sync-oldest",
    ):
        scheduled_args = build_scheduled_args(args.profile)

    command: list[str] = ["node", str(source["ingest_script"])]
    command.extend(args.inputs)
    command.extend(scheduled_args)
    command.extend(passthrough)

    append_flag(command, "--doc-token", profile["feishu"].get("doc_token") or "")
    append_flag(command, "--bitable-app-token", profile["feishu"].get("bitable_app_token") or "")
    append_flag(command, "--bitable-table-id", profile["feishu"].get("bitable_table_id") or "")
    append_flag(command, "--backup-dir", str(source.get("working_backup_root") or ""))
    append_flag(command, "--checkpoint", str(source.get("checkpoint_path") or ""))
    append_flag(command, "--index-log", str(source.get("index_log_path") or ""))
    append_flag(command, "--douyin-storage-state", str(source.get("storage_state_path") or ""))

    env = os.environ.copy()
    if source.get("dictionary_path"):
        env["DOUYIN_TEXT_CORRECTIONS_PATH"] = str(source["dictionary_path"])

    result_code = 0
    if not args.sync_only:
        completed = subprocess.run(command, env=env, check=False)
        result_code = int(completed.returncode or 0)
        if result_code != 0:
            return result_code

    sync_result = sync_source_records(
        profile,
        str(source.get("name") or args.source),
        include_legacy=args.import_legacy,
    )
    print(
        json.dumps(
            {
                "profile": profile["name"],
                "source": source["name"],
                "command": command if not args.sync_only else [],
                "sync": sync_result,
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

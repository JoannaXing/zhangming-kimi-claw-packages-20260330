# douyin-transcribe-to-feishu

抖音视频语音转写并标准化输出到飞书文档 / 多维表格的处理管道。

## 这次改了什么

- 支持 `--limit` 控制本批处理数量
- 支持 `--batch videos.txt` 批量输入
- 支持 `douyin.com` 主站登录态深分页发现
- 支持标准化同步模式入口
- 增加 checkpoint（处理中断后可定位问题）
- checkpoint 改为按写入目标感知，切换客户文档/表格时不会误跳过
- ASR 改为 JSON 输出，主流程可识别失败原因
- 预留 `turbo_2_0 -> streaming_1_0` fallback 结构
- ASR 成功后本地持久化备份转写与格式化产物
- 文档输出按既有飞书格式标准化
- 表格字段输出按固定 Bitable 字段标准化
- 增加成功写入后的本地 `jsonl` 索引日志
- 飞书文档 / 表格目标支持 `命令行 > 环境变量 > runtime.toml`

## 默认目标

- 文档：`AKKHw9M1DiY83LkK1ohcNtMDn7b`
- Bitable App：`QdSlbWIV4aLHaqswxh5cg0RLnKf`
- Bitable Table：`tbl8j1Qj6V9K0HPz`

## 用法

### 单条

```bash
node douyin-transcribe-to-feishu.js "https://www.douyin.com/video/7618945910454770899"
```

### 批量

```bash
node douyin-transcribe-to-feishu.js --batch videos.txt --limit 5
```

### 仅生成标准化结果（不真正写飞书）

```bash
node douyin-transcribe-to-feishu.js --batch videos.txt --limit 3 --dry-run
```

### 账号级同步

```bash
node douyin-transcribe-to-feishu.js --sync-latest
node douyin-transcribe-to-feishu.js --sync-incremental
node douyin-transcribe-to-feishu.js --sync-recent 3
node douyin-transcribe-to-feishu.js --sync-date 2026-03-27
node douyin-transcribe-to-feishu.js --sync-month 2026-03
node douyin-transcribe-to-feishu.js --sync-oldest 20
node douyin-transcribe-to-feishu.js --sync-oldest 20 --skip-doc-write
node douyin-transcribe-to-feishu.js --backfill-doc-pending --limit 10
node douyin-transcribe-to-feishu.js --rewrite 7621183793445803435
node douyin-transcribe-to-feishu.js --reconcile-target
node douyin-transcribe-to-feishu.js --backfill-missing-backups
node douyin-transcribe-to-feishu.js --sync-latest --force-rewrite
node douyin-transcribe-to-feishu.js --sync-latest --doc-token xxx --bitable-app-token yyy --bitable-table-id zzz
node douyin-transcribe-to-feishu.js --sync-latest --index-log /tmp/customer-a-write-index.jsonl
node douyin-transcribe-to-feishu.js --sync-latest --backup-dir /tmp/customer-a-douyin-backups
node douyin-transcribe-to-feishu.js --sync-date 2026-03-03 --douyin-storage-state .state/douyin-storage-state.json
```

## 说明

当前主脚本现在会直接完成：

1. 抓取视频元数据
2. 提取发布时间
3. 下载视频并抽音频
4. 调用 ASR
5. 生成标准化文档片段
6. 生成标准化 Bitable 字段
7. 追加写入飞书文档
8. upsert 写入飞书 Bitable
9. 记录 checkpoint
10. 追加写入本地索引日志
11. 将 ASR 成功结果备份到本地固定目录

当前实现会优先复用 OpenClaw Feishu channel 的 app 凭证直接写回；
ASR 仅使用火山 openspeech。云端若命中服务端异常会先短重试，重试后仍失败则整条报错退出，不会再走本地 Whisper。

账号级同步当前固定使用 `config/runtime.toml` 里的 `account.sec_uid`。
主站深分页默认读取 `config/runtime.toml` 里的 `browser.douyin_storage_state_path`，也可用 `--douyin-storage-state` 或环境变量 `DOUYIN_STORAGE_STATE_PATH` 覆盖。

## 推荐批量流程

适合“先尽快补完 800+ 条多维表格，再慢慢补文档”的场景：

1. 先跑表格主链路：

```bash
node douyin-transcribe-to-feishu.js --sync-oldest 100 --skip-doc-write --douyin-storage-state .state/douyin-storage-state.json
```

2. 后续再补文档：

```bash
node douyin-transcribe-to-feishu.js --backfill-doc-pending --limit 20
```

说明：

- `--skip-doc-write` 主链路只做“抖音抓取 -> ASR -> 摘要 -> 多维表格写入 -> 本地备份 / checkpoint / checklist”
- `--backfill-doc-pending` 会直接复用本地备份补写飞书文档，不会重复抓取抖音、不会重复做 ASR
- `--sync-oldest N --skip-doc-write` 会优先跳过那些“表格已写、仅待补文档”的条目，继续往更早的未入表视频推进

## 飞书目标覆盖优先级

- 命令行：`--doc-token` `--bitable-app-token` `--bitable-table-id`
- 环境变量：`FEISHU_DOC_TOKEN` `FEISHU_BITABLE_APP_TOKEN` `FEISHU_BITABLE_TABLE_ID`
- 默认配置：`config/runtime.toml`

这意味着后续交付客户时，不需要改代码，只要切换目标 token 即可。

## 索引日志

- 默认索引日志路径：`/tmp/douyin-transcribe-checkpoints/write-index.jsonl`
- 可通过 `--index-log` 或环境变量 `FEISHU_WRITE_INDEX_LOG` 覆盖
- 每次成功写入会追加一条 JSON，包含：
  - `publishDate`
  - `publishTime`
  - `videoId`
  - `title`
  - `topic`
  - `docSequence`
  - `docAction`
  - `bitableAction`
  - `bitableRecordId`
  - `backupPath`
  - `target.docToken`
  - `target.bitableAppToken`
  - `target.bitableTableId`
  - `checkpointPath`

## 本地备份

- 默认备份目录：`./.local-backups`
- 可通过 `--backup-dir`、`DOUYIN_BACKUP_DIR` 或 `DOUYIN_TRANSCRIBE_BACKUP_DIR` 覆盖
- 只要 ASR 成功，就会立即落盘；即使后续飞书写入失败，文本也会保留
- 备份目录会按“文档/表格目标 + 视频ID”分层，切换客户目标时不会互相覆盖
- 每条视频会生成独立目录，根目录保留当前 canonical 版本，同时每次运行都会额外写入 `runs/<时间戳>_<模型>/` 快照，避免低质量 fallback 覆盖之前的较优结果
- 根目录额外会记录 `latest-run.json` 与 `canonical-run.json`，分别指向最近一次运行和当前 canonical 来源
- 每个写入目标根目录还会持续维护一个 `catalog.json`，记录该文档/表格目标下当前已接管的视频目录清单，按发布时间逆序排列
- 同一目标根目录还会维护 `timeline-checklist.json`，按发布时间正序记录“已完成 / 未完成 / 仅文档 / 仅表格 / 失败”等状态，避免后续每次都回抖音网页重新翻时间线
- 同一目标根目录还会维护 `dedupe-index.json`，基于“转写正文 + 时长”识别重复内容；重复视频会保留本地备份，但会标记 `duplicate_skipped`
- 后续脚本成功写入或保持原样时，会同步更新 `write-index.jsonl` 与对应目标下的 `catalog.json`
- `--sync-oldest N` 会优先消费本地 `timeline-checklist.json` 中最早的未完成项；只有 checklist 还没覆盖完整账号时间线时，才会回到 douyin.com 做一次完整扫描
- `--reconcile-target` 会扫描当前飞书文档与多维表格，把已存在内容接管到本地 `checkpoint / write-index / catalog`
- 对账时若找到同视频的历史本地备份，会自动复制到当前目标目录；若飞书里已有内容但本地没有原始产物，则会先记入 `catalog.json`，但无法直接重写正文
- `--backfill-missing-backups` 会针对当前目标里“已接管但缺本地备份”的条目，重新抓取并转写，同时把文档区块与多维表格刷新到当前最新模板
- `meta.json` 会补充 `asrAttempts / asrFallbackUsed / asrPrimaryError`，方便排查云端 ASR 失败原因
- `config/text-corrections.json` 可维护账号级专名纠错词典，当前已内置 `张老师 -> 章老师`、`张敏 -> 章明`、`张明 -> 章明`、`张行长 -> 章行长`
- canonical 根目录默认包含：
  - `record.json`
  - `transcript.txt`
  - `doc.md`
  - `bitable-fields.json`
  - `doc-sections.json`
  - `meta.json`
- `meta.json` 会补充 `dedupeStatus / canonicalVideoId / duplicateOfVideoId / contentFingerprint`

## Checkpoint 行为

- checkpoint 现在会同时记录视频写入目标签名。
- 只有“同一个视频 + 同一个文档/表格目标”才会因为 checkpoint 被跳过。
- 如果后续切到客户自己的飞书文档或多维表格，不会因为你本地旧 checkpoint 而误判“已写入”。

## 默认重写策略

- 默认不会重写已存在内容。
- 如果当前目标里已经同时存在该视频的文档区块和多维表格记录，脚本会直接提示“已存在，保持原样”，不做替换。
- 只有显式传入 `--force-rewrite` 或 `--rewrite`，才会执行替换写入。

## 内容去重策略

- 当前除了 `videoId` 去重，还会在本地备份层增加“内容级去重”。
- 规则基于“转写正文高相似度 + 时长一致”；默认保留最早发布的那条作为 canonical。
- 命中重复时：
  - 保留该视频的本地备份
  - 不再写入飞书多维表格
  - 不再补写飞书文档
  - 在 checkpoint / checklist / 本地 `meta.json` 中标记 `duplicate_skipped`
- 这样即使抖音时间线里出现“不同视频ID但正文几乎一样”的重复发布，后续知识库也不会重复入库。

## 飞书限频策略

- 飞书文档写入默认最多尝试 2 次。
- 如果命中飞书 `99991400 request trigger frequency limit`，脚本会直接明确报错“飞书写入限频，请稍后再试”。
- 不会为了限频问题长时间持续重试。
- 默认摘要模式为 `pre_write`，单条新增视频会先本地生成完整区块，再尽量用 1 次文档写入落地。
- 重写已有视频时仍需要“先写新块，再删旧块”，因此文档侧通常至少 2 次操作。
- 历史回填模式（如 `--sync-oldest` / `--sync-date` / `--sync-month` / `--sync-recent N`）会改成“转写一条、表格一条、文档批量写入”。
- 如果显式传入 `--skip-doc-write`，历史回填会进一步改成“转写一条、表格一条”，文档全部留到后续 `--backfill-doc-pending`。
- 文档写入会先走本地主动节流，再按批次 flush，默认批次 `10` 条、批次间最小间隔 `8` 秒。
- 文档插入位置会优先参考本地 `write-index.jsonl` 和 checkpoint 的已知时间边界，只有无法判断时才回退到飞书文档扫描。

## ASR 策略

- 默认主模型仍为火山录音文件识别大模型 2.0 极速版 `turbo_2_0`。
- 命中 `55000000 / 21109` 这类服务端内部错误时，会做短重试，默认 `2` 次、间隔 `3` 秒。
- 短重试后仍失败，则整条任务直接失败，不写飞书文档、不写多维表格。
- 本地 `mlx-whisper` fallback 已移除，避免低质量文本混进正式知识库。

## 摘要模型

- 默认摘要提供方为 `auto`：优先火山方舟 Ark，拿不到 key 或 Ark 连续失败时自动回退 `openclaw agent`。
- 当前默认模型为 `doubao-seed-2-0-lite-260215`。
- 调用方式为 Ark `chat/completions`，并显式传 `thinking.type=disabled`，避免推理内容干扰 JSON 摘要解析。
- 推荐提供环境变量 `ARK_API_KEY`，这样摘要更快；也可通过 `ARK_SUMMARY_MODEL` / `ARK_BASE_URL` 覆盖默认模型与地址。
- 如果调度器环境拿不到 `ARK_API_KEY`，可把它写到 `.state/daily-sync.env`；runner 会自动加载，且该文件默认不进 git。
- 如需临时切回旧链路，可设置 `SUMMARY_PROVIDER=openclaw`。

## 排序规则

- 飞书文档与多维表格统一按“抖音发布时间（UTC+8）逆序”处理，新视频排前面，旧视频排后面。
- 文档插入位置继续按发布时间逆序计算。
- 多维表格里的 `发布日期` 现在按秒级时间戳写入，不再只保留到分钟。
- 飞书多维表格界面的默认显示顺序，仍需要在当前视图里手动设置一次：
  - 字段：`发布日期`
  - 方向：`降序`
- 公开 API 目前没有稳定的视图排序配置能力，所以脚本不会假装已经自动改好视图排序。

## 表格字段兼容

- 多维表格写入已改成字段别名解析，不再死依赖单一中文字段名。
- 当前逻辑字段已拆分为：
  - `标签`：仅写抖音原始显式话题标签，读不到就留空
  - `主题`：摘要阶段由 LLM 提炼的简短主题
- 兼容层仍允许旧表头 `标签/主题` 继续承接 `标签` 字段，避免历史表立即写坏。
- `主题（AI提取）` / `主题(AI提取)` 会被视为 `主题`。
- `核心要点（AI提取）` / `核心要点(AI提取)` 会被视为 `核心要点`。
- 若当前目标表还没有单独的 `主题` 列，脚本会先跳过该字段写入；建议尽快在多维表格中补一列 `主题`。

## 历史表格字段回填

- 如果你新增了 `主题` 列，或者调整了相关表头，可直接运行：

```bash
node douyin-transcribe-to-feishu.js --backfill-bitable-fields
```

- 这条命令会复用本地 `record.json`，刷新 `bitable-fields.json / doc-sections.json / doc.md`，并回填当前目标下的历史多维表格记录。
- 不会重新抓抖音，不会重新做 ASR，也不会写飞书文档。

## 当前账号级同步能力

- `--sync-latest`
- `--sync-incremental`
- `--sync-recent N`
- `--sync-date YYYY-MM-DD`
- `--sync-month YYYY-MM`
- `--sync-oldest N`
- `--rewrite <视频链接或视频ID>`
- `--force-rewrite`
- `--backfill-bitable-fields`

## 当前账号级限制

- 严格日期/月份/最早补录依赖 `douyin.com` 主站登录态深分页。
- 如果没有可用的登录态文件，脚本只能退回账号首屏发现，无法对更旧日期做严格保证。
- 当前主站深分页会在达到目标边界后主动停止，不再使用“已入库记录 + 实时补拉详情”去反推最新或反推旧数据。

## 当前文档规则

- 当前只保留 H3 标题，不追加编号。
- 文档 H3 统一使用 `日期 + #主题`。
- 例如：`2026-03-25 #面试准备`。
- 如果摘要阶段暂时没有可用主题，则 H3 只保留日期。
- 原始标签不再参与 H3 生成，也不再做 `#人生感悟 #认知提升` 之类的前缀过滤。
- 多维表格中的 `标签` 与 `主题` 现已拆分：
  - `标签` 仅保存抖音原始显式标签
  - `主题` 统一保存 LLM 提炼主题
- 文档中的摘要小标题统一使用 `核心要点`。

## 当前转写分段规则

- 先保留原始空行分段。
- 不按字数切段。
- 不按标点符号主动切段。
- 只在出现结构词时开启新段，当前使用：
  - `首先` `其次` `再次` `最后`
  - `第一` `第二` `第三` `第四` `第五`
  - `第一点` `第二点` `第三点` `第四点` `第五点`
  - `总结一下` `所以` `举个例子` `换个角度`
- 如果整段文本里没有这些结构词，就保持单段输出。

# 飞书写回闭环设计

当前 skill 已完成本地处理管道：
- 抖音抓取
- 发布时间提取与标准化
- 音频提取
- ASR 转写
- 文档内容标准化
- Bitable 字段标准化
- checkpoint 记录

## 剩余闭环

由于本地 Node/Python 脚本无法直接调用 OpenClaw 会话内工具，真实写回飞书需要宿主层接管：

1. 文档写入：`feishu_doc append`
2. 表格写入：
   - 先 `feishu_bitable_list_records` 查询是否已有相同“视频ID:”
   - 有则 `feishu_bitable_update_record`
   - 无则 `feishu_bitable_create_record`

## 建议宿主执行顺序

对每条记录：

1. 运行 skill，生成 record JSON / 标准化 markdown / 字段映射
2. `feishu_doc append` 追加文档块
3. 根据 `视频ID:` upsert 到 Bitable
4. 成功后 checkpoint 状态改成 `written`
5. 失败则记录具体 stage 与错误信息

## 状态设计

- `downloaded`
- `transcribed`
- `formatted`
- `doc_written`
- `bitable_written`
- `written`
- `failed`

## 备注

下一步建议直接把这层宿主回写逻辑做成：
- OpenClaw skill wrapper
- 或独立 session 内 orchestrator

#!/usr/bin/env python3
"""
ASR 转写模块。

策略：
1. 若提供 VOLC_APP_ID + VOLC_ACCESS_TOKEN，则尝试火山 openspeech。
2. 云端 ASR 若命中可重试错误，会先短重试。
3. 默认不再自动回落到本地 mlx-whisper，避免低质量文本混入正式文档。
"""
import base64
import json
import os
import re
import sys
import time
import uuid
from pathlib import Path
from time import perf_counter

import requests
import toml

CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "runtime.toml"
CONFIG = toml.loads(CONFIG_PATH.read_text(encoding="utf-8"))
os.environ.setdefault("HF_HUB_DISABLE_PROGRESS_BARS", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")
ASR_CONFIG = CONFIG.get("asr", {})
CLOUD_RETRY_ATTEMPTS = max(1, int(ASR_CONFIG.get("cloud_retry_attempts", 2)))
CLOUD_RETRY_DELAY_SECONDS = max(0.0, float(ASR_CONFIG.get("cloud_retry_delay_seconds", 3)))


def load_shell_exports():
    keys = ("VOLC_APP_ID", "VOLC_ACCESS_TOKEN")
    if all(os.environ.get(key) for key in keys):
        return

    candidates = [
        Path.home() / ".zshenv",
        Path.home() / ".zprofile",
        Path.home() / ".zshrc",
        Path.home() / ".bash_profile",
        Path.home() / ".bashrc",
    ]
    pattern = re.compile(r"^\s*export\s+(VOLC_APP_ID|VOLC_ACCESS_TOKEN)\s*=\s*(.+?)\s*$")

    for file_path in candidates:
        if not file_path.exists():
            continue
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception:
            continue
        for raw_line in content.splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            match = pattern.match(line)
            if not match:
                continue
            key, value = match.groups()
            value = value.strip().strip("'").strip('"')
            if value and not os.environ.get(key):
                os.environ[key] = value


load_shell_exports()


def build_headers(app_id: str, access_token: str, resource_id: str):
    return {
        "X-Api-App-Key": app_id,
        "X-Api-Access-Key": access_token,
        "X-Api-Resource-Id": resource_id,
        "X-Api-Request-Id": str(uuid.uuid4()),
        "X-Api-Sequence": "-1",
        "Content-Type": "application/json",
    }


def read_audio_bytes(audio_path: str):
    p = Path(audio_path)
    if not p.exists():
        raise FileNotFoundError(f"音频文件不存在: {audio_path}")
    return p.read_bytes()


def is_retryable_cloud_error(error_text: str):
    text = str(error_text or "").lower()
    return any(
        token in text
        for token in (
            "http 请求异常",
            "http 429",
            "http 500",
            "http 502",
            "http 503",
            "http 504",
            "55000000",
            "55000031",
            "21109",
            "internal error",
            "server busy",
            "服务器繁忙",
            "timeout",
            "timed out",
        )
    )


def asr_http_flash(audio_path: str, model_key: str):
    model = CONFIG["models"][model_key]
    audio_bytes = read_audio_bytes(audio_path)
    app_id = os.environ.get("VOLC_APP_ID")
    access_token = os.environ.get("VOLC_ACCESS_TOKEN")
    if not app_id or not access_token:
        return {"success": False, "error": "缺少 VOLC_APP_ID 或 VOLC_ACCESS_TOKEN", "model": model_key}

    audio = base64.b64encode(audio_bytes).decode("utf-8")
    headers = build_headers(app_id, access_token, model["resource_id"])
    payload = {
        "user": {"uid": app_id},
        "audio": {"data": audio},
        "request": {
            "model_name": model.get("model_name", "bigmodel"),
            "enable_itn": True,
            "enable_punc": True,
        },
    }
    t0 = perf_counter()
    try:
        resp = requests.post(model["api_endpoint"], headers=headers, json=payload, timeout=180)
    except Exception as exc:
        return {"success": False, "error": f"HTTP 请求异常: {exc}", "model": model_key}
    elapsed = perf_counter() - t0
    if resp.status_code != 200:
        return {
            "success": False,
            "error": f"HTTP {resp.status_code}: {resp.text[:300]}",
            "model": model_key,
            "elapsed_sec": elapsed,
        }
    status_code = resp.headers.get("X-Api-Status-Code", "")
    if status_code != "20000000":
        return {
            "success": False,
            "error": f"ASR 状态异常: {status_code} {resp.headers.get('X-Api-Message', '')}",
            "model": model_key,
            "elapsed_sec": elapsed,
        }
    data = resp.json()
    text = data.get("result", {}).get("text", "").strip()
    if not text:
        return {"success": False, "error": "ASR 返回空文本", "model": model_key, "elapsed_sec": elapsed}
    return {"success": True, "text": text, "model": model_key, "elapsed_sec": elapsed}


def try_cloud_asr_with_retry(audio_path: str, model_key: str):
    attempts = []
    for index in range(CLOUD_RETRY_ATTEMPTS):
        result = asr_http_flash(audio_path, model_key)
        attempts.append(dict(result))
        if result.get("success"):
            output = dict(result)
            output["attempts"] = attempts
            output["asr_duration"] = f"约 {max(1, round(result.get('elapsed_sec', 0)))} 秒"
            return output
        if index >= CLOUD_RETRY_ATTEMPTS - 1:
            break
        if not is_retryable_cloud_error(result.get("error", "")):
            break
        time.sleep(CLOUD_RETRY_DELAY_SECONDS)
    return {"success": False, "attempts": attempts}


def transcribe(audio_path: str, primary: str = None):
    read_audio_bytes(audio_path)
    primary = primary or CONFIG["asr"]["primary_model"]
    attempts = []

    cloud_enabled = (
        primary == "turbo_2_0"
        and os.environ.get("VOLC_APP_ID")
        and os.environ.get("VOLC_ACCESS_TOKEN")
    )
    if cloud_enabled:
        cloud_result = try_cloud_asr_with_retry(audio_path, primary)
        attempts.extend(cloud_result.get("attempts", []))
        if cloud_result.get("success"):
            return cloud_result
        result = {
            "success": False,
            "error": " ; ".join([a.get("error", "未知错误") for a in attempts]),
            "model": primary,
        }
        attempts.append(dict(result))
        return {
            "success": False,
            "error": " ; ".join([a.get("error", "未知错误") for a in attempts]),
            "attempts": attempts,
        }

    result = {
        "success": False,
        "error": "未配置可用的云端 ASR 凭证 VOLC_APP_ID / VOLC_ACCESS_TOKEN",
        "model": primary,
    }
    attempts.append(dict(result))

    return {
        "success": False,
        "error": " ; ".join([a.get("error", "未知错误") for a in attempts]),
        "attempts": attempts,
    }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({"success": False, "error": "用法: python3 transcribe.py <audio_file.wav>"}, ensure_ascii=False))
        sys.exit(1)

    try:
        result = transcribe(sys.argv[1])
    except Exception as exc:
        result = {"success": False, "error": str(exc)}
    print(json.dumps(result, ensure_ascii=False))
    if not result.get("success"):
        sys.exit(1)

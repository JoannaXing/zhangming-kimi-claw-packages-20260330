#!/bin/zsh

set -u

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR" || exit 1

LOG="${LOG:-$ROOT_DIR/logs/backfill-doc-all-watchdog-$(date +%Y%m%d-%H%M%S).log}"
POLL_SECONDS="${POLL_SECONDS:-30}"
STALL_SECONDS="${STALL_SECONDS:-180}"
MAX_DOC_WRITE_SECONDS="${MAX_DOC_WRITE_SECONDS:-300}"
START_AFTER_VIDEO_ID="${START_AFTER_VIDEO_ID:-}"
DOC_TOKEN="${DOC_TOKEN:-}"
BATCH_FILE="${BATCH_FILE:-}"

mkdir -p "$(dirname "$LOG")"

log_watchdog() {
  printf '[watchdog][%s] %s\n' "$(date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$LOG"
}

last_completed_id() {
  node -e "const fs=require('fs'); const p=process.argv[1]; if(!fs.existsSync(p)){process.exit(0);} const lines=fs.readFileSync(p,'utf8').split(/\n/); let last=''; const re=/\[\d+\/\d+\]\[(\d+)\]\s+文档回填完成/; for(const line of lines){const m=line.match(re); if(m) last=m[1];} if(last) process.stdout.write(last);" "$LOG"
}

current_doc_write_state() {
  node -e "const fs=require('fs'); const p=process.argv[1]; if(!fs.existsSync(p)){process.stdout.write('\t0'); process.exit(0);} const lines=fs.readFileSync(p,'utf8').trim().split(/\n/).slice(-60); const last=lines[lines.length-1]||''; const m=last.match(/\[\d+\/\d+\]\[(\d+)\].*写入飞书文档进行中，已耗时\s+(.+)$/); function parseElapsed(text){let sec=0; const min=text.match(/(\d+)\s*分/); if(min) sec += Number(min[1]) * 60; const secMatch=text.match(/(\d+)\s*秒/); if(secMatch) sec += Number(secMatch[1]); return sec;} if(!m){process.stdout.write('\t0'); process.exit(0);} process.stdout.write(String(m[1]) + '\t' + String(parseElapsed(m[2])));" "$LOG"
}

stop_child() {
  local pid="$1"
  kill -TERM "$pid" 2>/dev/null || true
  sleep 5
  if kill -0 "$pid" 2>/dev/null; then
    kill -KILL "$pid" 2>/dev/null || true
  fi
  wait "$pid" 2>/dev/null || true
}

attempt=0
resume_after="$START_AFTER_VIDEO_ID"

log_watchdog "log: $LOG"
log_watchdog "poll=${POLL_SECONDS}s stall=${STALL_SECONDS}s max_doc_write=${MAX_DOC_WRITE_SECONDS}s"
if [[ -n "$DOC_TOKEN" ]]; then
  log_watchdog "doc_token=$DOC_TOKEN"
fi
if [[ -n "$BATCH_FILE" ]]; then
  log_watchdog "batch_file=$BATCH_FILE"
fi

while true; do
  if [[ -z "$resume_after" ]]; then
    resume_after="$(last_completed_id)"
  fi

  cmd=(node douyin-transcribe-to-feishu.js --backfill-doc-all)
  if [[ -n "$resume_after" ]]; then
    cmd+=(--start-after-video-id "$resume_after")
  fi
  if [[ -n "$DOC_TOKEN" ]]; then
    cmd+=(--doc-token "$DOC_TOKEN")
  fi
  if [[ -n "$BATCH_FILE" ]]; then
    cmd+=(--batch "$BATCH_FILE")
  fi

  attempt=$((attempt + 1))
  log_watchdog "attempt=$attempt start_after=${resume_after:-<none>} doc_token=${DOC_TOKEN:-<default>} batch_file=${BATCH_FILE:-<none>}"

  "${cmd[@]}" >> "$LOG" 2>&1 &
  pid=$!
  restarted=0

  while kill -0 "$pid" 2>/dev/null; do
    sleep "$POLL_SECONDS"

    now_epoch="$(date +%s)"
    log_mtime="$(stat -f %m "$LOG" 2>/dev/null || echo "$now_epoch")"
    log_age="$((now_epoch - log_mtime))"
    if [[ "$log_age" -ge "$STALL_SECONDS" ]]; then
      log_watchdog "no log update for ${log_age}s, restarting pid=$pid"
      stop_child "$pid"
      restarted=1
      break
    fi

    state="$(current_doc_write_state)"
    current_video="${state%%$'\t'*}"
    current_elapsed="${state#*$'\t'}"
    if [[ -n "$current_video" && "$current_elapsed" -ge "$MAX_DOC_WRITE_SECONDS" ]]; then
      log_watchdog "doc write exceeded ${MAX_DOC_WRITE_SECONDS}s for video=${current_video}, restarting pid=$pid"
      stop_child "$pid"
      restarted=1
      break
    fi
  done

  resume_after="$(last_completed_id)"

  if [[ "$restarted" -eq 1 ]]; then
    sleep 5
    continue
  fi

  wait "$pid"
  status="$?"
  if [[ "$status" -eq 0 ]]; then
    log_watchdog "completed successfully last_completed=${resume_after:-<none>}"
    break
  fi

  log_watchdog "process exited status=${status}, restarting after ${resume_after:-<none>}"
  sleep 5
done

echo "$LOG"

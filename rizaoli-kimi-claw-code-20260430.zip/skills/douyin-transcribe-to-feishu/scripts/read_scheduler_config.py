#!/usr/bin/env python3
from __future__ import annotations

import argparse
import shlex
from pathlib import Path

try:
    import tomllib  # type: ignore[attr-defined]
except ModuleNotFoundError:
    tomllib = None


def parse_toml_simple(content: str) -> dict:
    data: dict = {}
    current = data
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "#" in line:
            line = line.split("#", 1)[0].rstrip()
        if not line:
            continue
        if line.startswith("[") and line.endswith("]"):
            current = data
            section = line[1:-1].strip()
            for part in section.split("."):
                current = current.setdefault(part, {})
            continue
        if "=" not in line:
            continue
        key, value = [segment.strip() for segment in line.split("=", 1)]
        if not key:
            continue
        if value.startswith('"') and value.endswith('"'):
            parsed = value[1:-1]
        elif value.lower() in {"true", "false"}:
            parsed = value.lower() == "true"
        else:
            try:
                parsed = int(value)
            except ValueError:
                try:
                    parsed = float(value)
                except ValueError:
                    parsed = value
        current[key] = parsed
    return data


def load_runtime_toml(runtime_path: Path) -> dict:
    if tomllib is not None:
        with runtime_path.open("rb") as handle:
            return tomllib.load(handle)
    return parse_toml_simple(runtime_path.read_text(encoding="utf-8"))


def resolve_path(skill_dir: Path, value: str, fallback: str) -> str:
    candidate = str(value or fallback or "").strip()
    if not candidate:
        return ""
    path = Path(candidate).expanduser()
    if not path.is_absolute():
        path = (skill_dir / candidate).resolve()
    return str(path)


def load_config(skill_dir: Path) -> dict[str, str]:
    runtime_path = skill_dir / "config" / "runtime.toml"
    runtime = load_runtime_toml(runtime_path)

    run_cfg = runtime.get("run") or {}
    logging_cfg = runtime.get("logging") or {}
    backup_cfg = runtime.get("backup") or {}
    browser_cfg = runtime.get("browser") or {}
    scheduler_cfg = runtime.get("scheduler") or {}

    state_dir = resolve_path(skill_dir, ".state", ".state")
    checkpoint_dir = resolve_path(skill_dir, str(run_cfg.get("checkpoint_dir") or ""), ".state/checkpoints")
    checkpoint_file = str(run_cfg.get("checkpoint_file") or "douyin-transcribe-to-feishu.json").strip() or "douyin-transcribe-to-feishu.json"
    checkpoint_path = str((Path(checkpoint_dir) / checkpoint_file).resolve())

    values = {
        "skill_dir": str(skill_dir),
        "runtime_config_path": str(runtime_path),
        "state_dir": state_dir,
        "checkpoint_dir": checkpoint_dir,
        "checkpoint_path": checkpoint_path,
        "index_log_path": resolve_path(skill_dir, str(logging_cfg.get("index_log_path") or ""), ".state/checkpoints/write-index.jsonl"),
        "backup_dir": resolve_path(skill_dir, str(backup_cfg.get("output_dir") or ""), ".local-backups"),
        "douyin_storage_state_path": resolve_path(skill_dir, str(browser_cfg.get("douyin_storage_state_path") or ""), ".state/douyin-storage-state.json"),
        "scheduler_enabled": "true" if str(scheduler_cfg.get("enabled") or "").strip().lower() in {"1", "true", "yes", "on"} else "false",
        "scheduler_hour": str(int(scheduler_cfg.get("hour", 2))),
        "scheduler_minute": str(int(scheduler_cfg.get("minute", 10))),
        "scheduler_sync_mode": str(scheduler_cfg.get("sync_mode") or "incremental").strip() or "incremental",
        "scheduler_recent_count": str(int(scheduler_cfg.get("recent_count") or 10)),
        "scheduler_log_dir": resolve_path(skill_dir, str(scheduler_cfg.get("log_dir") or ""), ".state/logs/scheduler"),
        "scheduler_lock_file": resolve_path(skill_dir, str(scheduler_cfg.get("lock_file") or ""), ".state/locks/douyin-daily-sync.lock"),
        "scheduler_env_file": resolve_path(skill_dir, str(scheduler_cfg.get("env_file") or ""), ".state/daily-sync.env"),
        "scheduler_macos_label": str(scheduler_cfg.get("macos_label") or "com.openclaw.douyin-transcribe.daily").strip() or "com.openclaw.douyin-transcribe.daily",
        "scheduler_linux_service_name": str(scheduler_cfg.get("linux_service_name") or "openclaw-douyin-transcribe-daily").strip() or "openclaw-douyin-transcribe-daily",
        "scheduler_engagement_refresh_enabled": "true"
        if str(scheduler_cfg.get("engagement_refresh_enabled") or "")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"}
        else "false",
        "scheduler_engagement_refresh_days": str(int(scheduler_cfg.get("engagement_refresh_days") or 7)),
        "scheduler_engagement_refresh_max_videos": str(
            int(scheduler_cfg.get("engagement_refresh_max_videos") or 0),
        ),
        "scheduler_openclaw_notify_enabled": "true"
        if str(scheduler_cfg.get("openclaw_notify_enabled") or "")
        .strip()
        .lower()
        in {"1", "true", "yes", "on"}
        else "false",
        "scheduler_openclaw_notify_channel": str(scheduler_cfg.get("openclaw_notify_channel") or "feishu").strip()
        or "feishu",
        "scheduler_openclaw_notify_target": str(scheduler_cfg.get("openclaw_notify_target") or "").strip(),
    }
    return values


def main() -> int:
    parser = argparse.ArgumentParser(description="Print resolved douyin scheduler config.")
    parser.add_argument("--format", choices=["env"], default="env")
    args = parser.parse_args()

    skill_dir = Path(__file__).resolve().parents[1]
    values = load_config(skill_dir)
    if args.format == "env":
        for key in sorted(values):
            print(f"{key}={shlex.quote(values[key])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

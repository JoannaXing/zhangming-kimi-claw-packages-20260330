---
name: knowledge-writer
description: 基于视频知识库检索结果生成 grounded 文章
metadata:
  openclaw:
    emoji: ✍️
---

# knowledge-writer

基于本地视频知识库备份，先检索命中素材，再生成 grounded 中文文章。

## 功能

- 🔎 复用 `video-knowledge-query` 做知识库检索
- 📚 自动加载命中视频的 `record.json`，带上要点、片段、全文摘录
- ✍️ 用 LLM 生成 grounded 文章，只允许基于命中证据写
- 🗣️ 默认沿用视频知识库口吻；只有显式指定时才切换风格
- 🧾 默认在文末追加 `原文定位`
- 🎯 支持 `--profile` 指定目标知识库，避免多知识库串库

## 环境变量

- 当前 runtime 默认走 `openclaw`
- 若显式切到 `ark`，运行环境需要提供 `ARK_API_KEY`
- 可用 `KNOWLEDGE_WRITER_PROVIDER=auto|ark|openclaw` 切默认生成链路
- 可用 `KNOWLEDGE_WRITER_PROFILE=<name>` 或 `VIDEO_KNOWLEDGE_PROFILE=<name>` 锁定知识库 profile
- 如 `openclaw` 可执行文件不在 PATH，可通过 `OPENCLAW_BIN` 或 `OPENCLAW_CLI_BIN` 指向具体路径
- 可用 `KNOWLEDGE_WRITER_OUTPUT_DIR` 覆盖默认输出目录

## 使用方法

### 生成主题文章

```bash
# 用主题词直接生成
python3 knowledge_writer.py "创业" --words 800

# 用完整写作要求生成，脚本会自动抽取检索主题
python3 knowledge_writer.py "以我的口吻，写一篇200字关于高尔夫的文章，要求有观点、有案例、有金句"
python3 knowledge_writer.py "教育" --profile zhangming --words 800

# 显式覆盖口吻
python3 knowledge_writer.py "管理" --words 600 --voice "更像公众号短评，克制一点"

# 强制走 Ark / OpenClaw
python3 knowledge_writer.py "教育" --provider ark --json
python3 knowledge_writer.py "教育" --provider openclaw --json
KNOWLEDGE_WRITER_PROVIDER=openclaw python3 knowledge_writer.py "教育" --json

# 调试 JSON 输出
python3 knowledge_writer.py "教育" --top 6 --json
```

## Provider 切换

- 支持 `--provider auto|ark|openclaw`
- 覆盖优先级：`命令行 > KNOWLEDGE_WRITER_PROVIDER > runtime.toml`
- 当前仓库默认 provider 为 `ark`，默认走豆包链路
- `auto`：若存在 `ARK_API_KEY` 则优先走 Ark，否则走 `openclaw agent`
- `openclaw` 表示走 skill 内部的嵌入式 `openclaw agent --agent main --local` 链路，不等于强绑定“当前聊天窗口正在用的那一个具体模型”
- 如果用户明确说“走豆包 / 走 Ark”，调用时必须带 `--provider ark`；如果用户明确说“走 OpenClaw”，调用时必须带 `--provider openclaw`

## 工作流程

1. **检索**：先走 `video-knowledge-query` 命中相关视频
2. **取证**：读取命中视频的 `record.json`，补全文摘录与证据片段
3. **生成**：把检索结果打包给模型，要求只能基于证据写作
4. **落盘**：输出 Markdown 到本地文件，默认保存在 skill 内 `.state/generated-articles/`

## 多知识库约束

- `knowledge-writer` 属于显式知识库写作工具，内部检索默认允许启用知识库，不要求你在请求里再写一次“基于视频知识库”
- 但如果你有多份知识库，仍然建议显式传 `--profile`，或先设置 `KNOWLEDGE_WRITER_PROFILE`
- 具体有哪些 profile，可用 `video-knowledge-query --list-profiles` 查看
- 该 skill 不需要定时器，但运行时同样要求 macOS / Linux 都能访问知识库备份目录

## 默认写作规则

1. 默认口吻不是另写一套 prompt，而是尽量贴近视频知识库本身的表达节奏
2. 正文至少包含明确观点、具体案例、收束金句
3. 如果证据不足，只写证据能支撑的部分，不做夸张延展
4. 默认在文章末尾追加 `原文定位`

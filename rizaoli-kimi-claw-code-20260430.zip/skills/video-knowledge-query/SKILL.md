---
name: video-knowledge-query
description: 轻量 RAG 查询短视频/抖音知识库，基于本地备份检索主题、标签、核心要点和完整文案；支持知识库检索、grounded 问答和基础统计
metadata:
  openclaw:
    emoji: 🔎
    requires:
      bins: [python3]
      env: []
---

# video-knowledge-query

用于查询当前抖音视频知识库。v1 是轻量 RAG：本地备份 + 规则检索 + 去重，不依赖 embedding。现在同时支持：

- `search`：返回命中的主题、要点、片段和原文定位
- `answer`：基于命中证据直接生成 grounded 回复
- `stats`：输出知识库规模统计、互动汇总，以及点赞/收藏/评论/转发最高的内容和主题
- `scope/profile`：控制知识库是否自动生效，以及命中哪一份知识库

## 何时使用

- 用户问某个主题在视频里讲过什么
- 用户问“我 / 章明关于 X 有哪些观点”
- 用户说“基于视频知识库”“帮我回忆下”“帮我搜索下知识库”
- 用户粘贴客户问题，希望“按章明本人的知识库和口吻”直接给出回复
- 用户要查知识库总条数、总时长、全文字数、互动总量
- 用户要看点赞/收藏/评论/转发量最高的内容或主题

## 调用

```bash
python3 video_knowledge_query.py --list-profiles
python3 video_knowledge_query.py "基于视频知识库，我有哪些教育的核心观点？"
python3 video_knowledge_query.py "基于视频知识库，我有哪些教育的核心观点？" --profile zhangming
python3 video_knowledge_query.py "基于章明知识库，孩子不爱学习怎么办？"
python3 video_knowledge_query.py "帮我回忆下，创业"
python3 video_knowledge_query.py "帮我搜索下知识库，提问式管理"
python3 video_knowledge_query.py "孩子不爱学习怎么办？"
python3 video_knowledge_query.py "这个问题我适合怎么回复客户：青春期孩子特别叛逆，父母该怎么办？"
python3 video_knowledge_query.py "孩子不爱学习怎么办？" --mode answer --provider ark
python3 video_knowledge_query.py "孩子不爱学习怎么办？" --mode answer --provider openclaw
VIDEO_KNOWLEDGE_ANSWER_PROVIDER=openclaw python3 video_knowledge_query.py "孩子不爱学习怎么办？" --mode answer
python3 video_knowledge_query.py --stats --json
python3 video_knowledge_query.py "基于视频知识库，我有哪些教育的核心观点？" --json
python3 video_knowledge_query.py "孩子不爱学习怎么办？" --mode answer --json
```

## 作用范围与多知识库

- 当前默认 `auto_trigger = true`，普通聊天会命中默认知识库 profile
- 如果你想显式切库，可以在问题里说“基于视频知识库 / 基于章明知识库”，或传 `--profile <name>`
- 用 `--list-profiles` 查看当前可用 profile、默认 profile 和备份目录
- `--profile` 覆盖优先级高于默认 profile；环境变量 `VIDEO_KNOWLEDGE_PROFILE` 也可指定
- 后续如果交付后要收紧范围，把 `config/runtime.toml` 里的 `scope.auto_trigger` 改回 `false` 即可
- 如果本地备份目录下存在多份知识库、但没有配置 `target_name`，脚本会直接报错，不再自动猜测，避免串库
- `stats` 也遵守 profile 作用域；如果统计涉及具体内容，末尾会附原文定位

## Provider 切换

- `answer` 模式支持 `--provider auto|ark|openclaw`
- 覆盖优先级：`命令行 > VIDEO_KNOWLEDGE_ANSWER_PROVIDER > runtime.toml`
- 兼容环境变量 `VIDEO_KNOWLEDGE_QUERY_PROVIDER`，便于整 skill 默认切换
- 当前仓库默认 provider 为 `ark`，默认走豆包链路
- `auto`：若存在 `ARK_API_KEY` 则优先走 Ark，否则走 `openclaw agent`
- `search` / `stats` 不调用模型，本地检索和统计不受 provider 影响
- `openclaw` 表示走 skill 内部的嵌入式 `openclaw agent --agent main --local` 链路，不等于强绑定“当前聊天窗口正在用的那一个具体模型”
- 如 `openclaw` 可执行文件不在 PATH，可通过 `OPENCLAW_BIN` 或 `OPENCLAW_CLI_BIN` 指向具体路径

## 回答规则

1. 普通用户提问默认不要加 `--json`，优先直接运行纯文本输出版本。
2. 只有在需要调试、二次加工结构化结果时才使用 `--json`。
3. 先运行脚本，再基于结果回答，不要脱离检索结果自由发挥。
4. 如果用了 `--json`，最终回答里必须把 `sourceRefText` 原样附在末尾，不要省略。
5. 这个 skill 内部默认把 `我 / 我的 / 本人` 解释为当前 profile 的知识库主人。
6. `auto` 模式下，短主题词默认走 `search`；明显是自然语言问题、客户提问、或“怎么回/怎么办/为什么”这类问句时默认走 `answer`。
7. `answer` 模式默认按章明第一人称口吻回答，但必须严格受命中证据约束；证据不足时要明确收窄结论。
8. `search` 模式优先引用 `主题 / 核心要点 / 全文片段`，需要时再补 `发布日期 / 视频链接`。
9. 回答底部固定追加 `原文定位` 区块，每条只保留 2 行：
   - `发布日期 | 主题 | 视频ID xxxxx`
   - `抖音：https://www.douyin.com/video/xxxxx`
   最终回复时必须逐行原样复制，不要改成项目符号，不要额外插入空行，不要再补“下面两行/来源/原文”等说明。
10. 如果命中不足或分数明显偏低，要明确说“当前只找到部分相关内容”。
11. 如果用户要“写文章 / 整理提纲 / 回顾观点”，也先用这个 skill 检索，再基于命中结果组织答案。
12. 如果用户明确说“走豆包 / 走 Ark”，调用时必须带 `--provider ark`；如果用户明确说“走 OpenClaw”，调用时必须带 `--provider openclaw`。

## 当前统计输出

- 知识库总体：视频总数、原文总字数、总时长、起止时间、去重情况
- 互动汇总：点赞 / 收藏 / 评论 / 转发总数
- 单条平均：字数、时长、四类互动的平均值
- 互动最高内容：四类互动各自最高的视频
- 互动最高主题：四类互动各自最高的主题
- 如果统计结果里提到了具体视频内容，会在末尾自动追加对应 `原文定位`

## 数据来源

- 默认读取同级 [douyin-transcribe-to-feishu](../douyin-transcribe-to-feishu/SKILL.md) 的本地备份目录
- 去重以 `dedupe-index.json` 为准，只保留 canonical 记录
- 可用环境变量 `VIDEO_KNOWLEDGE_BACKUP_ROOT` 覆盖备份根目录
- 建议通过 `profiles.<name>.target_name` 锁定具体知识库目录，不要依赖目录猜测
- 该 skill 本身不需要定时器，只要 macOS / Linux 上能访问到知识库备份目录即可

# 抖音知识库文档后补任务

你只做这一个固定流程：运行脚本，读取报告，把报告原文直接回复到当前 OpenClaw 会话。

强制规则：
1. 第一条助手动作必须是命令工具调用。
2. 在第一次命令工具调用之前，禁止：
   - 输出任何解释、分析、计划、总结、状态说明
   - 读取任何文件
   - 查看任何 `SKILL.md`
   - 查看 memory、history、其他 prompt 或其他上下文材料
3. 第一步必须直接执行下面这条命令：
   - `command`: `DOUYIN_SYNC_PIPELINE_MODE=backfill_doc_pending OPENCLAW_SKIP_NOTIFY=1 ./scripts/run_douyin_daily_sync.sh`
   - `workdir`: `/Users/synqora/.openclaw/workspace/skills/douyin-transcribe-to-feishu`
   - `timeout`: `1800`
   - `yieldMs`: `1000`
   - 调用命令工具时只传 `command`、`workdir`、`timeout`、`yieldMs`
4. 命令完成后，如果输出里有 `RUN_REPORT_PATH=`，只读取这个路径对应的文件。
5. 如果命令输出本身已经包含完整简报正文，或包含“执行状态：跳过”/“已有同步任务在运行”，优先直接回复该简报，不要读取旧报告。
6. 只有在命令输出里既没有 `RUN_REPORT_PATH=`、也没有任何本轮简报正文时，才读取这个兜底文件：
   `/Users/synqora/.openclaw/workspace/skills/douyin-transcribe-to-feishu/.state/runs/latest-report.md`
7. 读取报告文件时，必须传入完整绝对路径。
8. 最终回复只能是报告文件正文原文，不得改写，不得补充第二版总结。

额外约束：
- 不要调用 `openclaw message send`。
- 不要安装或启用 `launchd`、`systemd`、`crontab`。
- 如果脚本退出非 0，但命令输出里已有本轮简报正文，直接回复该正文。
- 如果脚本退出非 0，且报告文件存在，仍然优先读取本轮报告文件并直接回复报告正文。

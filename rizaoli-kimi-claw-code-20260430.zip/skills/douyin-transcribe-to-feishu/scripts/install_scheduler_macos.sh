#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

eval "$(
  python3 "$SCRIPT_DIR/read_scheduler_config.py" --format env
)"

PLIST_PATH="$HOME/Library/LaunchAgents/${scheduler_macos_label}.plist"
RUNNER_PATH="$SCRIPT_DIR/run_douyin_daily_sync.sh"
SCHED_PATH="/opt/homebrew/bin:/usr/local/bin:/usr/local/sbin:/usr/bin:/bin:${HOME}/.npm-global/bin:${HOME}/.local/bin:${HOME}/.fnm/current/bin:${HOME}/.volta/bin:${HOME}/.asdf/shims"

if command -v openclaw >/dev/null 2>&1; then
  SCHED_PATH="$(dirname "$(command -v openclaw)"):${SCHED_PATH}"
fi
if command -v node >/dev/null 2>&1; then
  SCHED_PATH="$(dirname "$(command -v node)"):${SCHED_PATH}"
fi

mkdir -p "$HOME/Library/LaunchAgents" "$scheduler_log_dir"

cat >"$PLIST_PATH" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${scheduler_macos_label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>${RUNNER_PATH}</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${skill_dir}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>TZ</key>
    <string>Asia/Shanghai</string>
    <key>PATH</key>
    <string>${SCHED_PATH}</string>
  </dict>
  <key>RunAtLoad</key>
  <false/>
  <key>StartCalendarInterval</key>
  <dict>
    <key>Hour</key>
    <integer>${scheduler_hour}</integer>
    <key>Minute</key>
    <integer>${scheduler_minute}</integer>
  </dict>
  <key>StandardOutPath</key>
  <string>${scheduler_log_dir}/launchd.stdout.log</string>
  <key>StandardErrorPath</key>
  <string>${scheduler_log_dir}/launchd.stderr.log</string>
</dict>
</plist>
PLIST

launchctl bootout "gui/$(id -u)/${scheduler_macos_label}" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH"
launchctl enable "gui/$(id -u)/${scheduler_macos_label}" >/dev/null 2>&1 || true

echo "已安装 macOS 定时任务: $PLIST_PATH"
echo "每日执行时间: $(printf '%02d:%02d' "$scheduler_hour" "$scheduler_minute")"
echo "手动触发: launchctl kickstart -k gui/$(id -u)/${scheduler_macos_label}"

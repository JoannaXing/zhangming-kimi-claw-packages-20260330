#!/usr/bin/env python3
"""
knowledge-writer
基于视频知识库生成 grounded 文章
"""
from __future__ import annotations

import sys
import json
import os
import re
import argparse
import tomllib
from pathlib import Path

# 添加 lib 目录到路径
sys.path.insert(0, str(Path(__file__).parent / "lib"))

from article_generator import ArticleGenerator, GenerationOptions
from knowledge_retriever import VideoKnowledgeRetriever


def load_runtime_config() -> dict:
    config_path = Path(__file__).parent / "config" / "runtime.toml"
    if not config_path.exists():
        return {}
    with config_path.open("rb") as handle:
        return tomllib.load(handle)


def resolve_output_dir(config: dict) -> Path:
    output_cfg = config.get("output", {})
    configured = (
        str(os.getenv("KNOWLEDGE_WRITER_OUTPUT_DIR") or "").strip()
        or str(output_cfg.get("default_dir") or "").strip()
        or ".state/generated-articles"
    )
    path = Path(configured).expanduser()
    if not path.is_absolute():
        path = (Path(__file__).parent / path).resolve()
    return path


def infer_target_words(request: str) -> int | None:
    match = re.search(r"(\d{2,5})\s*字", request)
    if not match:
        return None
    value = int(match.group(1))
    return value if value > 0 else None


def infer_retrieval_query(request: str) -> str:
    text = re.sub(r"\s+", " ", str(request or "")).strip()
    if not text:
        return ""

    patterns = [
        r"关于[「“\"]?(.+?)[」”\"]?(?:的)?(?:文章|短文|内容|文案|分享|思考)",
        r"聊聊[「“\"]?(.+?)[」”\"]?(?:吧|。|，|,|$)",
        r"写(?:一篇|篇)?(?:大约)?\d{0,5}字?(?:的)?关于(.+?)(?:的)?(?:文章|短文|内容|文案|分享|思考|吧|。|，|,|$)",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            candidate = match.group(1).strip("，。,.;；：: ")
            if candidate:
                return candidate

    cleaned = text
    noise_patterns = [
        r"^基于视频知识库[,，]?",
        r"以我的口吻[,，]?",
        r"用我的口吻[,，]?",
        r"默认口吻[^，,。]*[,，]?",
        r"写(?:一篇|篇)?",
        r"\d{2,5}\s*字",
        r"的文章",
        r"文章",
        r"短文",
        r"文案",
        r"内容",
        r"要求有?观点",
        r"要求有?案例",
        r"要求有?金句",
        r"有观点",
        r"有案例",
        r"有金句",
    ]
    for pattern in noise_patterns:
        cleaned = re.sub(pattern, " ", cleaned)
    cleaned = re.sub(r"\s+", " ", cleaned).strip("，。,.;；：: ")
    return cleaned or text


def slugify_filename(text: str) -> str:
    ascii_only = re.sub(r"[^\w\-]+", "_", text.strip(), flags=re.UNICODE)
    ascii_only = ascii_only.strip("_")
    return ascii_only or "article"


def main():
    config = load_runtime_config()
    retrieval_cfg = config.get("retrieval", {})
    output_cfg = config.get("output", {})

    parser = argparse.ArgumentParser(description="基于视频知识库生成 grounded 文章")
    parser.add_argument("request", help='主题或完整写作要求，如"写一篇200字关于高尔夫的文章"')
    parser.add_argument("--query", help="用于检索知识库的查询词，默认自动从 request 推断")
    parser.add_argument("--words", "-w", type=int, default=0, help="目标字数；未传时优先从 request 提取")
    parser.add_argument("--top", type=int, default=0, help="检索前 N 条结果")
    parser.add_argument("--profile", help="指定知识库 profile；优先级为命令行 > KNOWLEDGE_WRITER_PROFILE > VIDEO_KNOWLEDGE_PROFILE")
    parser.add_argument("--voice", help="显式指定文章口吻；默认沿用视频知识库口吻")
    parser.add_argument("--audience", help="指定受众")
    parser.add_argument(
        "--provider",
        choices=["auto", "ark", "openclaw"],
        help="生成提供方；优先级为命令行 > KNOWLEDGE_WRITER_PROVIDER > runtime.toml",
    )
    parser.add_argument("--output-file", "-o", help="输出 Markdown 文件路径")
    parser.add_argument("--output-doc", help="保留参数，当前未实现飞书文档直写")
    parser.add_argument("--json", action="store_true", help="输出 JSON，便于调试")
    parser.add_argument("--no-source-refs", action="store_true", help="正文后不追加原文定位")

    args = parser.parse_args()

    def log(message: str = "") -> None:
        if args.json:
            print(message, file=sys.stderr)
        else:
            print(message)

    if args.output_doc:
        print("提示: --output-doc 当前仍未实现飞书直写，本次会继续正常生成本地 Markdown。", file=sys.stderr)

    retrieval_query = (args.query or infer_retrieval_query(args.request)).strip()
    if not retrieval_query:
        print("错误: 无法从 request 推断检索主题，请通过 --query 显式指定。", file=sys.stderr)
        sys.exit(2)

    target_words = args.words or infer_target_words(args.request) or int(output_cfg.get("default_words") or 1500)
    top_k = args.top or int(retrieval_cfg.get("default_top_k") or 5)
    excerpt_chars = int(retrieval_cfg.get("excerpt_chars") or 220)
    include_source_refs = (not args.no_source_refs) and bool(output_cfg.get("include_source_refs", True))
    selected_profile = (
        str(args.profile or "").strip()
        or str(os.getenv("KNOWLEDGE_WRITER_PROFILE") or "").strip()
        or str(os.getenv("VIDEO_KNOWLEDGE_PROFILE") or "").strip()
    )

    query_script = Path(__file__).resolve().parents[1] / "video-knowledge-query" / "video_knowledge_query.py"
    retriever = VideoKnowledgeRetriever(
        script_path=query_script,
        default_top_k=top_k,
        excerpt_chars=excerpt_chars,
        default_profile=selected_profile,
        allow_auto_scope=True,
    )
    generator = ArticleGenerator(config)

    log(f"[知识库] 检索查询: {retrieval_query}")
    log(f"[知识库] 原始请求: {args.request}")
    log(f"[知识库] 目标字数: {target_words}")
    log(f"[知识库] 检索条数: {top_k}")
    if selected_profile:
        log(f"[知识库] 指定 profile: {selected_profile}")

    log("\n[1/2] 检索知识库...")
    try:
        payload = retriever.search(
            retrieval_query,
            top_k=top_k,
            profile=selected_profile or None,
            allow_auto_scope=True,
        )
    except Exception as exc:
        print(f"知识库检索失败: {exc}", file=sys.stderr)
        sys.exit(2)
    results = payload.get("results") or []
    if not results:
        print(f"未找到与“{retrieval_query}”相关的知识库内容。", file=sys.stderr)
        sys.exit(1)
    log(f"找到 {len(results)} 条相关记录")

    log("\n[2/2] 生成 grounded 文章...")
    generated = generator.generate(
        payload=payload,
        options=GenerationOptions(
            target_words=target_words,
            retrieval_query=retrieval_query,
            original_request=args.request,
            voice=args.voice,
            audience=args.audience,
            provider=args.provider,
            include_source_refs=include_source_refs,
        ),
    )

    output_payload = {
        "request": args.request,
        "retrievalQuery": retrieval_query,
        "targetWords": target_words,
        "provider": generated["provider"],
        "scope": payload.get("scope") or {},
        "results": results,
        "article": {
            "title": generated["title"],
            "quote": generated["quote"],
            "body": generated["article"],
            "markdown": generated["markdown"],
            "usedSourceRanks": generated["usedSourceRanks"],
            "groundingNotes": generated["groundingNotes"],
        },
    }

    output_file = args.output_file
    if not output_file:
        slug = slugify_filename(retrieval_query)[:48]
        output_dir = resolve_output_dir(config)
        output_dir.mkdir(parents=True, exist_ok=True)
        output_file = str((output_dir / f"article_{slug}.md").resolve())

    Path(output_file).write_text(generated["markdown"], encoding="utf-8")

    if args.json:
        print(json.dumps(output_payload, ensure_ascii=False, indent=2))
    else:
        print("\n" + "=" * 60)
        print("文章预览:")
        print("=" * 60)
        preview = generated["markdown"]
        print(preview[:1000] + "..." if len(preview) > 1000 else preview)
        print(f"[输出] Markdown 已保存: {output_file}")


if __name__ == '__main__':
    main()

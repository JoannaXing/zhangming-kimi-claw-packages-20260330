---
name: knowledge-base-query
description: 轻量 RAG 查询统一知识库 profile，基于 knowledge-bases 下的本地备份检索主题、标签、核心要点和完整文案；支持 grounded 问答和基础统计
metadata:
  openclaw:
    emoji: 🔎
    requires:
      bins: [python3]
      env: []
---

# knowledge-base-query

用于查询 `knowledge-bases/*` 下的统一知识库 profile。当前默认支持：

- `search`：返回命中的主题、要点、片段和原文定位
- `answer`：基于命中证据直接生成 grounded 回复
- `stats`：输出知识库规模统计、互动汇总，以及点赞/收藏/评论/转发最高的内容和主题
- `profile`：切换 `rizaoli-douyin`、`synqora-ai` 等知识库

## 调用

```bash
python3 knowledge_base_query.py --list-profiles
python3 knowledge_base_query.py "基于我的AI知识库，Skill 和 MCP 有什么区别？"
python3 knowledge_base_query.py "基于 synqora-ai 知识库，Skill 和 MCP 有什么区别？"
python3 knowledge_base_query.py "基于 rizaoli-douyin 知识库，孩子不爱学习怎么办？"
python3 knowledge_base_query.py "Skill 和 MCP 有什么区别？" --profile synqora-ai --mode answer
python3 knowledge_base_query.py --stats --profile synqora-ai --json
```

## 规则

1. profile 从 `knowledge-bases/<name>/profile.toml` 自动发现，不再把 profile 写死在 skill runtime 里。
2. 查询层只读取 profile 自己的 `storage/records`，不直接扫各 source skill 的私有目录。
3. `--profile` 优先级高于默认 profile；也可用 `KNOWLEDGE_BASE_PROFILE` 指定。
4. `answer` 模式支持 `--provider auto|ark|openclaw`，也可用 `KNOWLEDGE_BASE_ANSWER_PROVIDER` 指定默认值。
5. `原文定位` 的来源标签不再写死成抖音，会按记录中的 `source/sourceUrl` 输出。

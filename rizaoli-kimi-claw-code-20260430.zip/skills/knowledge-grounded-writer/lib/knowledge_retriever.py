#!/usr/bin/env python3
"""Knowledge-base retrieval adapter for grounded writing."""
from __future__ import annotations

import importlib.util
import json
import re
import sys
from pathlib import Path
from types import SimpleNamespace
from typing import Any


def normalize_for_match(text: str | None) -> str:
    if not text:
        return ""
    return re.sub(r"[\s\u3000，。！？、；：“”‘’\"'《》〈〉<>\(\)（）【】\[\]\-—_:：/\\|#]+", "", text).lower()


class KnowledgeBaseRetriever:
    """Reuse the sibling knowledge-base-query skill as retrieval backend."""

    def __init__(
        self,
        script_path: Path,
        default_top_k: int = 5,
        excerpt_chars: int = 220,
        default_profile: str = "",
        allow_auto_scope: bool = True,
    ):
        self.script_path = script_path.resolve()
        self.default_top_k = default_top_k
        self.excerpt_chars = excerpt_chars
        self.default_profile = str(default_profile or "").strip()
        self.allow_auto_scope = bool(allow_auto_scope)
        self._module = self._load_module()

    def _load_module(self):
        spec = importlib.util.spec_from_file_location("knowledge_base_query_runtime", self.script_path)
        if not spec or not spec.loader:
            raise RuntimeError(f"无法加载检索脚本: {self.script_path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module

    def search(
        self,
        query: str,
        top_k: int | None = None,
        profile: str | None = None,
        allow_auto_scope: bool | None = None,
    ) -> dict[str, Any]:
        args = SimpleNamespace(
            query=query,
            top=top_k or self.default_top_k,
            stats=False,
            mode="search",
            profile=(profile or self.default_profile or "").strip() or None,
            allow_auto_scope=self.allow_auto_scope if allow_auto_scope is None else bool(allow_auto_scope),
        )
        payload = self._module.build_payload(args)
        query_meta = payload.get("query") or {}
        focus_terms = list(query_meta.get("focusTerms") or [])
        expanded_terms = list(query_meta.get("expandedTerms") or [])

        enriched_results: list[dict[str, Any]] = []
        for index, item in enumerate(payload.get("results") or [], start=1):
            enriched = dict(item)
            enriched["rank"] = index
            enriched.update(self._load_record_context(item, focus_terms, expanded_terms))
            enriched_results.append(enriched)

        payload["results"] = enriched_results
        if enriched_results:
            payload["sourceRefs"] = [item["sourceRef"] for item in enriched_results if item.get("sourceRef")]
            payload["sourceRefText"] = self._module.build_source_ref_text(payload["sourceRefs"])
        return payload

    def _load_record_context(
        self,
        item: dict[str, Any],
        focus_terms: list[str],
        expanded_terms: list[str],
    ) -> dict[str, Any]:
        backup_path = Path(str(item.get("backupPath") or "")).expanduser()
        record_path = backup_path / "record.json"
        if not record_path.exists():
            return {"transcript": "", "transcriptExcerpt": ""}

        record = json.loads(record_path.read_text(encoding="utf-8"))
        transcript = str(record.get("transcript") or "").strip()
        return {
            "transcript": transcript,
            "transcriptExcerpt": self._select_excerpt(transcript, focus_terms + expanded_terms),
        }

    def _select_excerpt(self, transcript: str, terms: list[str]) -> str:
        text = str(transcript or "").strip()
        if not text:
            return ""
        compact_text = normalize_for_match(text)
        for term in terms:
            compact_term = normalize_for_match(term)
            if not compact_term:
                continue
            compact_index = compact_text.find(compact_term)
            if compact_index < 0:
                continue

            raw_index = self._compact_index_to_raw_index(text, compact_index)
            start = max(0, raw_index - self.excerpt_chars // 2)
            end = min(len(text), start + self.excerpt_chars)
            excerpt = text[start:end].strip()
            if start > 0:
                excerpt = "…" + excerpt
            if end < len(text):
                excerpt = excerpt + "…"
            return excerpt

        if len(text) <= self.excerpt_chars:
            return text
        return text[: self.excerpt_chars].rstrip() + "…"

    def _compact_index_to_raw_index(self, text: str, compact_index: int) -> int:
        seen = 0
        for index, char in enumerate(text):
            if normalize_for_match(char):
                if seen == compact_index:
                    return index
                seen += 1
        return 0

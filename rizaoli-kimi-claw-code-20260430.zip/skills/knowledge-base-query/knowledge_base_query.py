#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import os
import re
import subprocess
import sys
import time
import tomllib
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from lib.knowledge_base_profiles import load_profile_runtime_map

TRIGGER_PREFIXES = [
    "基于视频知识库",
    "基于知识库",
    "基于AI知识库",
    "我的视频知识库里",
    "帮我搜索下知识库",
    "帮我回忆下",
    "视频知识库里",
    "知识库里",
]

QUERY_NOISE_PHRASES = [
    "核心观点",
    "核心理念",
    "核心内容",
    "核心看法",
    "有哪些",
    "有什么",
    "是什么",
    "都有哪些",
    "主要有哪些",
    "帮我",
    "回忆下",
    "搜索下知识库",
    "搜索下",
    "查一下",
    "看一下",
    "看下",
    "整理下",
    "总结下",
    "总结一下",
    "请问",
    "请",
    "一下",
    "关于",
    "有关",
    "围绕",
    "视频知识库",
    "知识库",
    "视频里",
    "视频中",
    "短视频",
    "视频",
    "观点",
    "理念",
    "内容",
    "说过",
    "提过",
    "讲过",
    "聊过",
    "怎么看",
    "怎么说",
    "方面",
]

TERM_EXPANSIONS = {
    "教育": ["孩子", "家长", "父母", "儿童", "成长", "学习"],
    "创业": ["业务", "客户", "生意", "企业", "公司", "销售"],
    "管理": ["团队", "干部", "管理者", "领导", "带队"],
    "领导力": ["领导", "管理者", "团队", "带队"],
    "认知": ["觉醒", "觉悟", "思维", "格局"],
    "人生": ["生活", "意义", "觉醒", "幸福"],
}

TERM_HINTS = sorted(
    {
        *TERM_EXPANSIONS.keys(),
        *(term for terms in TERM_EXPANSIONS.values() for term in terms),
        "青春期",
        "叛逆",
        "沟通",
        "自驱力",
        "目标感",
        "情绪",
        "专注",
        "习惯",
        "客户",
        "回复",
        "回答",
        "提问",
        "关系",
        "婚姻",
        "家庭",
        "销售",
        "老板",
        "干部",
        "团队",
        "用人",
        "执行力",
    },
    key=len,
    reverse=True,
)

WEAK_FOCUS_TERMS = {
    "见解",
    "看法",
    "观点",
    "想法",
    "理解",
    "评价",
    "建议",
    "分析",
    "总结",
    "结论",
    "启发",
    "认知",
    "意义",
    "经验",
}

QUESTION_HINT_RE = re.compile(r"(怎么办|怎么回|怎么回复|如何回复|如何回|为什么|如何|怎么|怎样|请问|是否|能不能|该不该|需不需要|有没有|什么|哪些|哪种|哪里|谁)")
REPLY_INTENT_RE = re.compile(r"(帮我回|帮我回复|帮我回答|这个问题怎么回|这个问题怎么答|适合怎么说|怎么跟.*说|如何跟.*说)")
TERM_SPLIT_RE = re.compile(r"(怎么办|怎么回|怎么回复|如何回复|如何回|为什么|如何|怎么|怎样|请问|是否|能不能|该不该|需不需要|有没有|问题|回复|回答|客户|关于|对于|这个|那个|一直|总是|没有|不)")

FIELD_WEIGHTS = (
    ("topic", "主题", 120),
    ("tags_text", "标签", 110),
    ("key_points_text", "核心要点", 90),
    ("title_text", "标题", 60),
    ("transcript_text", "全文", 45),
    ("comments_text", "评论", 20),
)

ENGAGEMENT_METRICS = (
    ("diggCount", "点赞", "digg_count"),
    ("collectCount", "收藏", "collect_count"),
    ("commentCount", "评论", "comment_count"),
    ("shareCount", "转发", "share_count"),
)

PUNCT_RE = re.compile(r"[\s\u3000，。！？、；：“”‘’\"'《》〈〉<>\(\)（）【】\[\]\-—_:：/\\|#]+")
SPACE_PUNCT_RE = re.compile(r"[\u3000，。！？、；：“”‘’\"'《》〈〉<>\(\)（）【】\[\]\-—_:：/\\|]+")
DATE_DAY_RE = re.compile(r"(?P<year>\d{4})[/-年](?P<month>\d{1,2})[/-月](?P<day>\d{1,2})日?")
DATE_MONTH_RE = re.compile(r"(?P<year>\d{4})[/-年](?P<month>\d{1,2})月?")
DATE_YEAR_RE = re.compile(r"(?P<year>\d{4})年?")
PROVIDER_CHOICES = ("auto", "ark", "openclaw")
OPENCLAW_RETRY_ATTEMPTS = 2


def resolve_openclaw_bin() -> str:
    return cleanup_text(os.getenv("OPENCLAW_BIN") or os.getenv("OPENCLAW_CLI_BIN")) or "openclaw"


@dataclass
class TimeFilter:
    label: str
    start: date
    end: date


@dataclass
class Record:
    video_id: str
    publish_time: str
    publish_date: str
    publish_dt: datetime | None
    topic: str
    title: str
    tags: list[str]
    key_points: list[str]
    transcript: str
    comments: list[str]
    duration: str
    duration_seconds: int
    digg_count: int
    collect_count: int
    comment_count: int
    share_count: int
    dedupe_status: str
    canonical_video_id: str
    backup_path: str
    platform: str
    source: str
    source_url: str
    uploader: str
    title_text: str = field(init=False)
    tags_text: str = field(init=False)
    key_points_text: str = field(init=False)
    transcript_text: str = field(init=False)
    comments_text: str = field(init=False)
    all_text: str = field(init=False)

    def __post_init__(self) -> None:
        self.title_text = normalize_for_match(self.title)
        self.tags_text = normalize_for_match(" ".join(self.tags))
        self.key_points_text = normalize_for_match(" ".join(self.key_points))
        self.transcript_text = normalize_for_match(self.transcript)
        self.comments_text = normalize_for_match(" ".join(self.comments))
        self.all_text = normalize_for_match(
            " ".join(
                [
                    self.topic,
                    self.title,
                    " ".join(self.tags),
                    " ".join(self.key_points),
                    self.transcript,
                    " ".join(self.comments),
                ]
            )
        )

    @property
    def url(self) -> str:
        if self.source_url:
            return self.source_url
        source_key = normalize_profile_name(self.source or self.platform)
        if source_key in {"douyin", "抖音"}:
            return f"https://www.douyin.com/video/{self.video_id}"
        if source_key in {"bilibili", "b站", "哔哩哔哩"}:
            return f"https://www.bilibili.com/video/{self.video_id}/"
        if source_key == "youtube":
            return f"https://www.youtube.com/watch?v={self.video_id}"
        return ""


@dataclass
class QueryBundle:
    raw: str
    normalized: str
    focus_terms: list[str]
    expanded_terms: list[str]
    owner_name: str
    owner_resolved_query: str
    time_filter: TimeFilter | None


class KnowledgeScopeError(RuntimeError):
    """Raised when the knowledge scope is not explicitly enabled."""


def normalize_for_match(text: str | None) -> str:
    if not text:
        return ""
    return PUNCT_RE.sub("", text).lower()


def cleanup_text(text: str | None) -> str:
    if not text:
        return ""
    return re.sub(r"\s+", " ", text).strip()


def normalize_text_list(values: Any) -> list[str]:
    if not isinstance(values, list):
        return []
    return [cleanup_text(str(item)) for item in values if cleanup_text(str(item))]


def normalize_profile_name(value: Any) -> str:
    return cleanup_text(str(value or "")).lower()


def parse_bool_flag(value: Any, default: bool) -> bool:
    if value is None or value == "":
        return default
    return cleanup_text(str(value)).lower() not in {"0", "false", "no", "off"}


def normalize_provider(value: Any, *, field_name: str) -> str:
    provider = str(value or "").strip().lower()
    if not provider:
        return "auto"
    if provider not in PROVIDER_CHOICES:
        supported = ", ".join(PROVIDER_CHOICES)
        raise ValueError(f"{field_name} 只支持 {supported}，当前为: {value}")
    return provider


def strip_code_fence(text: str) -> str:
    value = str(text or "").strip()
    fenced = re.match(r"^```(?:json)?\s*([\s\S]*?)\s*```$", value, flags=re.IGNORECASE)
    return fenced.group(1).strip() if fenced else value


def parse_json_from_text(text: str) -> dict[str, Any]:
    raw = strip_code_fence(text)
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end < start:
        raise ValueError("模型输出中未找到 JSON 对象")
    return json.loads(raw[start : end + 1])


def extract_ark_chat_text(data: dict[str, Any]) -> str:
    choices = data.get("choices") if isinstance(data, dict) else None
    if not isinstance(choices, list) or not choices:
        return ""
    primary = (((choices[0] or {}).get("message") or {}).get("content"))
    if isinstance(primary, str):
        return primary.strip()
    if isinstance(primary, list):
        parts: list[str] = []
        for item in primary:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict) and isinstance(item.get("text"), str):
                parts.append(item["text"])
        return "\n".join(part.strip() for part in parts if part and part.strip()).strip()
    return ""


def extract_openclaw_text(result: dict[str, Any]) -> str:
    payloads = (((result or {}).get("result") or {}).get("payloads")) or ((result or {}).get("payloads")) or []
    parts: list[str] = []
    for payload in payloads:
        if isinstance(payload, dict) and isinstance(payload.get("text"), str):
            text = payload["text"].strip()
            if text:
                parts.append(text)
    return "\n".join(parts).strip()


def load_toml(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("rb") as handle:
        return tomllib.load(handle)


def resolve_script_root() -> Path:
    return Path(__file__).resolve().parent


def load_profile_map(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    profiles = load_profile_runtime_map(resolve_script_root())
    if profiles:
        return profiles
    profiles_cfg = config.get("profiles", {})
    if not isinstance(profiles_cfg, dict):
        return {}
    fallback: dict[str, dict[str, Any]] = {}
    for raw_name, raw_cfg in profiles_cfg.items():
        name = normalize_profile_name(raw_name)
        if name and isinstance(raw_cfg, dict):
            fallback[name] = raw_cfg
    return fallback


def get_scope_settings(config: dict[str, Any]) -> dict[str, Any]:
    scope_cfg = config.get("scope", {})
    return {
        "enabled": parse_bool_flag(scope_cfg.get("enabled"), True),
        "autoTrigger": parse_bool_flag(scope_cfg.get("auto_trigger"), True),
        "defaultProfile": normalize_profile_name(scope_cfg.get("default_profile")),
        "requireExplicitProfile": parse_bool_flag(scope_cfg.get("require_explicit_profile"), False),
    }


def build_profile_activation_terms(profile_name: str, profile_cfg: dict[str, Any]) -> list[str]:
    owner_name = cleanup_text(profile_cfg.get("owner_name"))
    label = cleanup_text(profile_cfg.get("label"))
    terms = normalize_text_list(profile_cfg.get("activation_terms"))
    if owner_name:
        terms.extend(
            [
                f"{owner_name}知识库",
                f"{owner_name}的视频知识库",
                f"{owner_name}视频知识库",
                f"基于{owner_name}知识库",
                f"基于{owner_name}的视频知识库",
            ]
        )
    if label:
        terms.append(label)
    if profile_name:
        terms.extend([profile_name, f"{profile_name}知识库"])
    prefixed_terms = [f"基于{term}" for term in terms if term and not term.startswith("基于")]
    terms.extend(prefixed_terms)
    return dedupe_keep_order([term for term in terms if cleanup_text(term)])


def detect_profile_from_query(raw_query: str | None, profiles: dict[str, dict[str, Any]]) -> str:
    query_norm = normalize_for_match(raw_query)
    if not query_norm:
        return ""

    matched_profile = ""
    for profile_name, profile_cfg in profiles.items():
        for term in sorted(build_profile_activation_terms(profile_name, profile_cfg), key=len, reverse=True):
            if not term:
                continue
            if normalize_for_match(term) in query_norm:
                if matched_profile and matched_profile != profile_name:
                    raise KnowledgeScopeError("问题中命中了多个知识库 profile，请明确指定一个。")
                matched_profile = profile_name
                break
    return matched_profile


def query_has_knowledge_activation(raw_query: str | None) -> bool:
    query_norm = normalize_for_match(raw_query)
    if not query_norm:
        return False
    trigger_terms = [*TRIGGER_PREFIXES, "知识库", "视频知识库", "基于知识库"]
    return any(normalize_for_match(term) in query_norm for term in trigger_terms)


def profile_display_name(profile_name: str, profile_cfg: dict[str, Any] | None) -> str:
    if not profile_name:
        return ""
    profile_cfg = profile_cfg or {}
    return (
        cleanup_text(profile_cfg.get("label"))
        or cleanup_text(profile_cfg.get("owner_name"))
        or profile_name
    )


def apply_profile_overrides(config: dict[str, Any], profile_name: str) -> dict[str, Any]:
    effective = copy.deepcopy(config)
    if not profile_name:
        return effective

    profiles = load_profile_map(config)
    profile_cfg = profiles.get(profile_name)
    if not profile_cfg:
        raise KnowledgeScopeError(f"未找到知识库 profile: {profile_name}")

    owner_cfg = effective.setdefault("owner", {})
    source_cfg = effective.setdefault("source", {})

    owner_name = cleanup_text(profile_cfg.get("owner_name"))
    if owner_name:
        owner_cfg["name"] = owner_name

    owner_aliases = normalize_text_list(profile_cfg.get("owner_aliases"))
    if owner_aliases:
        owner_cfg["aliases"] = owner_aliases

    backup_root = cleanup_text(profile_cfg.get("backup_root"))
    if backup_root:
        source_cfg["backup_root"] = backup_root

    target_name = cleanup_text(profile_cfg.get("target_name"))
    if target_name:
        source_cfg["target_name"] = target_name

    return effective


def resolve_scope_selection(args: argparse.Namespace, config: dict[str, Any]) -> dict[str, Any]:
    profiles = load_profile_map(config)
    scope_settings = get_scope_settings(config)

    explicit_profile = normalize_profile_name(
        getattr(args, "profile", None)
        or os.getenv("KNOWLEDGE_BASE_PROFILE")
        or os.getenv("VIDEO_KNOWLEDGE_PROFILE")
        or ""
    )
    if explicit_profile and explicit_profile not in profiles:
        raise KnowledgeScopeError(f"未找到知识库 profile: {explicit_profile}")

    matched_profile = detect_profile_from_query(getattr(args, "query", None), profiles)
    explicit_activation = bool(explicit_profile or matched_profile or query_has_knowledge_activation(getattr(args, "query", None)))
    allow_auto_scope = bool(getattr(args, "allow_auto_scope", False))

    if not scope_settings["enabled"] and not explicit_activation and not allow_auto_scope and not getattr(args, "stats", False):
        raise KnowledgeScopeError("当前知识库作用范围已关闭。请显式指定 profile，或在问题中明确说“基于xx知识库”。")

    if (
        getattr(args, "query", None)
        and not scope_settings["autoTrigger"]
        and not explicit_activation
        and not allow_auto_scope
    ):
        raise KnowledgeScopeError("当前知识库未自动生效。请明确说“基于视频知识库”，或通过 --profile 指定目标知识库。")

    selected_profile = explicit_profile or matched_profile
    default_profile = scope_settings["defaultProfile"]
    if default_profile and default_profile not in profiles:
        raise KnowledgeScopeError(f"默认知识库 profile 不存在: {default_profile}")

    if scope_settings["requireExplicitProfile"] and not selected_profile and profiles:
        raise KnowledgeScopeError("当前要求显式指定知识库 profile，请使用 --profile 或在问题里明确说“基于xx知识库”。")

    if not selected_profile:
        if default_profile:
            selected_profile = default_profile
        elif len(profiles) == 1:
            selected_profile = next(iter(profiles))

    if not selected_profile and len(profiles) > 1:
        raise KnowledgeScopeError("检测到多份知识库，请显式指定 profile，避免串库。")

    selected_cfg = profiles.get(selected_profile) if selected_profile else None
    return {
        "profile": selected_profile,
        "profileLabel": profile_display_name(selected_profile, selected_cfg),
        "explicitActivation": explicit_activation,
        "scopeEnabled": scope_settings["enabled"],
        "autoTrigger": scope_settings["autoTrigger"],
        "requireExplicitProfile": scope_settings["requireExplicitProfile"],
    }


def build_profiles_payload(config: dict[str, Any]) -> dict[str, Any]:
    scope_settings = get_scope_settings(config)
    profiles = load_profile_map(config)
    items: list[dict[str, Any]] = []
    for name, profile_cfg in profiles.items():
        effective = apply_profile_overrides(config, name)
        backup_root = ""
        backup_error = ""
        try:
            backup_root = str(resolve_backup_root(effective))
        except Exception as exc:
            backup_error = str(exc)
        items.append(
            {
                "name": name,
                "label": profile_display_name(name, profile_cfg),
                "ownerName": cleanup_text(profile_cfg.get("owner_name")),
                "targetName": cleanup_text(profile_cfg.get("target_name")),
                "backupRoot": backup_root,
                "backupError": backup_error,
                "activationTerms": build_profile_activation_terms(name, profile_cfg),
                "sourceLabels": [
                    cleanup_text(item.get("label") or item.get("platform"))
                    for item in (profile_cfg.get("sources") or [])
                    if isinstance(item, dict) and cleanup_text(item.get("label") or item.get("platform"))
                ],
                "isDefault": name == scope_settings["defaultProfile"],
            }
        )
    return {
        "scope": scope_settings,
        "profiles": items,
    }


def render_profiles_text(payload: dict[str, Any]) -> str:
    scope = payload.get("scope") or {}
    profiles = payload.get("profiles") or []
    lines = [
        "知识库作用范围",
        f"- enabled: {scope.get('enabled')}",
        f"- auto_trigger: {scope.get('autoTrigger')}",
        f"- default_profile: {scope.get('defaultProfile') or '未设置'}",
        f"- require_explicit_profile: {scope.get('requireExplicitProfile')}",
        "",
    ]
    if not profiles:
        lines.append("未配置任何知识库 profile。")
        return "\n".join(lines).strip()

    lines.append("可用知识库")
    for item in profiles:
        header = f"- {item['name']}"
        label = item.get("label")
        if label and label != item["name"]:
            header += f" | {label}"
        if item.get("isDefault"):
            header += " | 默认"
        lines.append(header)
        owner_name = item.get("ownerName")
        if owner_name:
            lines.append(f"  owner: {owner_name}")
        backup_root = item.get("backupRoot")
        if backup_root:
            lines.append(f"  backup: {backup_root}")
        elif item.get("backupError"):
            lines.append(f"  backup_error: {item['backupError']}")
        activation_terms = item.get("activationTerms") or []
        if activation_terms:
            lines.append(f"  activation_terms: {', '.join(activation_terms)}")
        source_labels = item.get("sourceLabels") or []
        if source_labels:
            lines.append(f"  sources: {', '.join(source_labels)}")
    return "\n".join(lines).strip()


def resolve_backup_root(config: dict[str, Any]) -> Path:
    env_root = (
        os.getenv("KNOWLEDGE_BASE_BACKUP_ROOT")
        or os.getenv("KNOWLEDGE_BASE_RECORD_ROOT")
        or os.getenv("VIDEO_KNOWLEDGE_BACKUP_ROOT")
        or os.getenv("DOUYIN_TRANSCRIBE_BACKUP_DIR")
        or os.getenv("DOUYIN_BACKUP_DIR")
    )
    if env_root:
        path = Path(env_root).expanduser().resolve()
        if not path.exists():
            raise FileNotFoundError(f"备份目录不存在: {path}")
        return path

    script_root = resolve_script_root()
    source_cfg = config.get("source", {})
    configured_root = cleanup_text(source_cfg.get("backup_root"))
    if configured_root:
        root = Path(configured_root).expanduser()
        if not root.is_absolute():
            root = (script_root / root).resolve()
        if not root.exists():
            raise FileNotFoundError(f"备份目录不存在: {root}")
        return root

    sibling_spec = cleanup_text(source_cfg.get("sibling_skill")) or "../douyin-transcribe-to-feishu"
    sibling_root = Path(sibling_spec).expanduser()
    if not sibling_root.is_absolute():
        sibling_root = (script_root / sibling_spec).resolve()
    if not sibling_root.exists():
        raise FileNotFoundError(f"未找到关联 skill 目录: {sibling_root}")

    runtime_cfg = load_toml(sibling_root / "config" / "runtime.toml")
    backup_output = cleanup_text(runtime_cfg.get("backup", {}).get("output_dir")) or ".local-backups"
    backup_base = Path(backup_output).expanduser()
    if not backup_base.is_absolute():
        backup_base = (sibling_root / backup_output).resolve()
    if not backup_base.exists():
        raise FileNotFoundError(f"未找到备份根目录: {backup_base}")

    target_name = cleanup_text(source_cfg.get("target_name"))
    if not target_name:
        feishu_cfg = runtime_cfg.get("feishu", {})
        doc_token = cleanup_text(feishu_cfg.get("doc_token"))
        app_token = cleanup_text(feishu_cfg.get("bitable_app_token"))
        table_id = cleanup_text(feishu_cfg.get("bitable_table_id"))
        if doc_token and app_token and table_id:
            target_name = f"{doc_token}_{app_token}_{table_id}"

    preferred = backup_base / target_name if target_name else None
    if preferred and preferred.exists():
        return preferred.resolve()
    if preferred and not preferred.exists():
        raise FileNotFoundError(f"未找到目标知识库目录: {preferred}")

    candidates = sorted(path for path in backup_base.iterdir() if path.is_dir())
    if not candidates:
        raise FileNotFoundError(f"备份根目录下没有可用目标: {backup_base}")
    if len(candidates) == 1:
        return candidates[0].resolve()

    candidate_names = ", ".join(path.name for path in candidates[:5])
    if len(candidates) > 5:
        candidate_names += f" 等 {len(candidates)} 个目录"
    raise FileNotFoundError(
        "检测到多个知识库目录，已停止自动猜测目标。"
        f"请在 runtime.toml 的 source.target_name 或 profiles.<name>.target_name 中显式指定。"
        f"当前目录: {backup_base}；候选: {candidate_names}"
    )


def load_dedupe_index(backup_root: Path) -> dict[str, dict[str, Any]]:
    dedupe_path = backup_root / "dedupe-index.json"
    if not dedupe_path.exists():
        return {}
    data = json.loads(dedupe_path.read_text(encoding="utf-8"))
    mapping: dict[str, dict[str, Any]] = {}
    for item in data.get("items") or []:
        video_id = str(item.get("videoId") or "").strip()
        if video_id:
            mapping[video_id] = item
    return mapping


def load_catalog_counts(backup_root: Path) -> tuple[int, int]:
    dedupe = load_dedupe_index(backup_root)
    if dedupe:
        canonical_count = sum(1 for item in dedupe.values() if item.get("dedupeStatus") != "duplicate")
        duplicate_count = sum(1 for item in dedupe.values() if item.get("dedupeStatus") == "duplicate")
        return canonical_count, duplicate_count
    record_count = len(list(backup_root.glob("*/record.json")))
    return record_count, 0


def parse_duration_seconds(value: str | None) -> int:
    text = cleanup_text(value)
    if not text:
        return 0
    parts = text.split(":")
    if not all(part.isdigit() for part in parts):
        return 0
    total = 0
    for part in parts:
        total = total * 60 + int(part)
    return total


def parse_publish_datetime(value: str | None) -> datetime | None:
    text = cleanup_text(value)
    if not text:
        return None
    for pattern in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return datetime.strptime(text, pattern)
        except ValueError:
            continue
    return None


def extract_tags(title: str | None) -> list[str]:
    if not title:
        return []
    return [cleanup_text(tag) for tag in re.findall(r"#([^\s#]+)", title) if cleanup_text(tag)]


def normalize_title_for_search(title: str | None) -> str:
    text = cleanup_text(title)
    if not text:
        return ""
    if re.fullmatch(r".*记录美好生活\d{8}", text):
        return ""
    return text


def load_records(backup_root: Path) -> list[Record]:
    dedupe_map = load_dedupe_index(backup_root)
    records: list[Record] = []

    for record_path in sorted(backup_root.glob("*/record.json")):
        raw = json.loads(record_path.read_text(encoding="utf-8"))
        video_id = cleanup_text(raw.get("videoId"))
        if not video_id:
            continue
        dedupe = dedupe_map.get(video_id, {})
        dedupe_status = cleanup_text(dedupe.get("dedupeStatus")) or "canonical"
        if dedupe_status == "duplicate":
            continue

        topic = cleanup_text(raw.get("topic"))
        title = normalize_title_for_search(raw.get("title"))
        tags = normalize_text_list(raw.get("tags")) or extract_tags(raw.get("title"))
        digg_count = int(raw.get("diggCount") or raw.get("likeCount") or 0)
        source = cleanup_text(raw.get("sourceCategory") or raw.get("source") or raw.get("platform"))
        record = Record(
            video_id=video_id,
            publish_time=cleanup_text(raw.get("publishTime")),
            publish_date=cleanup_text((raw.get("publishTime") or "")[:10]),
            publish_dt=parse_publish_datetime(raw.get("publishTime")),
            topic=topic,
            title=title,
            tags=tags,
            key_points=[cleanup_text(item) for item in (raw.get("keyPoints") or []) if cleanup_text(item)],
            transcript=cleanup_text(raw.get("transcript")),
            comments=[cleanup_text(item) for item in (raw.get("comments") or []) if cleanup_text(item)],
            duration=cleanup_text(raw.get("duration")),
            duration_seconds=parse_duration_seconds(raw.get("duration")),
            digg_count=digg_count,
            collect_count=int(raw.get("collectCount") or 0),
            comment_count=int(raw.get("commentCount") or 0),
            share_count=int(raw.get("shareCount") or 0),
            dedupe_status=dedupe_status,
            canonical_video_id=cleanup_text(dedupe.get("canonicalVideoId")) or video_id,
            backup_path=str(record_path.parent),
            platform=cleanup_text(raw.get("platform")),
            source=source,
            source_url=cleanup_text(raw.get("sourceUrl")),
            uploader=cleanup_text(raw.get("uploader")),
        )
        records.append(record)

    records.sort(key=lambda item: item.publish_dt or datetime.min)
    return records


def replace_owner_aliases(query: str, owner_name: str, aliases: list[str]) -> str:
    result = query
    patterns = sorted(set(aliases), key=len, reverse=True)
    for alias in patterns:
        alias = alias.strip()
        if not alias:
            continue
        pattern = rf"(^|[\s，,。！？；;：:]){re.escape(alias)}(?=($|[\s的在有哪些什么怎么如何与和及，,。！？；;：:]))"
        result = re.sub(pattern, lambda match: f"{match.group(1)}{owner_name}", result)
    return cleanup_text(result)


def extract_time_filter(query: str) -> tuple[str, TimeFilter | None]:
    text = query

    match = DATE_DAY_RE.search(text)
    if match:
        year = int(match.group("year"))
        month = int(match.group("month"))
        day = int(match.group("day"))
        current = date(year, month, day)
        label = f"{current.isoformat()}"
        text = cleanup_text(text[: match.start()] + " " + text[match.end() :])
        return text, TimeFilter(label=label, start=current, end=current)

    match = DATE_MONTH_RE.search(text)
    if match:
        year = int(match.group("year"))
        month = int(match.group("month"))
        start = date(year, month, 1)
        if month == 12:
            end = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            end = date(year, month + 1, 1) - timedelta(days=1)
        label = f"{year:04d}-{month:02d}"
        text = cleanup_text(text[: match.start()] + " " + text[match.end() :])
        return text, TimeFilter(label=label, start=start, end=end)

    match = DATE_YEAR_RE.search(text)
    if match:
        year = int(match.group("year"))
        start = date(year, 1, 1)
        end = date(year, 12, 31)
        label = f"{year:04d}"
        text = cleanup_text(text[: match.start()] + " " + text[match.end() :])
        return text, TimeFilter(label=label, start=start, end=end)

    return text, None


def strip_trigger_prefixes(query: str) -> str:
    text = cleanup_text(query)
    changed = True
    while changed:
        changed = False
        for prefix in TRIGGER_PREFIXES:
            pattern = rf"^\s*{re.escape(prefix)}[\s，,。！？；;：:]*"
            if re.match(pattern, text):
                text = re.sub(pattern, "", text)
                text = cleanup_text(text)
                changed = True
    return text


def strip_profile_activation_prefixes(query: str, config: dict[str, Any]) -> str:
    text = cleanup_text(query)
    changed = True
    while changed:
        changed = False
        for profile_name, profile_cfg in load_profile_map(config).items():
            terms = sorted(build_profile_activation_terms(profile_name, profile_cfg), key=len, reverse=True)
            for term in terms:
                pattern = rf"^\s*{re.escape(term)}[\s，,。！？；;：:]*"
                if re.match(pattern, text):
                    text = re.sub(pattern, "", text)
                    text = cleanup_text(text)
                    changed = True
    return text


def split_compound_terms(text: str) -> list[str]:
    pieces = [cleanup_text(part) for part in re.split(r"[、,，/]|(?:和|及|与)", text) if cleanup_text(part)]
    if len(pieces) > 1:
        return [piece for piece in pieces if len(piece) >= 2]
    return [cleanup_text(text)] if cleanup_text(text) else []


def dedupe_keep_order(values: list[str]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        if value and value not in seen:
            seen.add(value)
            result.append(value)
    return result


def rebalance_focus_terms(terms: list[str]) -> list[str]:
    ordered = dedupe_keep_order([cleanup_text(term) for term in terms if cleanup_text(term)])
    if len(ordered) <= 1:
        return ordered
    specific_terms = [term for term in ordered if term not in WEAK_FOCUS_TERMS]
    return specific_terms or ordered


def expand_chunk_hints(chunk: str) -> list[str]:
    cleaned = cleanup_text(chunk)
    if not cleaned:
        return []

    candidates: list[str] = [cleaned]
    for hint in TERM_HINTS:
        if len(hint) >= 2 and hint in cleaned and hint != cleaned:
            candidates.append(hint)

    for piece in [cleanup_text(part) for part in TERM_SPLIT_RE.split(cleaned) if cleanup_text(part)]:
        if len(piece) >= 2:
            candidates.append(piece)
        for hint in TERM_HINTS:
            if len(hint) >= 2 and hint in piece and hint != piece:
                candidates.append(hint)
    return dedupe_keep_order(candidates)


def infer_query_mode(raw_query: str, requested_mode: str) -> str:
    if requested_mode != "auto":
        return requested_mode
    text = cleanup_text(raw_query)
    if not text:
        return "search"
    if REPLY_INTENT_RE.search(text):
        return "answer"
    if "？" in text or "?" in text:
        return "answer"
    if len(text) >= 6 and QUESTION_HINT_RE.search(text):
        return "answer"
    return "search"


def extract_focus_terms(query: str, owner_name: str, aliases: list[str]) -> tuple[list[str], list[str]]:
    working = query
    quoted = re.findall(r"[“\"'‘](.+?)[”\"'’]", working)
    hashtags = re.findall(r"#([^\s#，。！？、；;:：]+)", working)
    collected = [cleanup_text(item) for item in quoted + hashtags if cleanup_text(item)]

    for token in [owner_name, *aliases]:
        token = cleanup_text(token)
        if token:
            working = working.replace(token, " ")

    for phrase in sorted(set(TRIGGER_PREFIXES + QUERY_NOISE_PHRASES), key=len, reverse=True):
        working = working.replace(phrase, " ")

    working = re.sub(r"(有没有|能不能|可以不可以|如何|怎么|怎样|请问)", " ", working)
    working = re.sub(r"(的|呢|吗|呀|啊|吧)$", " ", working)
    working = SPACE_PUNCT_RE.sub(" ", working)
    working = re.sub(r"\s+", " ", working).strip()

    for chunk in [cleanup_text(item) for item in working.split(" ") if cleanup_text(item)]:
        for piece in split_compound_terms(chunk):
            cleaned = re.sub(r"^(关于|有关|围绕|针对)", "", piece)
            cleaned = re.sub(r"^(把|将)", "", cleaned)
            cleaned = re.sub(r"(的|呢|吗|呀|啊|吧)$", "", cleaned)
            cleaned = cleanup_text(cleaned)
            if len(cleaned) >= 2:
                collected.extend(expand_chunk_hints(cleaned))

    if not collected:
        fallback = cleanup_text(SPACE_PUNCT_RE.sub(" ", query))
        if len(fallback) >= 2:
            collected.extend(expand_chunk_hints(fallback))

    focus_terms = rebalance_focus_terms(collected)
    expanded: list[str] = []
    for term in focus_terms:
        for expanded_term in TERM_EXPANSIONS.get(term, []):
            expanded_term = cleanup_text(expanded_term)
            if expanded_term and expanded_term not in focus_terms:
                expanded.append(expanded_term)
    return focus_terms, dedupe_keep_order(expanded)


def analyze_query(raw_query: str, config: dict[str, Any]) -> QueryBundle:
    owner_cfg = config.get("owner", {})
    owner_name = cleanup_text(owner_cfg.get("name")) or "章明"
    aliases = [cleanup_text(item) for item in (owner_cfg.get("aliases") or []) if cleanup_text(item)]

    stripped = strip_trigger_prefixes(raw_query)
    stripped = strip_profile_activation_prefixes(stripped, config)
    owner_resolved = replace_owner_aliases(stripped, owner_name, aliases)
    no_time_text, time_filter = extract_time_filter(owner_resolved)
    normalized = cleanup_text(no_time_text) or cleanup_text(raw_query)
    focus_terms, expanded_terms = extract_focus_terms(normalized, owner_name, aliases)

    return QueryBundle(
        raw=raw_query,
        normalized=normalized,
        focus_terms=focus_terms,
        expanded_terms=expanded_terms,
        owner_name=owner_name,
        owner_resolved_query=owner_resolved,
        time_filter=time_filter,
    )


def within_time_filter(record: Record, time_filter: TimeFilter | None) -> bool:
    if not time_filter:
        return True
    if not record.publish_dt:
        return False
    current = record.publish_dt.date()
    return time_filter.start <= current <= time_filter.end


def compact_count(haystack: str, needle: str) -> int:
    if not haystack or not needle:
        return 0
    return haystack.count(needle)


def determine_relevance(score: int) -> str:
    if score >= 260:
        return "high"
    if score >= 150:
        return "medium"
    return "low"


def build_source_ref(item: dict[str, Any]) -> dict[str, str]:
    topic = cleanup_text(item.get("topic")) or "未命名主题"
    publish_date = cleanup_text(item.get("publishDate"))
    video_id = cleanup_text(item.get("videoId"))
    url = cleanup_text(item.get("url"))
    source = cleanup_text(item.get("source") or item.get("platform")) or "原文"
    return {
        "summaryLine": f"{publish_date} | {topic} | 视频ID {video_id}",
        "linkLine": f"{source}：{url}",
    }


def select_snippet(record: Record, direct_terms: list[str], expanded_terms: list[str], snippet_length: int) -> str:
    joined_key_points = "；".join(record.key_points)
    text_sources = [joined_key_points, record.transcript, "；".join(record.comments)]
    terms = direct_terms + expanded_terms

    for text in text_sources:
        clean_text = cleanup_text(text)
        if not clean_text:
            continue
        for term in terms:
            index = clean_text.find(term)
            if index >= 0:
                start = max(index - snippet_length // 3, 0)
                end = min(start + snippet_length, len(clean_text))
                return clean_text[start:end]

    if record.key_points:
        return "；".join(record.key_points[:2])[:snippet_length]
    return record.transcript[:snippet_length]


def select_transcript_excerpt(transcript: str, terms: list[str], excerpt_length: int) -> str:
    clean_text = cleanup_text(transcript)
    if not clean_text:
        return ""
    for term in terms:
        term = cleanup_text(term)
        if not term:
            continue
        index = clean_text.find(term)
        if index >= 0:
            start = max(index - excerpt_length // 3, 0)
            end = min(start + excerpt_length, len(clean_text))
            excerpt = clean_text[start:end]
            if start > 0:
                excerpt = "…" + excerpt
            if end < len(clean_text):
                excerpt = excerpt + "…"
            return excerpt
    if len(clean_text) <= excerpt_length:
        return clean_text
    return clean_text[:excerpt_length] + "…"


def score_record(record: Record, bundle: QueryBundle, query_cfg: dict[str, Any]) -> dict[str, Any] | None:
    if not within_time_filter(record, bundle.time_filter):
        return None

    score = 0
    reasons: list[str] = []
    matched_terms: set[str] = set()
    matched_expanded: set[str] = set()
    expanded_weight = float(query_cfg.get("expanded_term_weight") or 0.35)
    compact_full_query = normalize_for_match(bundle.normalized)

    for term in bundle.focus_terms:
        compact_term = normalize_for_match(term)
        if not compact_term:
            continue
        for field_name, label, weight in FIELD_WEIGHTS:
            count = compact_count(getattr(record, field_name), compact_term)
            if not count:
                continue
            increment = weight + max(0, count - 1) * max(weight // 3, 1)
            score += increment
            reasons.append(f"{label}命中“{term}”")
            matched_terms.add(term)

        if compact_term and record.topic and compact_term == normalize_for_match(record.topic):
            score += 40
            reasons.append(f"主题精确命中“{term}”")

    for term in bundle.expanded_terms:
        compact_term = normalize_for_match(term)
        if not compact_term:
            continue
        for field_name, label, weight in FIELD_WEIGHTS:
            count = compact_count(getattr(record, field_name), compact_term)
            if not count:
                continue
            increment = int(weight * expanded_weight)
            score += increment
            reasons.append(f"{label}扩展命中“{term}”")
            matched_expanded.add(term)
            break

    if compact_full_query and len(compact_full_query) >= 4 and compact_full_query in record.all_text:
        score += 70
        reasons.append("整句命中")

    if bundle.focus_terms and len(matched_terms) == len(bundle.focus_terms):
        score += 25 + len(matched_terms) * 5
        reasons.append("核心词全部命中")

    if score < int(query_cfg.get("min_score") or 55):
        return None

    snippet_length = int(query_cfg.get("snippet_length") or 90)
    snippet = select_snippet(record, bundle.focus_terms, bundle.expanded_terms, snippet_length)
    evidence_terms = bundle.focus_terms + bundle.expanded_terms
    matched_key_points = [item for item in record.key_points if any(term in item for term in evidence_terms)]
    matched_comments = [item for item in record.comments if any(term in item for term in evidence_terms)]
    transcript_excerpt = select_transcript_excerpt(
        record.transcript,
        evidence_terms,
        int(query_cfg.get("answer_excerpt_length") or 220),
    )

    result = {
        "score": score,
        "relevance": determine_relevance(score),
        "videoId": record.video_id,
        "publishTime": record.publish_time,
        "publishDate": record.publish_date,
        "topic": record.topic,
        "title": record.title,
        "tags": record.tags,
        "duration": record.duration,
        "durationSeconds": record.duration_seconds,
        "keyPoints": record.key_points,
        "matchedKeyPoints": matched_key_points[:4],
        "comments": matched_comments[:3],
        "snippet": snippet,
        "transcriptExcerpt": transcript_excerpt,
        "engagement": {
            "diggCount": record.digg_count,
            "collectCount": record.collect_count,
            "commentCount": record.comment_count,
            "shareCount": record.share_count,
        },
        "whyMatched": dedupe_keep_order(reasons)[:8],
        "platform": record.platform,
        "source": record.source,
        "uploader": record.uploader,
        "url": record.url,
        "backupPath": record.backup_path,
    }
    result["sourceRef"] = build_source_ref(result)
    return result


def search_records(records: list[Record], bundle: QueryBundle, config: dict[str, Any], top_k: int) -> list[dict[str, Any]]:
    query_cfg = config.get("query", {})
    scored: list[dict[str, Any]] = []
    for record in records:
        match = score_record(record, bundle, query_cfg)
        if match:
            scored.append(match)
    scored.sort(key=lambda item: (item["score"], item["publishTime"]), reverse=True)
    top_results = scored[:top_k]
    for index, item in enumerate(top_results, start=1):
        item["rank"] = index
    return top_results


def format_duration(seconds: int) -> str:
    hours, remainder = divmod(seconds, 3600)
    minutes, secs = divmod(remainder, 60)
    parts: list[str] = []
    if hours:
        parts.append(f"{hours} 小时")
    if minutes or hours:
        parts.append(f"{minutes} 分")
    parts.append(f"{secs} 秒")
    return " ".join(parts)


def build_top_video_lists(records: list[Record], top_n: int) -> dict[str, list[dict[str, Any]]]:
    top_lists: dict[str, list[dict[str, Any]]] = {}
    for metric_key, _, attr_name in ENGAGEMENT_METRICS:
        ranked = sorted(
            records,
            key=lambda item: (getattr(item, attr_name), item.publish_time, item.video_id),
            reverse=True,
        )
        items: list[dict[str, Any]] = []
        for record in ranked[:top_n]:
            payload = {
                "publishDate": record.publish_date,
                "publishTime": record.publish_time,
                "topic": record.topic or "未命名主题",
                "videoId": record.video_id,
                "platform": record.platform,
                "source": record.source,
                "url": record.url,
                "value": getattr(record, attr_name),
            }
            payload["sourceRef"] = build_source_ref(payload)
            items.append(payload)
        top_lists[metric_key] = items
    return top_lists


def build_top_topic_lists(records: list[Record], top_n: int) -> dict[str, list[dict[str, Any]]]:
    grouped: dict[str, dict[str, Any]] = {}
    for record in records:
        topic = record.topic or "未命名主题"
        bucket = grouped.setdefault(
            topic,
            {
                "topic": topic,
                "videoCount": 0,
                "latestPublishTime": "",
                "diggCount": 0,
                "collectCount": 0,
                "commentCount": 0,
                "shareCount": 0,
            },
        )
        bucket["videoCount"] += 1
        bucket["diggCount"] += record.digg_count
        bucket["collectCount"] += record.collect_count
        bucket["commentCount"] += record.comment_count
        bucket["shareCount"] += record.share_count
        latest = cleanup_text(bucket["latestPublishTime"])
        if record.publish_time and (not latest or record.publish_time > latest):
            bucket["latestPublishTime"] = record.publish_time

    top_lists: dict[str, list[dict[str, Any]]] = {}
    values = list(grouped.values())
    for metric_key, _, _ in ENGAGEMENT_METRICS:
        ranked = sorted(
            values,
            key=lambda item: (int(item[metric_key]), int(item["videoCount"]), cleanup_text(item["latestPublishTime"])),
            reverse=True,
        )
        top_lists[metric_key] = [
            {
                "topic": item["topic"],
                "videoCount": item["videoCount"],
                "latestPublishTime": item["latestPublishTime"],
                "value": item[metric_key],
            }
            for item in ranked[:top_n]
        ]
    return top_lists


def build_stats(records: list[Record], backup_root: Path, config: dict[str, Any]) -> dict[str, Any]:
    transcript_chars = sum(len(record.transcript) for record in records)
    total_duration = sum(record.duration_seconds for record in records)
    published = [record.publish_dt for record in records if record.publish_dt]
    canonical_count, duplicate_count = load_catalog_counts(backup_root)
    total_digg = sum(record.digg_count for record in records)
    total_collect = sum(record.collect_count for record in records)
    total_comment = sum(record.comment_count for record in records)
    total_share = sum(record.share_count for record in records)
    count = len(records) or 1
    top_n = max(1, int((config.get("stats") or {}).get("top_n") or 3))
    top_videos = build_top_video_lists(records, top_n)
    stats_source_refs = collect_stats_source_refs(top_videos)
    return {
        "recordCount": len(records),
        "canonicalCount": canonical_count,
        "duplicateSkipped": duplicate_count,
        "totalTranscriptChars": transcript_chars,
        "totalDurationSeconds": total_duration,
        "totalDurationHuman": format_duration(total_duration),
        "totalDiggCount": total_digg,
        "totalCollectCount": total_collect,
        "totalCommentCount": total_comment,
        "totalShareCount": total_share,
        "avgTranscriptCharsPerVideo": round(transcript_chars / count, 2) if records else 0,
        "avgDurationSecondsPerVideo": round(total_duration / count, 2) if records else 0,
        "avgDurationHumanPerVideo": format_duration(round(total_duration / count)) if records else "0 秒",
        "avgDiggCountPerVideo": round(total_digg / count, 2) if records else 0,
        "avgCollectCountPerVideo": round(total_collect / count, 2) if records else 0,
        "avgCommentCountPerVideo": round(total_comment / count, 2) if records else 0,
        "avgShareCountPerVideo": round(total_share / count, 2) if records else 0,
        "firstPublishTime": min(published).strftime("%Y-%m-%d %H:%M:%S") if published else "",
        "lastPublishTime": max(published).strftime("%Y-%m-%d %H:%M:%S") if published else "",
        "topN": top_n,
        "topVideosByEngagement": top_videos,
        "topTopicsByEngagement": build_top_topic_lists(records, top_n),
        "sourceRefs": stats_source_refs,
        "sourceRefText": build_source_ref_text(stats_source_refs),
    }


def build_source_ref_text(source_refs: list[dict[str, str]]) -> str:
    if not source_refs:
        return ""
    lines = ["原文定位"]
    for index, item in enumerate(source_refs, start=1):
        lines.append(f"{index}. {item['summaryLine']}")
        lines.append(f"   {item['linkLine']}")
    return "\n".join(lines)


def dedupe_source_refs(source_refs: list[dict[str, str]]) -> list[dict[str, str]]:
    seen: set[tuple[str, str]] = set()
    deduped: list[dict[str, str]] = []
    for item in source_refs:
        summary = cleanup_text(item.get("summaryLine"))
        link = cleanup_text(item.get("linkLine"))
        key = (summary, link)
        if not summary or not link or key in seen:
            continue
        seen.add(key)
        deduped.append(
            {
                "summaryLine": item["summaryLine"],
                "linkLine": item["linkLine"],
            }
        )
    return deduped


def collect_stats_source_refs(top_videos: dict[str, list[dict[str, Any]]]) -> list[dict[str, str]]:
    refs: list[dict[str, str]] = []
    for metric_key, _, _ in ENGAGEMENT_METRICS:
        entries = top_videos.get(metric_key) or []
        if not entries:
            continue
        source_ref = entries[0].get("sourceRef")
        if source_ref:
            refs.append(source_ref)
    return dedupe_source_refs(refs)


def filter_source_refs_by_ranks(results: list[dict[str, Any]], ranks: list[int]) -> list[dict[str, str]]:
    if not results:
        return []
    if not ranks:
        return [item["sourceRef"] for item in results[: min(3, len(results))] if item.get("sourceRef")]
    rank_set = set(ranks)
    return [item["sourceRef"] for item in results if item.get("rank") in rank_set and item.get("sourceRef")]


def normalize_multiline_text(text: str) -> str:
    value = str(text or "").replace("\r\n", "\n").strip()
    return re.sub(r"\n{3,}", "\n\n", value)


def parse_answer_payload(raw_text: str) -> dict[str, Any]:
    parsed = parse_json_from_text(raw_text)
    answer = normalize_multiline_text(parsed.get("answer") or "")
    if not answer:
        raise ValueError("生成结果缺少 answer")

    used_source_ranks: list[int] = []
    for item in parsed.get("usedSourceRanks") or []:
        if isinstance(item, int):
            used_source_ranks.append(item)
        elif isinstance(item, str):
            match = re.search(r"(\d+)", item)
            if match:
                used_source_ranks.append(int(match.group(1)))

    confidence = cleanup_text(parsed.get("confidence")) or "partial"
    raw_notes = parsed.get("notes") or []
    if isinstance(raw_notes, str):
        raw_notes = [raw_notes]
    notes = [cleanup_text(item) for item in raw_notes if cleanup_text(item)]

    return {
        "text": answer,
        "usedSourceRanks": used_source_ranks,
        "confidence": confidence,
        "notes": notes[:6],
    }


def default_used_source_ranks(results: list[dict[str, Any]], limit: int = 3) -> list[int]:
    ranks: list[int] = []
    for item in results[: min(limit, len(results))]:
        rank = item.get("rank")
        if isinstance(rank, int):
            ranks.append(rank)
    return ranks


def recover_answer_from_text(raw_text: str, results: list[dict[str, Any]]) -> dict[str, Any] | None:
    text = normalize_multiline_text(strip_code_fence(raw_text))
    if not text:
        return None
    text = re.sub(r"^(?:answer|回答|最终回答)\s*[:：]\s*", "", text, flags=re.IGNORECASE)
    text = normalize_multiline_text(text)
    compact = re.sub(r"\s+", "", text)
    if len(compact) < 30:
        return None
    return {
        "text": text,
        "usedSourceRanks": default_used_source_ranks(results),
        "confidence": "partial",
        "notes": ["模型未按 JSON 返回，已自动提取正文。"],
    }


def parse_answer_payload_with_recovery(raw_text: str, results: list[dict[str, Any]]) -> dict[str, Any]:
    try:
        return parse_answer_payload(raw_text)
    except Exception:
        recovered = recover_answer_from_text(raw_text, results)
        if recovered:
            return recovered
        raise


def build_answer_prompt(
    raw_query: str,
    bundle: QueryBundle,
    results: list[dict[str, Any]],
    config: dict[str, Any],
    persona_mode: str,
) -> str:
    owner_cfg = config.get("owner", {})
    answer_cfg = config.get("answer", {})
    owner_name = cleanup_text(owner_cfg.get("name")) or bundle.owner_name or "章明"
    owner_role = cleanup_text(answer_cfg.get("owner_role")) or "经验分享者"
    voice_style = cleanup_text(answer_cfg.get("voice_style")) or "判断清楚，口语自然，先说结论，再给依据，别端着"

    if persona_mode == "owner":
        persona_instruction = (
            f"请默认用{owner_name}本人的第一人称口吻回答，就像{owner_name}本人在回复客户。"
            "不要说“知识库显示”“视频里讲过”，而是直接自然地表达观点。"
        )
    else:
        persona_instruction = (
            f"请用中性中文整理{owner_name}在知识库中的稳定观点，避免替他虚构经历或原话。"
        )

    evidence_blocks: list[str] = []
    for item in results:
        evidence_blocks.append(
            "\n".join(
                [
                    f"[S{item.get('rank')}]",
                    f"发布日期：{item.get('publishDate') or '未知'}",
                    f"主题：{item.get('topic') or '未命名主题'}",
                    f"视频ID：{item.get('videoId') or ''}",
                    f"命中分数：{item.get('score') or 0}",
                    "核心要点：",
                    *(f"- {point}" for point in (item.get("keyPoints") or [])[:4]),
                    f"命中片段：{item.get('snippet') or '无'}",
                    f"全文摘录：{item.get('transcriptExcerpt') or '无'}",
                ]
            )
        )

    return "\n".join(
        [
            "你在做 grounded 中文问答。必须严格基于证据回答，不得编造证据之外的案例、原话、人物经历、时间或结论。",
            persona_instruction,
            f"人物设定：{owner_name}，角色偏向 {owner_role}。",
            f"表达风格：{voice_style}。",
            "如果证据不足，只能回答证据能支撑的部分，并明确说“按我目前内容里的经验/按我目前这部分内容看”。",
            "回答要求：",
            "1. 直接回答用户问题，优先给结论，不空泛。",
            "2. 尽量控制在 2 到 5 段，必要时可用 1 到 3 个短编号。",
            "3. 不要在正文里堆砌视频标题、发布日期、source 编号。",
            "4. 可以给建议，但必须能被证据支持。",
            "5. 如果用户像在问客户问题，就按“可直接发给客户”的口径写。",
            '仅输出 JSON，不要输出 markdown、解释或代码块。JSON 结构固定为 {"answer":"最终回答","usedSourceRanks":[1,2],"confidence":"high|partial","notes":["说明1","说明2"]}。',
            "最终输出的第一个字符必须是 {，最后一个字符必须是 }。",
            f"原始问题：{raw_query}",
            f"归一化问题：{bundle.normalized}",
            "",
            "证据如下：",
            *evidence_blocks,
        ]
    )


def generate_answer_with_ark(prompt: str, config: dict[str, Any]) -> str:
    answer_cfg = config.get("answer", {})
    ark_api_key = cleanup_text(os.getenv("ARK_API_KEY") or answer_cfg.get("ark_api_key"))
    if not ark_api_key:
        raise RuntimeError("ARK_API_KEY 未配置")

    ark_base_url = cleanup_text(os.getenv("ARK_BASE_URL") or answer_cfg.get("ark_base_url")) or "https://ark.cn-beijing.volces.com/api/v3"
    ark_model = cleanup_text(os.getenv("ARK_MODEL") or answer_cfg.get("ark_model")) or "doubao-seed-2-0-lite-260215"
    payload = {
        "model": ark_model,
        "messages": [
            {
                "role": "system",
                "content": "你是 grounded 中文问答助手。你只输出 JSON，不输出解释、markdown 或代码块。",
            },
            {"role": "user", "content": prompt},
        ],
        "temperature": float(answer_cfg.get("temperature") or 0.2),
        "max_tokens": int(answer_cfg.get("ark_max_tokens") or 1200),
        "thinking": {"type": "disabled"},
    }
    request = urllib.request.Request(
        f"{ark_base_url.rstrip('/')}/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {ark_api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    timeout = int(answer_cfg.get("timeout_seconds") or 120)
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="ignore")
        raise RuntimeError(f"Ark 问答失败: HTTP {exc.code} {body}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Ark 问答失败: {exc.reason}") from exc

    data = json.loads(raw)
    text = extract_ark_chat_text(data)
    if not text:
        raise RuntimeError("Ark 返回为空")
    return text


def generate_answer_with_openclaw(prompt: str, config: dict[str, Any]) -> str:
    answer_cfg = config.get("answer", {})
    completed = subprocess.run(
        [
            resolve_openclaw_bin(),
            "--log-level",
            "silent",
            "agent",
            "--agent",
            "main",
            "--local",
            "--json",
            "--timeout",
            str(int(answer_cfg.get("timeout_seconds") or 120)),
            "--thinking",
            cleanup_text(answer_cfg.get("openclaw_thinking")) or "minimal",
            "--message",
            prompt,
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    raw = completed.stdout.strip() or completed.stderr.strip()
    if completed.returncode != 0:
        raise RuntimeError(f"OpenClaw 问答失败: {raw or f'exit={completed.returncode}'}")
    result = parse_json_from_text(raw)
    status = result.get("status")
    if status not in {None, "ok"}:
        raise RuntimeError(f"OpenClaw 问答失败: {result.get('summary') or 'unknown_error'}")
    text = extract_openclaw_text(result)
    if not text:
        raise RuntimeError("OpenClaw 返回为空")
    return text


def has_ark_answer_provider(config: dict[str, Any]) -> bool:
    answer_cfg = config.get("answer", {})
    return bool(cleanup_text(os.getenv("ARK_API_KEY") or answer_cfg.get("ark_api_key")))


def resolve_answer_provider_attempts(provider: str, config: dict[str, Any]) -> list[str]:
    has_ark = has_ark_answer_provider(config)
    if provider == "ark":
        return ["ark"]
    if provider == "openclaw":
        return ["openclaw", "ark"] if has_ark else ["openclaw"]
    if provider == "auto":
        return ["ark", "openclaw"] if has_ark else ["openclaw"]
    return ["openclaw", "ark"] if has_ark else ["openclaw"]


def generate_answer_with_provider(
    provider: str,
    prompt: str,
    config: dict[str, Any],
    results: list[dict[str, Any]],
) -> dict[str, Any]:
    if provider == "ark":
        raw_text = generate_answer_with_ark(prompt, config)
        return parse_answer_payload_with_recovery(raw_text, results)

    last_error: Exception | None = None
    for attempt in range(OPENCLAW_RETRY_ATTEMPTS):
        try:
            raw_text = generate_answer_with_openclaw(prompt, config)
            return parse_answer_payload_with_recovery(raw_text, results)
        except Exception as exc:
            last_error = exc
            if attempt + 1 < OPENCLAW_RETRY_ATTEMPTS:
                time.sleep(0.8)
    raise last_error or RuntimeError("OpenClaw 问答失败")


def fallback_answer(
    raw_query: str,
    bundle: QueryBundle,
    results: list[dict[str, Any]],
    persona_mode: str,
) -> dict[str, Any]:
    if not results:
        prefix = "按我目前这部分内容看，" if persona_mode == "owner" else "按当前知识库命中的内容看，"
        return {
            "text": prefix + "我还没找到足够直接的相关材料，建议换个更具体的提法，或者补一个主题词再查。",
            "usedSourceRanks": [],
            "confidence": "partial",
            "notes": ["未命中足够相关内容，已返回兜底提示。"],
        }

    picked_points: list[str] = []
    used_ranks: list[int] = []
    for item in results[:3]:
        for point in (item.get("matchedKeyPoints") or item.get("keyPoints") or []):
            point = cleanup_text(point)
            if point and point not in picked_points:
                picked_points.append(point)
        if item.get("rank"):
            used_ranks.append(int(item["rank"]))

    opener = (
        "结合我自己一直反复讲的内容，这个问题我会先抓这几件事："
        if persona_mode == "owner"
        else f"结合{bundle.owner_name}知识库里反复出现的内容，这个问题可以先抓这几件事："
    )
    lines = [opener]
    for index, point in enumerate(picked_points[:3], start=1):
        lines.append(f"{index}. {point}")

    if results[0].get("snippet"):
        lines.append(f"如果只按我目前命中的内容往下说，最关键的提醒是：{cleanup_text(results[0]['snippet'])}")

    return {
        "text": "\n".join(lines).strip(),
        "usedSourceRanks": used_ranks[:3],
        "confidence": "partial" if len(results) < 2 else "high",
        "notes": ["模型生成不可用，已降级为基于命中结果的规则化回答。"],
    }


def resolve_answer_provider(cli_provider: str | None, config: dict[str, Any]) -> str:
    if cli_provider is not None:
        return normalize_provider(cli_provider, field_name="--provider")
    env_provider = (
        os.getenv("KNOWLEDGE_BASE_ANSWER_PROVIDER")
        or os.getenv("VIDEO_KNOWLEDGE_ANSWER_PROVIDER")
        or os.getenv("VIDEO_KNOWLEDGE_QUERY_PROVIDER")
        or ""
    )
    if str(env_provider).strip():
        return normalize_provider(env_provider, field_name="KNOWLEDGE_BASE_ANSWER_PROVIDER")
    answer_cfg = config.get("answer", {})
    return normalize_provider(answer_cfg.get("provider") or "auto", field_name="runtime.toml [answer].provider")


def build_answer(
    raw_query: str,
    bundle: QueryBundle,
    results: list[dict[str, Any]],
    config: dict[str, Any],
    provider_override: str | None = None,
) -> dict[str, Any]:
    answer_cfg = config.get("answer", {})
    persona_mode = cleanup_text(answer_cfg.get("default_persona")) or "owner"

    if not results:
        answer = fallback_answer(raw_query, bundle, results, persona_mode)
        answer["persona"] = persona_mode
        return answer

    prompt = build_answer_prompt(raw_query, bundle, results[: int(answer_cfg.get("max_evidence_results") or 5)], config, persona_mode)
    provider = resolve_answer_provider(provider_override, config)

    try:
        attempt_providers = resolve_answer_provider_attempts(provider, config)
        last_error: Exception | None = None
        answer: dict[str, Any] | None = None
        used_provider = "fallback"
        for candidate in attempt_providers:
            try:
                answer = generate_answer_with_provider(candidate, prompt, config, results)
                used_provider = candidate
                break
            except Exception as exc:
                last_error = exc
        if answer is None:
            if provider == "ark" and not has_ark_answer_provider(config):
                raise RuntimeError("ARK_API_KEY 未配置") from last_error
            raise last_error or RuntimeError("问答生成失败")
        answer["provider"] = used_provider
    except Exception:
        answer = fallback_answer(raw_query, bundle, results, persona_mode)
        answer["provider"] = "fallback"

    source_refs = filter_source_refs_by_ranks(results, answer.get("usedSourceRanks") or [])
    answer["persona"] = persona_mode
    answer["sourceRefs"] = source_refs
    answer["sourceRefText"] = build_source_ref_text(source_refs)
    return answer


def render_text(payload: dict[str, Any]) -> str:
    lines: list[str] = []
    query = payload.get("query")
    answer = payload.get("answer")
    if query:
        if answer:
            lines.append(f"问题: {query.get('raw')}")
            lines.append("")
        else:
            lines.append(f"查询: {query.get('raw')}")
            lines.append(f"归一化: {query.get('normalized')}")
            if query.get("focusTerms"):
                lines.append(f"关键词: {', '.join(query.get('focusTerms') or [])}")
            if query.get("expandedTerms"):
                lines.append(f"扩展词: {', '.join(query.get('expandedTerms') or [])}")
            if query.get("timeFilter"):
                lines.append(f"时间过滤: {query['timeFilter'].get('label')}")
            lines.append("")

    stats = payload.get("stats")
    if stats:
        lines.append("知识库总体")
        lines.append(f"- 视频总数：{stats['recordCount']} 条")
        lines.append(f"- 原文总字数：{stats['totalTranscriptChars']} 字")
        lines.append(f"- 视频总时长：{stats['totalDurationSeconds']} 秒 = {stats['totalDurationHuman']}")
        lines.append(f"- 最早发布日期：{stats['firstPublishTime']}")
        lines.append(f"- 最新发布日期：{stats['lastPublishTime']}")
        lines.append(f"- 去重后有效视频数：{stats['canonicalCount']}")
        lines.append(f"- 备份里重复记录跳过：{stats['duplicateSkipped']}")
        lines.append("")
        lines.append("互动数据汇总")
        lines.append(f"- 点赞总数：{stats['totalDiggCount']}")
        lines.append(f"- 收藏总数：{stats['totalCollectCount']}")
        lines.append(f"- 评论总数：{stats['totalCommentCount']}")
        lines.append(f"- 转发总数：{stats['totalShareCount']}")
        lines.append("")
        lines.append("单条平均")
        lines.append(f"- 平均字数：{stats['avgTranscriptCharsPerVideo']} 字/条")
        lines.append(f"- 平均时长：{stats['avgDurationSecondsPerVideo']} 秒/条（{stats['avgDurationHumanPerVideo']}）")
        lines.append(f"- 平均点赞：{stats['avgDiggCountPerVideo']}/条")
        lines.append(f"- 平均收藏：{stats['avgCollectCountPerVideo']}/条")
        lines.append(f"- 平均评论：{stats['avgCommentCountPerVideo']}/条")
        lines.append(f"- 平均转发：{stats['avgShareCountPerVideo']}/条")
        lines.append("")

        top_videos = stats.get("topVideosByEngagement") or {}
        if top_videos:
            lines.append("互动最高内容")
            for metric_key, label, _ in ENGAGEMENT_METRICS:
                entries = top_videos.get(metric_key) or []
                if not entries:
                    continue
                best = entries[0]
                lines.append(
                    f"- {label}最高：{best['value']} | {best['publishDate']} | {best['topic']} | 视频ID {best['videoId']}"
                )
            lines.append("")

        top_topics = stats.get("topTopicsByEngagement") or {}
        if top_topics:
            lines.append("互动最高主题")
            for metric_key, label, _ in ENGAGEMENT_METRICS:
                entries = top_topics.get(metric_key) or []
                if not entries:
                    continue
                best = entries[0]
                lines.append(
                    f"- {label}最高主题：{best['topic']} | {best['value']} | {best['videoCount']} 条"
                )
            lines.append("")

        stats_source_ref_text = str(stats.get("sourceRefText") or "").strip()
        if stats_source_ref_text:
            lines.append(stats_source_ref_text)
            lines.append("")

    results = payload.get("results") or []
    if answer:
        lines.append(str(answer.get("text") or "").strip())
        notes = answer.get("notes") or []
        if notes:
            lines.append("")
            lines.append("补充说明")
            for item in notes:
                lines.append(f"- {item}")
        source_ref_text = str(answer.get("sourceRefText") or "").strip()
        if source_ref_text:
            lines.append("")
            lines.append(source_ref_text)
        return "\n".join(lines).strip()

    if stats and not query:
        return "\n".join(lines).strip()

    if not results:
        lines.append("未找到足够相关的记录。")
        return "\n".join(lines).strip()

    for index, item in enumerate(results, start=1):
        lines.append(f"{index}. {item['publishDate']} #{item['topic'] or '未命名主题'}  score={item['score']}")
        if item.get("tags"):
            lines.append(f"   标签: {' '.join('#' + tag for tag in item['tags'])}")
        if item.get("matchedKeyPoints"):
            lines.append(f"   要点: {'；'.join(item['matchedKeyPoints'])}")
        elif item.get("keyPoints"):
            lines.append(f"   要点: {'；'.join(item['keyPoints'][:2])}")
        if item.get("snippet"):
            lines.append(f"   片段: {item['snippet']}")
        lines.append(f"   链接: {item['url']}")

    source_ref_text = str(payload.get("sourceRefText") or "").strip()
    if source_ref_text:
        lines.append("")
        lines.append(source_ref_text)
    return "\n".join(lines).strip()


def build_payload(args: argparse.Namespace) -> dict[str, Any]:
    script_root = resolve_script_root()
    base_config = load_toml(script_root / "config" / "runtime.toml")
    scope_info = resolve_scope_selection(args, base_config)
    config = apply_profile_overrides(base_config, scope_info.get("profile") or "")
    backup_root = resolve_backup_root(config)
    records = load_records(backup_root)
    payload: dict[str, Any] = {
        "source": {
            "backupRoot": str(backup_root),
            "generatedAt": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        },
        "scope": {
            **scope_info,
            "backupRoot": str(backup_root),
        },
    }

    if args.stats:
        payload["stats"] = build_stats(records, backup_root, config)

    if args.query:
        bundle = analyze_query(args.query, config)
        query_mode = infer_query_mode(args.query, getattr(args, "mode", "auto"))
        payload["query"] = {
            "raw": bundle.raw,
            "normalized": bundle.normalized,
            "ownerName": bundle.owner_name,
            "ownerResolvedQuery": bundle.owner_resolved_query,
            "focusTerms": bundle.focus_terms,
            "expandedTerms": bundle.expanded_terms,
            "timeFilter": None,
            "mode": query_mode,
        }
        if bundle.time_filter:
            payload["query"]["timeFilter"] = {
                "label": bundle.time_filter.label,
                "start": bundle.time_filter.start.isoformat(),
                "end": bundle.time_filter.end.isoformat(),
            }
        top_k = args.top or int(config.get("query", {}).get("default_top_k") or 8)
        payload["results"] = search_records(records, bundle, config, top_k)
        payload["sourceRefs"] = [item["sourceRef"] for item in payload["results"]]
        payload["sourceRefText"] = build_source_ref_text(payload["sourceRefs"])
        if query_mode == "answer":
            payload["answer"] = build_answer(
                args.query,
                bundle,
                payload["results"],
                config,
                provider_override=getattr(args, "provider", None),
            )

    return payload


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="轻量 RAG 查询多来源知识库")
    parser.add_argument("query", nargs="?", help="自然语言查询")
    parser.add_argument("--top", type=int, default=0, help="返回前 N 条")
    parser.add_argument("--stats", action="store_true", help="输出知识库统计")
    parser.add_argument("--profile", help="指定知识库 profile")
    parser.add_argument("--list-profiles", action="store_true", help="列出可用知识库 profile")
    parser.add_argument("--mode", choices=["auto", "search", "answer"], default="auto", help="查询模式")
    parser.add_argument(
        "--provider",
        choices=["auto", "ark", "openclaw"],
        help="问答模型提供方；仅 answer 生效，优先级为命令行 > KNOWLEDGE_BASE_ANSWER_PROVIDER > runtime.toml",
    )
    parser.add_argument("--json", action="store_true", help="JSON 输出")
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    if args.list_profiles:
        config = load_toml(resolve_script_root() / "config" / "runtime.toml")
        payload = build_profiles_payload(config)
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2))
        else:
            print(render_profiles_text(payload))
        return 0

    if not args.query and not args.stats:
        print("请提供查询内容，或使用 --stats。", file=sys.stderr)
        return 2

    try:
        payload = build_payload(args)
    except KnowledgeScopeError as exc:
        if args.json:
            print(json.dumps({"scopeBlocked": True, "error": str(exc)}, ensure_ascii=False, indent=2))
        else:
            print(f"知识库未生效: {exc}", file=sys.stderr)
        return 2

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(render_text(payload))
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))

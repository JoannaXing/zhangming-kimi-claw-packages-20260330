#!/usr/bin/env python3
"""
飞书文档写入模块
用于将转写内容按规范格式写入飞书文档
"""
import json
import re
from datetime import datetime
from pathlib import Path


def extract_hashtags(title):
    """从标题中提取标签"""
    if not title:
        return ""
    # 匹配 #标签 格式
    hashtags = re.findall(r'#([^#\s]+)', title)
    if hashtags:
        return ' '.join([f'#{tag}' for tag in hashtags])
    return title


def format_transcription(
    video_id: str,
    video_title: str,
    publish_time: str,
    duration: str,
    transcript: str,
    asr_duration: str = "约 5 秒",
    digg_count: int = 0,
    collect_count: int = 0,
    comment_count: int = 0,
    share_count: int = 0
) -> str:
    """
    格式化转写内容为飞书文档格式
    
    Args:
        video_id: 抖音视频ID
        video_title: 视频标题/标签
        publish_time: 发布时间 (YYYY-MM-DD HH:MM)
        duration: 视频时长 (如 "03:49")
        transcript: 转写正文
        asr_duration: ASR处理耗时
        digg_count: 点赞数
        collect_count: 收藏数
        comment_count: 评论数
        share_count: 转发数
    
    Returns:
        格式化后的 Markdown 文本
    """
    # 提取日期和标签
    date_match = re.match(r'(\d{4}-\d{2}-\d{2})', publish_time)
    date = date_match.group(1) if date_match else publish_time[:10]
    hashtags = extract_hashtags(video_title)
    
    # 计算字数
    word_count = len(transcript.replace(' ', '').replace('\n', ''))
    
    # 构建内容
    content = f"""---

### {date} {hashtags}

**视频信息**

| 项目 | 内容 |
|------|-----|
| 抖音链接 | https://www.douyin.com/video/{video_id} |
| 视频时长 | {duration} |
| 发布时间 | {publish_time} |
| 转写时间 | {datetime.now().strftime('%Y-%m-%d %H:%M')} |
| ASR 耗时 | {asr_duration} |

**互动数据**：点赞：{digg_count}，收藏：{collect_count}，评论：{comment_count}，转发：{share_count}

**完整文案（时长 {duration} | 约 {word_count} 字）**

{transcript}

---
"""
    return content


def append_to_feishu_doc(doc_token: str, content: str) -> bool:
    """
    追加内容到飞书文档
    
    注意：这里使用 openclaw 内置的 feishu_doc 工具
    实际调用时需要通过 agent 完成
    
    Args:
        doc_token: 飞书文档 token
        content: 要追加的内容
    
    Returns:
        是否成功
    """
    # 保存到临时文件，供外部工具读取
    temp_file = Path(f"/tmp/feishu_append_{doc_token[:8]}.md")
    temp_file.write_text(content, encoding='utf-8')
    print(f"[Feishu] 内容已准备，临时文件: {temp_file}")
    print(f"[Feishu] 目标文档 Token: {doc_token}")
    return True


if __name__ == "__main__":
    # 测试
    sample = format_transcription(
        video_id="7618945910454770899",
        video_title="#人生感悟 #认知提升 #下海#创业",
        publish_time="2026-03-19 20:50",
        duration="03:36",
        transcript="大家好，这是测试内容...",
        asr_duration="约 5 秒"
    )
    print(sample)

#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND="${1:-auto}"

eval "$(
  python3 "$SCRIPT_DIR/read_scheduler_config.py" --format env
)"

RUNNER_PATH="$SCRIPT_DIR/run_douyin_daily_sync.sh"
mkdir -p "$scheduler_log_dir"

install_systemd() {
  local unit_dir="$HOME/.config/systemd/user"
  local service_path="$unit_dir/${scheduler_linux_service_name}.service"
  local timer_path="$unit_dir/${scheduler_linux_service_name}.timer"
  local _SCHED_PATH _OPENCLAW_DIR _NODE_DIR
  mkdir -p "$unit_dir"

  # PATH：常见 Node / openclaw 全局安装位置（Linux 容器、Kimi Claw 等常需显式包含）
  _SCHED_PATH="/usr/local/bin:/usr/local/sbin:/usr/bin:/bin:${HOME}/.local/bin:${HOME}/.npm-global/bin:${HOME}/.fnm/current/bin:${HOME}/.volta/bin:${HOME}/.asdf/shims"
  if command -v openclaw >/dev/null 2>&1; then
    _OPENCLAW_DIR="$(dirname "$(command -v openclaw)")"
    _SCHED_PATH="${_OPENCLAW_DIR}:${_SCHED_PATH}"
  fi
  if command -v node >/dev/null 2>&1; then
    _NODE_DIR="$(dirname "$(command -v node)")"
    _SCHED_PATH="${_NODE_DIR}:${_SCHED_PATH}"
  fi

  cat >"$service_path" <<SERVICE
[Unit]
Description=Daily Douyin to Feishu sync (OpenClaw skill)

[Service]
Type=oneshot
WorkingDirectory=${skill_dir}
Environment=TZ=Asia/Shanghai
Environment=PATH=${_SCHED_PATH}
ExecStart=/bin/bash ${RUNNER_PATH}
SERVICE

  cat >"$timer_path" <<TIMER
[Unit]
Description=Daily Douyin sync timer (OnCalendar uses Asia/Shanghai; hour/minute from skill runtime.toml)

[Timer]
OnCalendar=*-*-* $(printf '%02d:%02d' "$scheduler_hour" "$scheduler_minute"):00 Asia/Shanghai
Persistent=true

[Install]
WantedBy=timers.target
TIMER

  systemctl --user daemon-reload
  systemctl --user enable --now "${scheduler_linux_service_name}.timer"
  echo "已安装 systemd user timer: ${scheduler_linux_service_name}.timer"
  echo "查看状态: systemctl --user status ${scheduler_linux_service_name}.timer"
}

install_cron() {
  local _cron_path _node_dir
  _cron_path="/usr/local/bin:/usr/local/sbin:/usr/bin:/bin:${HOME}/.local/bin:${HOME}/.npm-global/bin:${HOME}/.fnm/current/bin:${HOME}/.volta/bin:${HOME}/.asdf/shims"
  if command -v openclaw >/dev/null 2>&1; then
    _cron_path="$(dirname "$(command -v openclaw)"):${_cron_path}"
  fi
  if command -v node >/dev/null 2>&1; then
    _node_dir="$(dirname "$(command -v node)")"
    _cron_path="${_node_dir}:${_cron_path}"
  fi
  local cron_line
  printf -v cron_line '%s %s * * * TZ=Asia/Shanghai PATH=%s /bin/bash %s >>%s 2>&1 # %s\n' \
    "$scheduler_minute" "$scheduler_hour" "$_cron_path" "$RUNNER_PATH" "${scheduler_log_dir}/cron-wrap.log" "$scheduler_linux_service_name"
  (
    crontab -l 2>/dev/null | grep -v "# ${scheduler_linux_service_name}$" || true
    printf '%s' "$cron_line"
  ) | crontab -
  echo "已安装 cron 定时任务: ${scheduler_linux_service_name}"
  echo "查看: crontab -l"
}

if [[ "$BACKEND" == "systemd" ]]; then
  install_systemd
elif [[ "$BACKEND" == "cron" ]]; then
  install_cron
else
  if command -v systemctl >/dev/null 2>&1 && systemctl --user show-environment >/dev/null 2>&1; then
    install_systemd
  elif command -v crontab >/dev/null 2>&1; then
    install_cron
  else
    echo "当前 Linux 环境既不可用 systemd --user，也没有 crontab，请手动调度: $RUNNER_PATH" >&2
    exit 2
  fi
fi

#!/usr/bin/env python3
"""
格式化与状态管理工具，用于 douyin-transcribe-to-feishu。
"""
import json
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from lib.knowledge_base_flags import get_lobster_bitable_value

CHINA_TZ = timezone(timedelta(hours=8))

DISCOURSE_MARKERS = [
    '总结一下',
    '举个例子',
    '换个角度',
    '第一点',
    '第二点',
    '第三点',
    '第四点',
    '第五点',
    '首先',
    '其次',
    '再次',
    '最后',
    '第一',
    '第二',
    '第三',
    '第四',
    '第五',
    '所以',
]
DISCOURSE_MARKER_PATTERN = re.compile(
    '|'.join(re.escape(marker) for marker in sorted(DISCOURSE_MARKERS, key=len, reverse=True))
)
GENERIC_DOUYIN_TITLE_PATTERN = re.compile(r'.*在抖音记录美好生活\d{8}$')


def normalize_publish_time(value: str) -> str:
    if not value:
        return ""
    value = value.strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
        return f"{value} 00:00"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}(:\d{2})?", value):
        return value
    return value


def parse_publish_timestamp_ms(value: str) -> Optional[int]:
    publish_time = normalize_publish_time(value)
    if not publish_time:
        return None
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", publish_time):
            dt = datetime.strptime(publish_time, '%Y-%m-%d %H:%M:%S')
            return int(dt.replace(tzinfo=CHINA_TZ).timestamp() * 1000)
        if re.fullmatch(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}", publish_time):
            dt = datetime.strptime(publish_time, '%Y-%m-%d %H:%M')
            return int(dt.replace(tzinfo=CHINA_TZ).timestamp() * 1000)
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", publish_time):
            dt = datetime.strptime(publish_time, '%Y-%m-%d')
            return int(dt.replace(tzinfo=CHINA_TZ).timestamp() * 1000)
    except Exception:
        return None
    return None


def extract_hashtags(title: str) -> str:
    if not title:
        return ""
    hashtags = re.findall(r'#([^#\s]+)', title)
    if hashtags:
        return ' '.join([f'#{tag}' for tag in hashtags])
    return ""


def extract_heading_hashtags(title: str) -> str:
    return extract_hashtags(title)


def extract_topic(topic: str) -> str:
    topic = (topic or '').strip()
    if not topic:
        return ""
    topic = re.sub(r'^[#\s]+', '', topic)
    topic = re.sub(r'[。；;：:，,、!?！？]+$', '', topic)
    if GENERIC_DOUYIN_TITLE_PATTERN.fullmatch(topic):
        return ""
    return topic[:20].strip()


def format_topic_hashtag(topic: str) -> str:
    normalized = extract_topic(topic)
    return f"#{normalized}" if normalized else ""


def build_display_title(record: Dict[str, Any]) -> str:
    publish_time = normalize_publish_time(record.get('publishTime', ''))
    publish_date = publish_time[:10] if publish_time else '未知日期'
    topic = format_topic_hashtag(record.get('topic', ''))
    return f"{publish_date} {topic}".strip() if topic else publish_date


def split_paragraphs(transcript: str) -> List[str]:
    text = (transcript or '').strip()
    if not text:
        return []
    source_paragraphs = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()] or [text]
    paragraphs = []

    for paragraph in source_paragraphs:
        marker_positions = []
        for match in DISCOURSE_MARKER_PATTERN.finditer(paragraph):
            start = match.start()
            if start <= 0:
                continue
            prev = paragraph[start - 1]
            if prev.isspace() or prev in '，。！？；：,.!?;:':
                marker_positions.append(start)

        if not marker_positions:
            paragraphs.append(paragraph)
            continue

        last_index = 0
        for start in marker_positions:
            segment = paragraph[last_index:start].strip()
            if segment:
                paragraphs.append(segment)
            last_index = start

        tail = paragraph[last_index:].strip()
        if tail:
            paragraphs.append(tail)

    return paragraphs


def word_count(text: str) -> int:
    return len((text or '').replace(' ', '').replace('\n', ''))


def format_transcribed_at_with_duration(record: Dict[str, Any]) -> str:
    transcribed_at = (record.get('transcribedAt') or '').strip()
    asr_duration = re.sub(r'\s+', '', (record.get('asrDuration') or '').strip())
    if transcribed_at and asr_duration:
        return f"{transcribed_at}（{asr_duration}）"
    return transcribed_at or asr_duration


def format_interaction_data(record: Dict[str, Any]) -> str:
    return (
        f"点赞 {record.get('diggCount', 0)}，"
        f"收藏 {record.get('collectCount', 0)}，"
        f"评论 {record.get('commentCount', 0)}，"
        f"转发 {record.get('shareCount', 0)}"
    )


def format_comments_for_display(comments: Any) -> str:
    lines = []
    for idx, item in enumerate(comments or [], start=1):
        text = str(item or '').strip()
        if not text:
            continue
        lines.append(f'{idx}. {text}')
    return '\n'.join(lines)


def build_comments_markdown(record: Dict[str, Any]) -> str:
    comments = format_comments_for_display(record.get('comments') or [])
    if not comments:
        return ''
    count = len([line for line in comments.splitlines() if line.strip()])
    return f"**评论内容（{count}条）**\n\n{comments}"


def format_doc_section(record: Dict[str, Any]) -> str:
    publish_time = normalize_publish_time(record.get('publishTime', ''))
    title_line = build_display_title(record)
    duration = record.get('duration', '00:00')
    transcript = (record.get('transcript') or '').strip()
    points = record.get('keyPoints') or []
    transcribed_with_duration = format_transcribed_at_with_duration(record)
    interaction_data = format_interaction_data(record)
    comments_markdown = build_comments_markdown(record)
    lines = []
    lines.append(f"### {title_line}")
    lines.append('')
    lines.append('**视频信息**')
    lines.append('')
    lines.append('| 项目 | 内容 |')
    lines.append('|------|------|')
    lines.append(f"| 抖音链接 | https://www.douyin.com/video/{record.get('videoId', '')} |")
    lines.append(f"| 视频时长 | {duration} |")
    lines.append(f"| 发布时间 | {publish_time or '缺失（需复核）'} |")
    lines.append(f"| 转写时间 | {transcribed_with_duration} |")
    lines.append(f"| 互动数据 | {interaction_data} |")
    lines.append('')
    lines.append(f"**完整文案（时长 {duration} | 字数 {word_count(transcript)}）**")
    lines.append('')
    lines.extend(split_paragraphs(transcript) or [''])
    lines.append('')
    if comments_markdown:
        lines.append(comments_markdown)
        lines.append('')
    if points:
        lines.append('**核心要点**')
        lines.append('')
        for idx, point in enumerate(points, start=1):
            lines.append(f"{idx}. {point}")
        lines.append('')
    lines.append('---')
    return '\n'.join(lines)


def record_to_doc_sections(record: Dict[str, Any]) -> Dict[str, Any]:
    publish_time = normalize_publish_time(record.get('publishTime', ''))
    title_line = build_display_title(record)
    duration = record.get('duration', '00:00')
    transcript = (record.get('transcript') or '').strip()
    key_points = record.get('keyPoints') or []
    transcribed_with_duration = format_transcribed_at_with_duration(record)
    interaction_data = format_interaction_data(record)
    comments_markdown = build_comments_markdown(record)

    transcript_paragraphs = split_paragraphs(transcript) or ['']
    transcript_body = '\n\n'.join(transcript_paragraphs)
    transcript_markdown = (
        f"**完整文案（时长 {duration} | 字数 {word_count(transcript)}）**\n\n"
        f"{transcript_body}"
    )
    if comments_markdown:
        transcript_markdown = f"{transcript_markdown}\n\n{comments_markdown}"

    return {
        'header_markdown': f"### {title_line}",
        'info_table_rows': [
            ['项目', '内容'],
            ['抖音链接', f"https://www.douyin.com/video/{record.get('videoId', '')}"],
            ['视频时长', duration],
            ['发布时间', publish_time or '缺失（需复核）'],
            ['转写时间', transcribed_with_duration],
            ['互动数据', interaction_data],
        ],
        'interaction_markdown': '',
        'transcript_markdown': transcript_markdown,
        'summary_markdown': (
            "**核心要点**\n\n"
            + '\n'.join([f"{idx}. {point}" for idx, point in enumerate(key_points, start=1)])
            if key_points
            else ''
        ),
        'divider_markdown': '---',
    }


def record_to_bitable_fields(record: Dict[str, Any]) -> Dict[str, Any]:
    publish_time = normalize_publish_time(record.get('publishTime', ''))
    publish_ms = parse_publish_timestamp_ms(publish_time)
    tags = extract_hashtags(record.get('title', ''))
    topic = extract_topic(record.get('topic', ''))
    return {
        '视频ID:': record.get('videoId', ''),
        '发布日期': publish_ms,
        '标签': tags,
        '主题': topic,
        '是否龙虾': get_lobster_bitable_value(record),
        '视频时长': record.get('duration', ''),
        '抖音链接': f"https://www.douyin.com/video/{record.get('videoId', '')}",
        '字数': word_count(record.get('transcript', '')),
        '完整文案': (record.get('transcript') or '').strip(),
        '核心要点': '\n'.join(
            [f'{idx}. {point}' for idx, point in enumerate(record.get('keyPoints') or [], start=1)]
        ),
        '点赞数-抖音': int(record.get('diggCount') or 0),
        '收藏数-抖音': int(record.get('collectCount') or 0),
        '转发数-抖音': int(record.get('shareCount') or 0),
        '评论数-抖音': int(record.get('commentCount') or 0),
        '评论内容': format_comments_for_display(record.get('comments') or []),
    }


def load_checkpoint(path: str) -> Dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {'items': {}}
    return json.loads(p.read_text(encoding='utf-8'))


def save_checkpoint(path: str, data: Dict[str, Any]) -> None:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    import sys
    cmd = sys.argv[1]
    if cmd == 'format-doc':
        record = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
        print(format_doc_section(record))
    elif cmd == 'doc-sections':
        record = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
        print(json.dumps(record_to_doc_sections(record), ensure_ascii=False))
    elif cmd == 'bitable-fields':
        record = json.loads(Path(sys.argv[2]).read_text(encoding='utf-8'))
        print(json.dumps(record_to_bitable_fields(record), ensure_ascii=False))
